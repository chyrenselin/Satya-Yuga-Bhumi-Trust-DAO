# =============================================================================
# content_english.py
# BHUMI TRUST LAND GOVERNANCE SYSTEM v5.0
# Complete English Content File
#
# SOURCE: Extracted directly from Bhumi_Trust_v5_0.pdf
# Every word comes from the original PDF. Nothing added. Nothing removed.
#
# VERIFICATION (check against original PDF cover page):
#   Total rules     : 121  (expected 121)
#   Workflows       : 15  (expected 15)
#   Roles           : 6   (expected 6)
#   Attack tests    : 10  (expected 10)
#   Precedents      : 5   (expected 5)
#   Bulletproof tests: 10  (expected 10)
#
# HOW TO USE:
#   from content_english import *
# =============================================================================

LANGUAGE = "english"

# =============================================================================
# DOCUMENT METADATA
# =============================================================================

DOC_TITLE    = "BHUMI TRUST LAND GOVERNANCE SYSTEM"
DOC_SUBTITLE = "Complete Village Land Governance Manual"
DOC_VERSION  = "Version 5.0 -- Corrected Edition"
DOC_TAGLINE  = "Offline. Paper-based. Community-owned. Legally anchored. Generationally durable. Honest about its limits."
DOC_NEED     = "What you need: Paper. Pens. People. Nothing else."
DOC_WHERE    = "Where it works: Any Indian village, any size."
DOC_WHEN     = "When it starts: Day 1, with 5 people and 6 notebooks."
DOC_CONTAINS = "121 rules -- 15 workflows -- 6 registers -- 6 roles -- 10 attack tests -- 10 bulletproof tests -- 5 historical precedents -- 4-phase legislative roadmap"
DOC_GITHUB   = "github.com/chyrenselin/Satya-Yuga-Bhumi-Trust-DAO"

THREE_DOCS = [
    {"num": "Document 1", "name": "Vishwadharma Granth",
      "desc": "The spiritual foundation -- why land belongs to no single person, why service is the only legitimate form of governance, why truth is the only currency that cannot be stolen.",
      "url":  "https://chyrenselin.github.io/Satya-Yuga-Bhumi-Trust-DAO/vishwadharma/vishwadharma.html"},
    {"num": "Document 2", "name": "Vishwa Samvidhan",
      "desc": "The ethical and constitutional framework -- the rights of Nature (Article 5), governance by truth and subsidiarity (Article 7), economic systems for shared prosperity not accumulation (Article 9).",
      "url":  "https://chyrenselin.github.io/Satya-Yuga-Bhumi-Trust-DAO/vishwasamvidhan/vishwasamvidhan.html"},
    {"num": "Document 3", "name": "Bhumi Trust Blueprint (this document)",
      "desc": "The operational implementation -- what to write, who signs, what happens when someone lies, how disputes are resolved in 7 days.",
      "url":  ""},
]
THREE_DOCS_FOOTER = "The Granth inspires the Samvidhan. The Samvidhan grounds this Blueprint. This Blueprint operationalises what the Samvidhan's Articles 5, 7, and 9 describe in principle."

# =============================================================================
# PART 1 -- WHAT IS THIS SYSTEM
# =============================================================================
PART1_TITLE         = "WHAT IS THIS SYSTEM"
SEC1_TITLE          = "ONE-PAGE SUMMARY"
SEC1_PROBLEM_LABEL  = "THE PROBLEM"
SEC1_PROBLEM        = "Land causes more fights in a village than anything else. Not because land is bad -- because there is no honest system that says: who lives where, what was decided, and who witnessed it. Today: whoever has money buys it, whoever has power grabs it, whoever has a lawyer wins. A farmer who has worked the same land for 40 years has no papers. When he dies, his children fight. A neighbour bribes the officer. A court case runs 20 years. Nobody wins except lawyers."
SEC1_SOLUTION_LABEL = "THE SOLUTION"
SEC1_SOLUTION       = "The Bhumi Trust removes land from ownership. Nobody owns land. The village holds it in trust -- meaning it takes care of it together. People get use-rights: to live on a plot, farm it, build on it. But they cannot sell it, mortgage it, or gamble it away. This is Bhumi Daan -- giving land back to the community."
SEC1_HOW_LABEL      = "HOW IT WORKS"
SEC1_HOW            = "Every plot gets a Plot ID. It is recorded in 6 paper notebooks. Three trained Verifiers physically visit every plot. Two neighbour Witnesses sign. The village votes to confirm. Disputes are heard in 7 days. All decisions are written down, publicly visible, and cannot be secretly changed. Every week, 10% of records are audited. Anyone caught lying gets a 30-day ban."
SEC1_WHY_LABEL      = "WHY IT IS BETTER"
SEC1_WHY            = "No money. No court. No internet. No electricity. No government form. Every decision is made by people who live in the village, about land they can see with their own eyes. It runs on paper, people, and rules -- nothing else. It can start today. It takes 5 people, 6 notebooks, and a pen."
SEC1_CANNOT_LABEL   = "WHAT IT CANNOT DO"
SEC1_CANNOT         = "It cannot override a government title deed in court -- not today. Doing that requires legislation, and legislation takes 15-30 years of documented community operation to earn. This document is that documentation."

SEC2_TITLE              = "FULL EXPLANATION"
SEC2_CORE_IDEA_TITLE    = "2.1 The Core Idea: Land as Trust, Not Property"
SEC2_CORE_IDEA          = "This operational manual is the ground-level implementation of the Vishwa Samvidhan, particularly Article 5 (the intrinsic rights of Nature and land), Article 7 (governance by truth, consent, and subsidiarity -- decisions made at the most local level possible), and Article 9 (economic systems serving shared prosperity, not accumulation). In the current system, land is a commodity. It can be bought, sold, pledged, seized, and stolen. The Bhumi Trust is based on a different idea: land belongs to no single person. It belongs to the community in perpetuity. The community acts as trustee -- it takes care of the land on behalf of everyone, including future generations. Individual families get use-rights: the right to live on a plot, farm it, and pass it to their children. But they cannot sell it, mortgage it, or let it sit unused while others have none. This is not a new idea. Van Panchayats have managed forest land in Uttarakhand since 1931. Community Land Trusts operate in 300+ locations across the USA and UK. The Ejido system protected community land in Mexico for 75 years. The Forest Rights Act 2006 recognised exactly this kind of community land governance in India. The Bhumi Trust builds on all of these."
SEC2_PRINCIPLES_TITLE   = "2.2 The Five Principles"
SEC2_PRINCIPLES = [
    ("Principle 1", "TRANSPARENCY",  "Everything is written. Anyone can read it."),
    ("Principle 2", "VERIFICATION",  "No entry without physical inspection + witnesses."),
    ("Principle 3", "COMMUNITY",     "Every decision is made by the village, not one person."),
    ("Principle 4", "CONTINUITY",    "Records survive floods, fires, and generations."),
    ("Principle 5", "HONESTY",       "The system tells the truth about what it can and cannot do."),
]
SEC2_LAYERS_TITLE  = "2.3 The Seven-Layer Tamper Resistance"
SEC2_LAYERS_INTRO  = "The system is designed so that fraud requires corrupting multiple independent people simultaneously in public:"
SEC2_LAYERS = [
    ("Layer 1", "3 Verifiers must physically visit and sign every plot entry."),
    ("Layer 2", "2 Neighbour Witnesses must walk the boundary and sign."),
    ("Layer 3", "The entire village must vote 60% YES before an entry is Final."),
    ("Layer 4", "10% of all entries are randomly audited every week."),
    ("Layer 5", "An off-site backup copy is maintained and updated monthly."),
    ("Layer 6", "The Integrity Register permanently records all fraud and bans."),
    ("Layer 7", "The Living History Register records institutional memory across generations."),
]
SEC2_LAYERS_FOOTER = "Corrupting this requires bribing or pressuring at least 6 independent people (3 Verifiers + 2 Witnesses + Recorder minimum) at the same time, in public, with witnesses, against a backdrop of weekly audits and a permanent record. This is far harder than bribing one Patwari."

# =============================================================================
# PART 2 -- THE RULES (121 TOTAL)
# =============================================================================
PART2_TITLE = "THE RULES"
PART2_INTRO = "Rules are numbered by family. R- = core rules. Fix-R- = fraud fixes. Protection- = equity protections. Legal- = legal anchoring. Enf- = enforcement. RL- = resident list. Cap- = capture prevention. Cont- = continuity. Econ- = economic. Total: 121 numbered rules across all families."

S3_TITLE  = "CORE NUMBERS"
S3_INTRO  = "These are the numbers the whole system runs on. Memorise these first."
S4_TITLE  = "LAND RULES"
S5_TITLE  = "INTEGRITY RULES"
S6_TITLE  = "INHERITANCE RULES"
S7_TITLE  = "ENFORCEMENT RULES"
S8_TITLE  = "RESIDENT LIST RULES"
S9_TITLE  = "CAPTURE PREVENTION RULES"
S10_TITLE = "CONTINUITY RULES"
S11_TITLE = "ECONOMIC RULES"
S12_TITLE = "PROTECTION RULES"
S12_GENDER_TITLE   = "12.1 Gender Protections"
S12_CASTE_TITLE    = "12.2 Caste and Community Protections"
S12_SEASONAL_TITLE = "12.3 Seasonal and Migrant Protections"
S13_TITLE = "ATTACK FIX RULES"
S13_NOTE  = "These rules were created specifically in response to the 10 attack scenarios tested in Section 17."

RULES_CORE = [
    ('R-01', 'Quorum = 20% of registered residents OR 50 people -- whichever is LESS. (Rationale: "whichever is LESS" would let a 3,000-person village change its rules with just 35 people -- 1.2% of residents. MORE protects large villages while still working for small ones.) Examples: 30 residents -> quorum = 6 (20%) 200 residents -> quorum = 40 (20%) 500 residents -> quorum = 100 (20%) 1,000 residents -> quorum = 200 (20%)'),
    ('R-02', 'Approval = 60% YES vote of those present at quorum'),
    ('R-03', 'Rule Change = 70% YES vote of those present at quorum'),
    ('R-04', 'Verifiers = 3 per village (2 resident local + 1 rotating external)'),
    ('R-05', 'Audit = 10% of all Final entries checked every 7 days (random)'),
    ('R-06', 'Fraud Ban = 30-day ban from all system participation for confirmed fraud'),
    ('R-07', 'Dispute Limit = Maximum 7 days from filing to initial panel decision (Max 14 days if appealed)'),
    ('R-08', 'Use-Right Review = Every 3 years per plot'),
    ('R-09', 'Recorder Term = 12 months, renewable once (24 months total maximum)'),
    ('R-10', 'Council Size = Minimum 7 members, maximum 15 members'),
    ('R-11', 'Vote Notice = Written notice 7 days before any vote, posted in 3 public places'),
    ('R-12', 'Speaker Limit = Maximum 3 minutes per speaker in any meeting'),
    ('R-13', 'Appeal Window = 48 hours after a decision to file a written appeal'),
    ('R-14', 'New Resident Wait = 30 days after registration before voting eligibility'),
    ('R-15', 'Verifier Term = Maximum 3 consecutive months, then 1 month rest before eligible'),
    ('R-16', 'Physical Presence = No Verifier signature without personal physical visit to the plot'),
    ('R-17', 'Post-Vote Appeal = 48-hour window (same as R-13)'),
    ('R-18', 'Illness/Distance = If appellant proves inability to reach in 48 hours (1 witness required): additional 48 hours granted once only'),
    ('R-19', 'Vexatious Dispute = Losing the same case 3 times = 30-day ban on filing that case'),
    ('R-20', 'Land entered in the Trust is permanent. Cannot be removed without 70% village vote.'),
    ('R-21', 'No plot can be sold, mortgaged, or transferred for money -- ever. This rule cannot be changed by any vote.'),
    ('R-22', 'Use-rights pass to family on death. Re-registration required within 90 days of death.'),
    ('R-23', 'Abandoned plot: no steward for 180 days = reverts to Trust. Exception: Seasonal status (see R-30).'),
    ('R-24', 'One family may hold maximum 3 plots simultaneously. Grandfathering clause: Families with more than 3 plots at time of Trust formation have 1 year to register up to 3 plots of their choice. Additional plots beyond 3 remain outside the Trust until one registered plot is vacated. Using Trust legitimacy for 3 plots while maintaining informal control over additional unregistered plots for competitive advantage = fraud (R-06).'),
    ('R-25', 'Boundary change requires new 60% vote + 3 new Verifier signatures.'),
    ('R-26', 'Hand-drawn sketch map required for every plot at time of registration.'),
    ('R-27', 'Minimum 2 permanent landmarks per plot (tree, wall, rock, ditch, road). Wooden stakes are NOT valid primary landmarks.'),
    ('R-28', 'Plot subdivision or merger: separate workflow required (Workflows 8 and 9).'),
    ('R-29', 'Collective land (grazing, ponds, forest, paths): entered in Land Register with Plot Type = "Collective."'),
    ('R-30', 'Seasonal stewards: the 180-day abandonment rule (R-23) does not apply if "Seasonal" status is registered at time of entry.'),
    ('R-31', 'A Verifier may not verify their own land or land of a 2nd-degree family member. 2nd-degree defined as: parents, siblings, children, grandparents, grandchildren, aunts/uncles, nieces/nephews. Not more distant relatives.'),
    ('R-32', "A Council member may not vote on their own or family's land matters."),
    ('R-33', 'The Recorder may not change a Final entry without 3 new Verifier signatures.'),
    ('R-34', 'Two Verifiers colluding in fraud: both 30-day banned, entry cancelled, 3 entirely new Verifiers must re-verify the plot.'),
    ('R-35', 'The Council cannot block a valid dispute from being filed.'),
    ('R-36', 'All residents may inspect any register at any time (with Recorder present).'),
    ('R-37', 'Registers do not leave the village. One backup copy kept separately at all times (temple, school, etc.)'),
    ('R-38', 'Maximum 2 members of one family (within 2nd-degree) may serve on Council simultaneously.'),
    ('R-39', 'Council must maintain minimum 33% women membership over any 5-year period. If it falls below 33%: by-election within 30 days. Enforcement floor: if a by-election produces no women candidates due to social pressure, the Council must invite women from neighbouring villages to serve as temporary external Council members (maximum 2) until a local woman is elected. These temporary members have full voting rights. This rule cannot be waived -- a Council below 33% women with no by-election held is in violation and all its decisions in that period are subject to challenge.'),
    ('R-40', 'No resident may demand another be excluded from any meeting.'),
    ('R-41', 'Threatening another person = immediate 30-day ban + 60% Council vote required for permanent exclusion.'),
    ('R-42', 'Pressuring a Verifier = same penalty as fraud (R-06 + R-41).'),
    ('R-43', 'No entry may become "Pending" without all 3 Verifier signatures and 4 Neighbour Witness signatures. An incomplete entry is void. A Recorder who creates an incomplete entry is immediately removed.'),
    ('R-44', "Re-registration required within 90 days of steward's death."),
    ('R-45', 'Multiple claimants: family decides together, in writing, before the Recorder.'),
    ('R-46', 'If family cannot agree within 30 days: Dispute Workflow (Workflow 5) begins.'),
    ('R-47', "Use-rights acquired in marriage: registered in BOTH spouses' names unless and until they legally separate."),
    ('R-48', 'Minor heir: guardian registered as "Temporary Steward" within 90 days. When minor turns 18: 90 days to re-register in their own name.'),
    ('R-49', 'In inheritance: daughters and sons are equal claimants. No gender preference.'),
    ('R-50', "Spouse protection: if plot is registered in both spouses' names (R-47), surviving spouse automatically becomes sole steward. No family vote required. Re-registration within 90 days."),
]

RULES_FIX = [
    ('Fix-R-02', 'Identity verification = (a) thumbprint match + (b) 2 residents who know the person confirm verbally at time of transaction. On steward\'s death: plot "Suspended" until re-registration (Workflow 6). Confirmed impersonation = 30-day ban + Integrity Register entry + Dispute opened.'),
    ('Fix-R-03', "Resident List is read aloud before voting begins. Any person's eligibility may be challenged before they vote. Challenged person does not vote until Council confirms eligibility. Outsider voter found: entire vote cancelled, redo in 7 days, person who brought outsiders: 30-day ban."),
    ('Fix-R-04', 'Two Verifiers found colluding: both 30-day banned, entry cancelled, 3 entirely new Verifiers (including 1 from neighbouring village) re-verify. Third confirmed collusion in same village: entire Verifier team replaced, neighbouring village team brought in for 60 days.'),
    ('Fix-R-05', 'Boundary markers must be (a) permanent natural feature or (b) concrete/stone marker recorded in the sketch map. Wooden stakes are NOT valid primary markers. Marker found displaced: plot immediately "Suspended," Dispute opened, steward must prove boundary against registered sketch. Deliberate displacement = fraud (R-06).'),
    ('Fix-R-06', 'Maximum 2 family members (2nd-degree) on Council simultaneously. Family relationship declared at election. Found after election: one must resign within 7 days (their choice). Neither resigns: both removed, by-election in 30 days. Council with majority from one caste and bias alleged: neighbouring village joint panel called (Workflow 10).'),
    ('Fix-R-07', 'Backup copy updated monthly. Storage location publicly known to all residents. Deliberate destruction = 30-day ban + 70% Council vote for permanent exclusion. If both copies destroyed: reconstruct per Workflow 11.'),
    ('Fix-R-08', 'Losing the same case 3 times = 30-day ban on filing that case. Panel checks prior Dispute IDs at the start of every hearing. Re-filed case must state what new evidence exists, in writing, at filing. New evidence claim without actual new evidence: dismissed in 15 minutes.'),
    ('Fix-R-09', 'Threatened Verifier reports to Recorder in writing within 24 hours. Integrity Register entry. Council hears within 48 hours. Threat confirmed: 30-day ban + 60% vote for permanent exclusion. Threatened Verifier has option to be removed from that specific case, replaced by an external Verifier with no social connection.'),
    ('Fix-R-10', "Blocking a woman from attending a meeting = same offence as threatening (R-41). Women's signatures equally valid as men's in every register. If Council falls below 33% women: by-election within 30 days. Pressuring a woman not to vote or stand for election = Integrity Register entry."),
]

RULES_ENF = [
    ('Enf-1', 'The Enforcement Ladder (Workflow 14) is sequential. No skipping rungs. Exception: physical threat or destruction of property -- go directly to Rung 5 (legal filing) + notify police immediately.'),
    ('Enf-2', 'Rung 3 (Commons Suspension) requires 60% Council vote. It is not automatic. It is not punishment -- it is the community deciding how to allocate its collective resources.'),
    ('Enf-3', 'A person suspended from commons may appeal to Council in writing. Council hears within 7 days. 60% to overturn.'),
    ('Enf-4', 'Physical violence by anyone is NOT part of this system. Any community member who uses physical force in the name of the Trust: immediate 30-day ban + 60% vote for permanent exclusion. The Trust is never a justification for violence.'),
    ('Enf-5', 'Legal filing (Rung 5) is a community decision -- 60% vote required. Legal aid is free. Village funds nothing. 3 Council members may be authorised to represent the Trust in proceedings.'),
]

RULES_RL = [
    ('RL-1', 'First day of each month: Recorder reviews the Resident List. Checks: deaths notified, departures known, new arrivals.'),
    ('RL-2', 'New resident: person presents to Recorder. 2 existing Active residents vouch. Vouchers sign Resident List entry. Voting eligibility: 30 days after entry.'),
    ('RL-3', "Departure: any resident who knows of a permanent departure tells Recorder within 30 days. 2 residents confirm. Status = Departed. Date recorded. That person's land: open Inheritance or Suspension workflow."),
    ('RL-4', 'Death: family or neighbour notifies Recorder. Status = Deceased. Date recorded. Their land: Workflow 6 (Inheritance) opens automatically.'),
    ('RL-5', 'Minor turns 18: family notifies Recorder. Status changes to Active. Voting eligibility: immediate. Temporary Steward land: 90-day clock starts.'),
    ('RL-6', 'Contested membership: anyone may challenge in writing to Recorder. Council hears within 7 days. Standard: does this person live here? 60% Council vote to confirm or remove Active status. Decision entered in Dispute Register.'),
    ('RL-7', 'Annual full Resident List audit: Council + Recorder visit every household. Confirm: person still lives there, thumbprint matches. All discrepancies resolved before next village meeting.'),
    ('RL-8', 'After annual audit: Recorder writes summary page with counts. All 3 Verifiers sign. This is the annual health check on the entire system.'),
]

CAP1_RED_FLAGS = [
    ("A", "More than 3 disputes filed and not heard within 7 days."),
    ("B", "Same family holds 3 or more Council seats."),
    ("C", "Rotating Verifier has not changed in 2 or more months."),
    ("D", "No audit results recorded for 4 or more weeks."),
    ("E", "New residents cannot get on the Resident List."),
    ("F", "A Dispute filed was rejected without a hearing."),
    ("G", "Council meetings held without required quorum."),
    ("H", "Register not available for inspection when requested."),
]

RULES_CAP = [
    ('Cap-1', 'RED FLAGS -- any 3 of these in the same 6-month period = possible capture: A: More than 3 disputes filed and not heard within 7 days. B: Same family holds 3 or more Council seats. C: Rotating Verifier has not changed in 2 or more months. D: No audit results recorded for 4 or more weeks. E: New residents cannot get on the Resident List. F: A Dispute filed was rejected without a hearing. G: Council meetings held without required quorum. H: Register not available for inspection when requested.'),
    ('Cap-2', 'Any resident observing 3 or more red flags may file a written "Capture Concern" to the Recorder or any Council member. This triggers the Capture Response Protocol (Workflow 15).'),
    ('Cap-3', 'If Recorder is suspected of complicity: Capture Concern goes to any 3 Council members. If Council is entirely compromised: Capture Concern goes to the nearest neighbouring Bhumi Trust.'),
    ('Cap-4', 'Rotating Verifier slot must rotate every 30 days. No exceptions. Recorder logs each rotation in Verification Register. Missed rotation = automatic Red Flag C.'),
    ('Cap-5', 'Council elections: always by secret ballot. No consensus appointment. Every election: names, votes, counts -- all in Voting Register.'),
    ('Cap-6', 'Any resident may inspect any register at any time. Refusal to allow inspection = immediate Red Flag H.'),
    ('Cap-7', 'External inter-village audit: once per year minimum. Neighbouring village Verifiers audit 25% of entries (not just 10%). Written report in Verification Register. This is the annual outside check.'),
    ('Cap-8', 'Rotation immunity: no person who has just completed a Council term may be re-elected for 6 months. Prevents immediate return after term ends.'),
]

RULES_CONT = [
    ('Cont-1', 'Every 2 years: a Youth Apprenticeship of 30 days. Any resident aged 15 to 25 is welcomed. Recorder and one Verifier teach. At end: apprentice signs Living History Register confirming they learned.'),
    ('Cont-2', 'Village keeps a Ready List: names of people who completed the Youth Apprenticeship and are ready to serve as Recorder or Verifier. Minimum target: 5 people on the Ready List at all times.'),
    ('Cont-3', 'When Recorder changes (Workflow 13): New Recorder must be from the Ready List, OR complete 7-day training with outgoing Recorder, OR Council votes 70% to waive in an emergency.'),
    ('Cont-4', 'Every 5 years: a full 2-day System Review meeting. Day 1: review all rules and workflows -- still working? Still relevant? Day 2: review Living History Register, propose changes, vote. Rule changes: 70%. Workflow changes: 60%.'),
    ('Cont-5', 'Five-Year Review findings recorded in full in Living History Register. This is the system updating itself deliberately, not drifting.'),
]

RULES_ECON = [
    ('Econ-1', 'Collective land generates real value: grazing = milk/fertiliser, ponds = fish/water, forests = fuel/fodder/fruit, storage = less waste. This value is allocated by the Trust, not informally or unfairly.'),
    ('Econ-2', 'For each collective plot: Council sets usage rules (60% vote). Rules specify who gets what, in what proportion, and when.'),
    ('Econ-3', 'Labour Exchange Credits: a column in the Resident List tracks how many community work-days each resident has contributed per year. Credits give first-claim priority on collective resources when demand exceeds supply. Credits reset to zero on January 1 each year.'),
    ('Econ-4', 'Commons dividend: if collective land produces surplus, Council decides (60% vote) how to distribute -- equally or weighted by labour credits. All distributions entered in Voting Register.'),
    ('Econ-5', 'Meeting attendance recorded in Voting Register. Residents with attendance below 20% of all meetings in a year: their labour exchange credits do not accumulate for that year. This is a record, not a punishment. The community sees who participates.'),
    ('Econ-6', 'Active stewards (maintain and use their plot productively): automatic use-right renewal at 3-year review, no additional requirements. Unregistered Inactive stewards (absent without Seasonal registration, minimal use): 3-year review triggers a hearing. Registered Seasonal Stewards are strictly protected under Protection-18 and are never subject to this hearing.'),
    ('Econ-7', 'Verifier service: a Verifier who completes a full 3-month term with clean audits is publicly recognised by name in the Living History Register. Permanent positive reputation is a real material benefit in a village.'),
]

RULES_PROT = [
    ('Protection-1', 'Council must maintain minimum 33% women over any 5-year period (R-39).'),
    ('Protection-2', "Plot acquired in marriage: registered in BOTH spouses' names (R-47)."),
    ('Protection-3', 'In inheritance: daughters and sons are equal claimants (R-49).'),
    ('Protection-4', "Women's Witness signatures are fully valid in all registers."),
    ('Protection-5', 'A woman may file her own land claim without male permission.'),
    ('Protection-6', 'A woman may be a sole steward, sole Recorder, sole Verifier -- no male guardian or co-signatory required.'),
    ('Protection-7', 'On separation or divorce: Council decides stewardship based on who actually lives and works on the land -- not gender.'),
    ('Protection-8', 'Blocking any woman from attending a meeting = immediate offence (R-41). Same penalty as making a physical threat.'),
    ('Protection-9', 'Any resident may file a discrimination dispute based on caste, religion, or birth. Filed in Dispute Register. Heard within 7 days.'),
    ('Protection-10', 'In any hearing: at least 1 panel member must not be from the dominant-caste group alleged to be applying pressure.'),
    ('Protection-11', 'All collective land (grazing, ponds, forest) is open to ALL residents regardless of caste, religion, or social status.'),
    ('Protection-12', 'No Council member may prevent any person from being heard at any meeting.'),
    ('Protection-13', 'If entire Council is from one caste and bias is alleged: neighbouring village joint panel is called (Workflow 10).'),
    ('Protection-14', 'All discrimination allegations are entered in the Integrity Register as permanent record, even if not upheld.'),
    ('Protection-15', 'Registered Seasonal Steward is EXEMPT from the 180-day abandonment rule (R-23). Must be registered at time of land entry.'),
    ('Protection-16', 'Seasonal status noted in Land Register: "Seasonal -- used [months], empty [months]."'),
    ('Protection-17', 'Seasonal steward must participate in 3-year use-right review (R-08). They notify Recorder on return to the village.'),
    ('Protection-18', 'If seasonal steward misses 3-year review: Council waits 30 days. If no contact: plot = "Pending Review." NOT cancelled. NOT reallocated without further process.'),
    ('Protection-19', 'Migrant worker: a family member may be registered as "Temporary Manager." That person maintains the plot and represents the absent steward in all procedures until the steward returns.'),
]

RULES_LEGAL = [
    ('Legal-1', 'At first Gram Sabha meeting after Trust formation: present the system formally. Request a resolution: "The Gram Sabha of [Village] recognises the Bhumi Trust Register as a community record." Not legally binding -- but it is a government body acknowledging existence.'),
    ('Legal-2', 'Every Trust vote where 60% or more residents participate should be documented so the Gram Sabha secretary can certify attendance. A certified community vote is evidence in civil court of consensus.'),
    ('Legal-3', 'Submit a copy of every Final Land Register entry to the Gram Panchayat. Request acknowledgement of receipt. Keep the stamp in the Land Register. This creates a paper trail inside the government system itself.'),
    ('Legal-4', 'For every Trust plot: check the state revenue record. Find: Khasra number, Khatauni, currently recorded owner. Enter in Land Register: "Govt. Record: Khasra No. [XXX]."'),
    ('Legal-5', 'Three situations: A. Records match: Trust entry aligns with revenue record. Document this. A matching Trust + Government record is very strong. B. Records differ -- government shows different name, but that person has voluntarily donated (Bhumi Daan): Draft a written statement: "I, [Name], holder of Khasra [XXX], give community use-rights to [Steward Name] under the Bhumi Trust. I do not waive government title. I waive use-rights only." Two Witnesses sign. Panchayat stamp if obtainable. This is a legal private use agreement between two parties. C. Government record shows no private owner'),
    ('Legal-6', 'Forest Rights Act 2006 (FRA): for eligible scheduled tribes and traditional forest dwellers -- check eligibility for Community Forest Rights claims. The Trust Register is exactly the kind of documentation the FRA expects. This can convert Trust entries into legal rights today. Do this immediately for any eligible community.'),
    ('Legal-7', "For any plot that may reach a court, prepare an Evidence Package: Document 1: Land Register entry -- original, with all signatures Document 2: All Verification Register entries for that plot Document 3: The Voting Register entry for that plot's confirmation Document 4: List of all Witnesses who signed, with contact details Document 5: The Boundary Document with all signatures Document 6: Gram Sabha resolution or Panchayat stamp (if obtained) Document 7: Written statements from 10 or more neighbours confirming the boundary as of [date] Document 8: Photographs of landmarks (if a camera was available) A civil court judge seeing 7 or 8 consistent documents, 10 witness statements, and a 3-year audited record will take this seriously. It is not a title deed. It is the strongest community evidence possible."),
    ('Legal-8', 'For every internal hearing: enter the Evidence Package summary in the Dispute Register. Even if resolved internally, the record exists if the case reaches a court later.'),
    ('Legal-9', 'When 10 villages are running the system: Form an inter-village council. Approach the state government with a formal proposal for "Community Land Trust Recognition Rules" under state land law. Precedents exist: Maharashtra (watan lands), Kerala (Kudumbashree), Uttarakhand (Van Panchayats).'),
    ('Legal-10', 'Every Trust register is evidence for this campaign. Well-maintained registers covering 5 or more years of community governance are exactly what a government needs to see before passing enabling legislation.'),
]

ALL_RULES = RULES_CORE + RULES_FIX + RULES_ENF + RULES_RL + RULES_CAP + RULES_CONT + RULES_ECON + RULES_PROT + RULES_LEGAL
assert len(ALL_RULES) == 121, f"RULE COUNT ERROR: expected 121, got {len(ALL_RULES)}"

# =============================================================================
# PART 3 -- THE SIX REGISTERS
# =============================================================================

PART3_TITLE = "THE SIX REGISTERS"
S14_TITLE   = "SIX NOTEBOOKS"
PART3_INTRO = "Six hardcover notebooks. Every entry numbered sequentially. No pages removed ever. Mistakes: crossed out with one line, Recorder's initials beside the crossing. Never erased."

BOUNDARY_DOCUMENT_NOTE = "For every plot, after verification, a one-page Boundary Document is created and folded inside the Land Register. It is the primary document to present in any legal proceeding. Contains: N/S/E/W directions + distance + landmark for each boundary side. Signed by: Steward + Thumbprint, Verifier 1, Verifier 2, Rotating Verifier, and all 4 Neighbours. Indian civil courts take 8 independent signatures seriously as corroborating evidence."

REGISTERS = [
    {
        "num":     '1',
        "name":    'LAND REGISTER (Plot Register)',
        "purpose": 'Master record of every plot in the Trust',
        "fields": [
            ('Plot ID', 'Format: BP-[Village Code]-[3 digits] e.g. BP-RAM-001'),
            ('Entry Date', 'DD/MM/YYYY'),
            ('Location Description', 'Written description: north of X, south of Y, Z metres east of W'),
            ('Area', 'Square metres (measured by rope or counted paces)'),
            ('Landmarks (min. 2)', 'Permanent physical markers -- described in detail'),
            ('Sketch Map', 'Hand-drawn -- in entry or folded on reverse of page'),
            ('Previous Holder', 'Who donated / whose land it was before'),
            ('Current Steward', 'Who holds the use-right now'),
            ('Steward Thumbprint', 'Left thumb ink print'),
            ('Verifier 1', 'Name + Signature + Date'),
            ('Verifier 2', 'Name + Signature + Date'),
            ('Rotating Verifier', 'Name + Signature + Date'),
            ('Neighbour Witness 1', 'Name + Signature (Adjacent plot holder -- North)'),
            ('Neighbour Witness 2', 'Name + Signature (Adjacent plot holder -- South)'),
            ('Neighbour Witness 3', 'Name + Signature (Adjacent plot holder -- East)'),
            ('Neighbour Witness 4', 'Name + Signature (Adjacent plot holder -- West)'),
            ('Vote ID', 'Reference Link to Voting Register entry'),
            ('Status', 'Pending / Final / Suspended / Cancelled'),
            ('Plot Type', 'Individual / Collective / Seasonal'),
            ('Govt. Record Number', 'Khasra / Khatauni number if applicable (optional)'),
            ('Boundary Document Attached?', 'Yes / No'),
        ],
        "example": "Plot ID: BP-RAM-007 | Entry Date: 14/03/2025 | Location: North of Ram Kund Road, south of Sita Well, east of Govind's field (BP-RAM-005), west of forest boundary wall | Area: 1,240 sq metres (5-metre rope, 4 people measuring) | Landmarks: (1) Neem tree, north-east corner, trunk 40 cm diameter (2) Stone boundary wall, southern edge, 22 metres long | Previous Holder: Rameshwar Prasad (voluntary Bhumi Daan) | Current Steward: Rameshwar Prasad | Thumbprint: [Left thumb ink print] | Verifier 1: Sunita Devi -- signed 15/03/2025 | Verifier 2: Harish Kumar -- signed 15/03/2025 | Rotating Verifier: Meena Bai (from Amarpur village) -- signed 16/03/2025 | Vote ID: VR-RAM-019 | Status: Final | Plot Type: Individual | Govt. Record: Khasra No. 447",
    },
    {
        "num":     '2',
        "name":    'VERIFICATION REGISTER (Inspection Register)',
        "purpose": 'Record of every physical audit and inspection',
        "fields": [
            ('Verification ID', 'Format: SP-[Village Code]-[3 digits]'),
            ('Date', 'DD/MM/YYYY'),
            ('Plot ID Inspected', 'Reference from Land Register'),
            ('Type', 'Regular Audit / Complaint Inspection / Re-verification'),
            ('Inspector Name', 'Verifier conducting the check'),
            ('Physical Boundary Match', 'Yes / No -- describe any discrepancy'),
            ('Steward Present and Confirmed', 'Yes / No'),
            ('Landmarks Intact', 'Yes / No'),
            ('Neighbours Confirmed Boundary', 'Yes / No'),
            ('Notes', 'Any observation'),
            ('Result', 'Clear / Discrepancy Found / Fraud Suspected'),
            ('Inspector Signature', 'Signed'),
            ('Action Taken', 'None / Suspended / Council Notified'),
        ],
        "example": 'Verification ID: SP-RAM-031 | Date: 21/03/2025 | Plot ID: BP-RAM-007 | Type: Regular Audit (weekly 10% random check) | Inspector: Meena Bai (Rotating Verifier) | Boundary Match: Yes -- 35m north, 28m east measured, matches register | Steward Present: Yes -- Rameshwar Prasad, thumbprint confirmed | Landmarks Intact: Yes -- Neem tree and stone wall both in place | Result: Clear | Action Taken: None',
    },
    {
        "num":     '3',
        "name":    'VOTING REGISTER (Vote Register)',
        "purpose": 'Record of every vote taken in village meetings',
        "fields": [
            ('Vote ID', 'Format: VR-[Village Code]-[3 digits]'),
            ('Date', 'DD/MM/YYYY'),
            ('Proposal Text', 'Exact wording of what is being voted on'),
            ('Total Registered Residents', 'Taken from current Resident List'),
            ('Required Quorum', 'Calculated per R-01: 20% or 50, whichever is LESS'),
            ('Residents Present', 'Physically counted and named'),
            ('Quorum Met', 'Yes / No'),
            ('YES Votes', 'Number'),
            ('NO Votes', 'Number'),
            ('Abstentions', 'Number'),
            ('Total Cast', 'Must equal Residents Present'),
            ('Required Threshold', '60% or 70% -- state which and why'),
            ('Result', 'Passed / Not Passed'),
            ('Recorder Signature', 'Signed'),
            ('Witness 1', 'Name + Signature'),
            ('Witness 2', 'Name + Signature'),
            ('Challenge Filed Within 48 hrs', 'Yes / No'),
            ('Final Status', 'Confirmed / Overturned / Under Challenge'),
        ],
        "example": 'Vote ID: VR-RAM-019 | Date: 15/03/2025 | Proposal: That plot BP-RAM-007, donated by Rameshwar Prasad, be entered as Final in the Bhumi Trust Land Register. | Registered Residents: 340 | Required Quorum: 50 | Residents Present: 127 | YES Votes: 98 | NO Votes: 21 | Abstentions: 8 | Required Threshold: 60% | Result: PASSED | Final Status: Confirmed',
    },
    {
        "num":     '4',
        "name":    'DISPUTE REGISTER',
        "purpose": 'Record of every dispute from filing to final decision',
        "fields": [
            ('Dispute ID', 'Format: VP-[Village Code]-[3 digits]'),
            ('Date Filed', 'DD/MM/YYYY'),
            ('Claimant Name', 'Person raising the dispute'),
            ('Respondent Name', 'Person the dispute is against'),
            ('Plot ID (if applicable)', 'Reference'),
            ('Type', 'Boundary / Use-Right / Fraud / Identity / Inheritance / Caste / Other'),
            ('Claimant Statement', 'Written or dictated word for word'),
            ('Respondent Statement', 'Written or dictated word for word'),
            ('Evidence Presented', 'Full list: witnesses, documents, maps, objects'),
            ('Hearing Date', 'Must be within 7 days of filing'),
            ('Panel Member 1 (Council)', 'Name -- must not be involved in the case'),
            ('Panel Member 2 (Council)', 'Name -- must not be involved in the case'),
            ('Panel Member 3 (Verifier)', 'Name -- must not have signed the original entry'),
            ('Decision', 'Full decision text -- written, not summarised'),
            ('Decision Date', 'DD/MM/YYYY'),
            ('Appeal Filed', 'Yes / No'),
            ('Appeal Outcome', 'If applicable'),
            ('Prior Disputes (same case)', 'Note if this is 2nd or 3rd filing of same case'),
            ('All Three Panel Signatures', 'Signed'),
        ],
        "example": 'Dispute ID: VP-RAM-004 | Date Filed: 02/04/2025 | Claimant: Vishnu Pandey | Respondent: Rameshwar Prasad | Plot ID: BP-RAM-007 | Type: Boundary | Decision: The panel finds that the boundary of BP-RAM-007 was correctly measured, witnessed by 2 neighbours, and verified by 3 Verifiers on 15/03/2025. Dispute rejected. Boundary stands as registered.',
    },
    {
        "num":     '5',
        "name":    'INTEGRITY REGISTER (Honesty Register)',
        "purpose": 'Permanent record of all fraud, threats, bans, and violations. NEVER destroyed.',
        "fields": [
            ('Incident ID', 'Format: IP-[Village Code]-[3 digits]'),
            ('Date', 'DD/MM/YYYY'),
            ('Person(s) Involved', 'Full names'),
            ('Allegation', 'Fraud / Collusion / Threat / Ban Violation / Discrimination'),
            ('Evidence Summary', 'Brief list'),
            ('Council Decision', 'Confirmed / Rejected'),
            ('Penalty Imposed', 'Ban duration / Permanent exclusion / None'),
            ('Ban Start Date', 'DD/MM/YYYY'),
            ('Ban End Date', 'DD/MM/YYYY'),
            ('Three Council Signatures', 'Signed'),
        ],
        "example": '',
    },
    {
        "num":     '6',
        "name":    'LIVING HISTORY REGISTER',
        "purpose": 'Institutional memory. Stories, decisions, attacks tried, lessons learned. Not a legal record. Not operational.',
        "fields": [
            ('Who writes', 'Any Council member or Recorder, at any time'),
            ('Format', "Date. Writer's name. What they are recording. Their signature."),
            ('What to write', 'Why each rule was created / First time someone tried to bribe a Verifier / Floods that destroyed landmarks / Which families tried to manipulate elections / Youth Apprentice learnings / Five-Year Review findings / Any event the village should remember in 50 years'),
        ],
        "example": 'Date: 17/03/2025 | Writer: Sunita Devi (Council Member) | Entry: We added R-38 (maximum 2 family members on Council) because in the first month, the Sharma family proposed 4 of their relatives for the 7-seat Council. Nobody objected openly because of caste pressure. Meena Bai (rotating Verifier from Amarpur) pointed out the pattern. We voted R-38 immediately. This is why that rule exists.',
    },
]

# =============================================================================
# PART 4 -- THE SIX ROLES
# =============================================================================

PART4_TITLE = "THE SIX ROLES"
S15_TITLE   = "WHAT EACH ROLE DOES AND CANNOT DO"
VERIFIER_ROTATING_NOTE = "One of the 3 Verifier slots rotates every 30 days. Priority: from a neighbouring village. This guarantees an outside perspective in every audit. Startup Phase (Years 1-2): Full external rotation becomes mandatory as soon as one neighbouring village adopts the system. The Startup Phase cannot extend beyond 24 months."

ROLES = [
    {
        "name":   'RESIDENT',
        "who":    'Every person registered on the Resident List.',
        "do": [
            'Donate land to the Trust (Bhumi Daan)',
            'Attend village meetings and vote',
            'Submit written proposals to the Recorder',
            'File disputes about any land matter',
            "Serve as Witness for other residents' transactions",
            'Request to inspect any register at any time',
            'Challenge a vote result within 48 hours',
            'File a Capture Concern if they observe 3 or more red flags (Cap-1)',
        ],
        "cannot": [
            'Verify their own land or serve as a Verifier for their 2nd-degree family',
            'Serve as Witness in their own land transactions',
            'Vote while under a 30-day ban',
            'Vote before 30 days of registration on the Resident List',
            'Serve on a dispute panel in a case where they are a claimant or respondent',
        ],
    },
    {
        "name":   'VERIFIER',
        "who":    '3 trained, certified residents. 2 resident local + 1 rotating external.',
        "do": [
            'Physically inspect land before any registration -- no exceptions',
            'Measure boundaries by rope or calibrated paces',
            'Record landmarks, draw sketch maps, complete the Verification Register',
            'Sign Land Register entries after physical inspection',
            'Conduct the weekly 10% random audit',
            'Report discrepancies to Council in writing within 24 hours',
            'Sit on dispute panels (only if they did NOT sign the original entry)',
        ],
        "cannot": [
            'Verify their own land (R-31)',
            "Verify 2nd-degree family members' land (R-31)",
            'Serve simultaneously as a Council member',
            'Serve more than 3 consecutive months without 1 month rest (R-15)',
            'Sign any entry without personally visiting the physical plot (R-16)',
            'Make land decisions alone -- verification is fact-finding only',
            'Write in the registers -- only the Recorder writes',
        ],
    },
    {
        "name":   'COUNCIL',
        "who":    'Elected by the village. Minimum 33% women at all times.',
        "do": [
            'Hear vote results and confirm land entries after 60% YES vote',
            'Hear dispute appeals and decide (60% needed to overturn)',
            'Change rules (70% vote required)',
            'Remove Verifiers or Recorder for cause (60% vote, stated reason)',
            'Investigate discrepancies flagged by Verifiers',
            'Call emergency meetings when fraud is suspected',
            'Update Resident List monthly',
            'Appoint rotating Verifier when external candidate is not available',
            'Manage collective resource allocation (Econ-1 through Econ-7)',
        ],
        "cannot": [
            "Vote on their own or family's land matters (R-32)",
            'Make any decision without quorum (R-01)',
            'Block any resident from filing a dispute (R-35)',
            'Write in any register -- only the Recorder writes',
            'Hold 3 or more members from one family simultaneously (R-38)',
            'Refuse any resident access to inspect registers (R-36)',
            'Operate below 33% women membership without calling a by-election (R-39)',
        ],
    },
    {
        "name":   'RECORDER',
        "who":    'One trained, certified resident. Maximum 24 months total service.',
        "do": [
            'Maintain all 6 registers -- physically write all entries',
            'Assign Plot IDs, Dispute IDs, Vote IDs, Verification IDs, Incident IDs',
            'Write statements for residents who cannot write',
            'Post meeting notices at 3 public locations with 7-day notice',
            'Count voters and confirm quorum at every meeting',
            'Keep time at meetings (3-minute speaker rule)',
            'Write monthly 1-page activity summary',
            'Keep off-site backup copy updated every month',
            'Train the Deputy Recorder',
            'Maintain the Resident List with monthly updates (RL-1)',
            'Track Labour Exchange Credits in Resident List (Econ-3)',
        ],
        "cannot": [
            'Change a Final entry without 3 new Verifier signatures (R-33)',
            'Vote in a meeting they are recording',
            'Simultaneously serve as Verifier or Council member',
            "Reject a resident's proposal -- only Council can reject",
            "Refuse any resident's request to inspect registers",
            'Serve more than 24 months total (R-09)',
        ],
    },
    {
        "name":   'DEPUTY RECORDER',
        "who":    'A trained backup. Must not be a family member of the Recorder.',
        "do": [
            'Receive ongoing training from the Recorder',
            'Take over fully when Recorder is absent for 7 or more days',
            'Mark all entries made during absence with "DR-" prefix',
            'Present all DR- entries to returning Recorder for review',
        ],
        "cannot": [
            'Act while the Recorder is present (except during training)',
            'Be from the same 2nd-degree family as the Recorder',
        ],
    },
    {
        "name":   'WITNESS',
        "who":    'Any eligible resident who personally observed what they are witnessing.',
        "do": [
            'Personally observe the event or boundary they are witnessing',
            'Walk the land boundary and physically confirm it where relevant',
            'Sign the relevant register entry',
        ],
        "cannot": [
            'Witness their own land transactions',
            "Witness 2nd-degree family members' transactions",
            'Sign without being physically present at the event',
            'Give retroactive testimony for events they did not personally observe 14',
        ],
    },
]

# =============================================================================
# PART 5 -- ALL 15 WORKFLOWS
# =============================================================================

PART5_TITLE = "ALL 15 WORKFLOWS"
S16_TITLE   = "ALL 15 WORKFLOWS"

WORKFLOWS = [
    {
        "num":   '1',
        "title": 'BOOTSTRAP -- Starting the System on Day 1',
        "use":   'this when a village is starting the Bhumi Trust for the first time.',
        "steps": [
            ('1', 'At least 7 interested residents call an open meeting. Post notice 7 days ahead at 3 public places in the village. Notice text: "Meeting to start Bhumi Trust. Everyone welcome. Anyone can vote."'),
            ('2', 'At meeting: single YES/NO vote -- shall we start this system? Special first-meeting quorum: 20 people present. (Normal quorum uses the Resident List, which does not exist yet.) If YES: continue to Step 3. If NO: discuss again in 30 days. Any resident may call next meeting.'),
            ('3', 'Appoint a Temporary Recorder (willing, able to write clearly). Serves for the first 30 days only. Obtain 6 hardcover notebooks immediately. Write on first page of each notebook: "This is the [Village Name] Bhumi Trust [Register Name]. Started: [Date]. Temporary Recorder: [Name]." Label each: Notebook 1 = Land Register Notebook 2 = Verification Register Notebook 3 = Voting Register Notebook 4 = Dispute Register Notebook 5 = Integrity Register Notebook 6 = Living History Register'),
            ('4', 'Appoint 3 Temporary Verifiers by show of hands. Requirements: resident for 1 or more years, known as honest. Priority for one slot: from a neighbouring village if possible.'),
            ('5', 'Build the Resident List (first page of Voting Register or separate sheet). Every person present: name, age, home location, thumbprint. Over the next 7 days: Recorder goes door to door to register all residents.'),
            ('6', 'Council Election. Nominate 7 to 15 people. Anyone may nominate anyone. Present residents vote. Top vote-getters join Council. Minimum 3 women required on Council from the start. If fewer than 2 women elected: the woman with next highest votes is added until minimum is met.'),
            ('7', 'Council holds first formal meeting. Confirms permanent Recorder (60% vote). Confirms permanent Verifiers (60% vote). Sets the village code: 3 letters, e.g. RAM, SIT, GOV. Designates 3 permanent public notice locations. Designates off-site backup copy storage location. Appoints a Deputy Recorder.'),
            ('8', 'First Bhumi Daan -- the practice entry. Register one plot (collective land, or a willing donor). Complete every step of Workflow 2 fully. The whole team learns the system by doing it once together. Any errors found in the practice entry are corrected and noted in the Living History Register.'),
            ('9', '30 days after startup: first review meeting. Review: what happened in the first 30 days? Any confusion? Any rules that need adjusting? Rule adjustments: 70% vote required. Confirm Temporary Recorder as Permanent (60% vote). System is now fully operational.'),
        ],
    },
    {
        "num":   '2',
        "title": 'BHUMI DAAN -- Adding Land to the Trust',
        "use":   'this when a resident wants to donate their land to the Trust.',
        "steps": [
            ('1', 'Donor comes to Recorder and states: "I want to give my land [description] to the Bhumi Trust." If donor cannot write: Recorder writes the statement, donor thumbprints it.'),
            ('2', "Recorder assigns the next Plot ID from the Land Register. 15 Opens new entry. Writes today's date. Status = Pending. Notifies all 3 Verifiers in writing within 48 hours."),
            ('3', 'All 3 Verifiers visit the plot together within 7 days. They must visit together -- not separately. Measure all 4 boundaries by rope or calibrated paces. Identify and record minimum 2 permanent landmarks in detail. Draw a sketch map showing all 4 boundaries and landmarks.'),
            ('4', 'Identify the 4 nearest neighbour plot-holders (North, South, East, West). Walk the full boundary with each neighbour. All 4 sign the Land Register entry as Witnesses. IF a neighbour refuses to sign: Recorder notes the reason in writing. Council votes (60%) whether to proceed without that signature. The refusal itself is opened as an entry in the Dispute Register.'),
            ('5', 'Create the Boundary Document (see Section 14). Collect all signatures: steward, 3 Verifiers, up to 4 neighbours. Fold and attach inside the Land Register entry. Seek Panchayat stamp if possible (Legal-3).'),
            ('6', 'Post vote notice at 3 public locations. Vote date: minimum 7 days after posting. Notice states: Plot ID, location description, steward name, vote date.'),
            ('7', 'Village votes. 60% YES of those present at quorum. All results recorded in Voting Register.'),
            ('8A', 'Vote PASSES: Status = Final. All fields must be complete. Entry cannot be Final with any blank. Recorder cross-references Vote ID in Land Register.'),
            ('8B', 'Vote FAILS: Status = Cancelled. Entry stays in register with all information intact. Never erased. Donor may reapply after 30 days if circumstances change.'),
        ],
    },
    {
        "num":   '3',
        "title": 'WEEKLY AUDIT',
        "use":   'every Monday (or fixed village audit day) without exception.',
        "steps": [
            ('1', 'Recorder randomly selects 10% of all Final entries. 50 Final plots = select 5 this week. Selection method: number all Plot IDs on paper strips, fold and draw blindly in front of one witness. Record which plots were selected in Verification Register.'),
            ('2', "Rotating Verifier (the external one) performs this audit. This person must NOT audit plots they originally verified. If conflict: one of the permanent Verifiers conducts that plot's audit."),
            ('3', 'For each selected plot, physically visit: Check boundaries match the sketch map dimensions. Check both landmarks are intact and undisturbed. Check steward is present or accounted for. Ask at least one neighbour to confirm the boundary verbally. Record all findings in Verification Register with Verification ID.'),
            ('4A', 'Result = Clear: Sign the entry. Done for this plot.'),
            ('4B', 'Discrepancy found: write "Suspended" in Land Register status. Notify all 3 Verifiers and Council in writing within 24 hours. Council investigates within 7 days (Dispute Workflow begins). Step 4C Fraud suspected: immediately write "Suspended" in Land Register. Notify all 3 Verifiers and Council the same day. Suspected party gets immediate 30-day ban (R-06). Open Dispute Register entry (Workflow 5 begins).'),
        ],
    },
    {
        "num":   '4',
        "title": 'VOTING',
        "use":   'for any village decision -- land, rules, Council, or proposals.',
        "steps": [
            ('1', 'Any registered resident submits a written proposal to the Recorder. Those who cannot write may dictate. Recorder writes, person thumbprints. Proposal must state: what is to be decided, and why. Recorder CANNOT reject a proposal. Only Council can reject, at Step 2.'),
            ('2', 'Recorder checks: regular matter = 60% threshold. Rule change = 70% threshold. Council reviews within 7 days. May reject if proposal is duplicate, outside system scope, or procedurally invalid -- written reason required.'),
            ('3', 'Recorder writes the notice. Posts at 3 designated public locations. 16 Vote date must be minimum 7 days after posting. Notice contains: full proposal text, date, time, location, threshold.'),
            ('4', 'On vote day: Recorder opens Voting Register. Records total registered residents from current Resident List. Calculates quorum: 20% of residents or 50, whichever is MORE. Counts those physically present.'),
            ('5', 'Quorum NOT met: do not vote. Record in Voting Register: date, proposal, quorum required, count present. Reschedule within 7 days. If quorum fails twice in a row: The proposal is automatically abandoned. The core quorum requirement (R-01) can NEVER be bypassed by the Council.'),
            ('6', 'Quorum met: Recorder reads proposal aloud twice. Open discussion period. Each speaker: maximum 3 minutes. Designated Timekeeper stands at 3 minutes. Recorder stops writing. Discussion closes when no more speakers.'),
            ('7', 'Before voting: decide by show of hands whether vote will be: Open: raise hands. Secret: paper slips. Either choice is valid. Secret ballot preferred for sensitive matters.'),
            ('8', 'Open vote: Recorder counts raised hands. 2 Witnesses confirm. Secret vote: Recorder distributes slips. Each writes YES / NO / ABSTAIN. Slips collected in a container. 2 Witnesses count together, not Recorder.'),
            ('9', 'Result announced. All numbers entered in Voting Register. Both Witnesses sign. Recorder signs. Total cast must equal count present.'),
            ('10', '48-hour challenge window begins immediately. Any resident may challenge in writing on grounds of: procedural error, ineligible voter, or proven coercion. No challenge filed: result = Confirmed. Challenge filed: Council hears within 48 hours.'),
        ],
    },
    {
        "num":   '5',
        "title": 'DISPUTE RESOLUTION',
        "use":   'for any land dispute -- boundary, use-right, fraud, identity, inheritance.',
        "steps": [
            ('1', 'Any resident files a dispute. Go to Recorder. Give statement orally or in writing. Recorder opens Dispute Register. Assigns Dispute ID. Records claimant statement word for word. No summary. No editing.'),
            ('2', 'Recorder notifies respondent in writing within 24 hours. Respondent has 48 hours to give a written or dictated statement. Refusal to respond: dispute proceeds without their statement. The refusal itself is recorded in the Dispute Register.'),
            ('3', 'Recorder schedules hearing within 7 days of filing (R-07). Assembles 3-person panel: 2 Council members not involved in the case 1 Verifier who did NOT sign the original entry If insufficient neutral Council members: invite from neighbouring village (Workflow 10 inter-village protocol).'),
            ('4', 'Both parties gather evidence before the hearing: • Witnesses (people who saw relevant events) -- Documents (maps, letters, prior register entries) -- Physical evidence (objects, photographs) Recorder lists all evidence in the Dispute Register before hearing starts.'),
            ('5', "Hearing is held in the open. Any resident may observe. No one may be excluded from observing. Order: A. Recorder reads Dispute ID and both statements aloud. B. Claimant presents -- maximum 15 minutes. C. Respondent presents -- maximum 15 minutes. D. Both may question each other's witnesses -- 3 min per question set. E. Panel asks its own questions -- no time limit. F. Closing statements -- 3 minutes each."),
            ('6', 'Panel deliberates privately. Maximum 2 hours. No deadlock -- 2-to-1 majority decides. Decision is written in full. All 3 panel members sign.'),
            ('7', 'Panel returns. Decision read aloud to everyone present. 17 Full decision text entered in Dispute Register by Recorder. Recorder signs as witness to the reading.'),
            ('8', '48-hour appeal window begins (R-13). Losing party may file written appeal to Recorder. Valid grounds only: new evidence unavailable at the hearing, or clear procedural error made during the hearing. "I disagree with the decision" is NOT valid grounds for appeal.'),
            ('9', 'Appeal filed: Full Council hears within 5 days. Reviews Dispute Register entry -- original decision and all evidence. 60% Council vote needed to overturn the original decision. This Council decision is final. No further appeal exists.'),
            ('10', 'Recorder updates all affected entries: Land Register status, Verification Register, cross-references. Fraud confirmed: 30-day ban entered in Integrity Register immediately. Enforcement Ladder (Workflow 14) begins if non-compliance follows.'),
        ],
    },
    {
        "num":   '6',
        "title": 'INHERITANCE -- Death of Steward',
        "use":   '',
        "steps": [
            ('1', 'On death: family notifies Recorder within 7 days. If family does not notify: any neighbour or resident may. Recorder changes steward status in Land Register to "Suspended." Note: "Steward [Name] deceased [Date]."'),
            ('2', 'Family appears before Council within 30 days. They state: who is the heir or heirs? Are they in agreement? Case A -- One heir, everyone agrees: Go directly to Step 4. Case B -- Multiple heirs, everyone agrees: Family decides: single steward or collective stewardship. If collective: all names entered. Plot remains undivided. Go to Step 4. Case C -- Multiple heirs, disagreement: 30 days for family to reach agreement privately. If no agreement after 30 days: proceed to Step 3.'),
            ('3', 'Inheritance Dispute: Enter in Dispute Register. Type = "Inheritance." All claimants present case and evidence to 3-person panel. Panel considers: What did the deceased say? (witnesses required) Who actually worked the land? What is the family tradition? Are there children? Daughters and sons are equal (R-49). Panel decides: single steward or collective stewardship.'),
            ('4', 'Re-registration within 90 days of death: New steward name, thumbprint, signature entered in Land Register. "Previous Steward" field: deceased\'s name entered. All 3 Verifiers physically visit the plot and re-sign. Village meeting informed. Undisputed inheritance: no vote needed. Disputed inheritance resolved by panel: 60% village vote required.'),
            ('5', 'Minor heir: Guardian registered as "Temporary Steward" within 90 days. Land Register notes: "Temporary Steward -- [Name], until [minor\'s name] turns 18." When minor turns 18: 90-day clock to re-register in own name.'),
            ('6', "Spouse protection: If plot was registered in both spouses' names (R-47): surviving spouse automatically becomes sole steward. No family vote required. Re-registration within 90 days, same as Case A above."),
        ],
    },
    {
        "num":   '7',
        "title": 'COLLECTIVE LAND -- Grazing, Ponds, Forest, Paths',
        "use":   'for all land that belongs to the whole community.',
        "steps": [
            ('1', 'Identify all collective village land: Grazing land (gochar), ponds and wells, forest and tree land, public paths and roads, cremation/burial grounds, other shared land.'),
            ('2', 'Enter each in Land Register with Plot Type = "Collective." Steward = "Village Bhumi Trust -- Collective." Enter usage rules in Location Description field: "Grazing: equal rights for all registered livestock keepers." "Pond: all residents 18 have right to water. Fishing: Council permission."'),
            ('3', 'No individual may claim ownership of collective land -- ever. Any such claim: immediate Dispute Workflow, hearing within 5 days.'),
            ('4', 'Collective land is managed by Council under community decision. Every 3 years: usage rules reviewed by village vote (60% to change).'),
            ('5', 'No permanent individual structures on collective land. Temporary structures (market stalls, shade shelters) allowed with 60% Council vote. Must be removed within 90 days.'),
            ('6', 'Collective land generates value -- managed per Econ-1 through Econ-4. Labour exchange credits apply to collective land maintenance work.'),
        ],
    },
    {
        "num":   '8',
        "title": 'PLOT SUBDIVISION',
        "use":   'when a steward wants to divide one plot into two or more smaller plots.',
        "steps": [
            ('1', 'Steward submits written application to Recorder: "I want to divide plot [BP-XXX-YYY] into [number] portions." States the reason.'),
            ('2', 'Recorder checks: Will each new portion be at least 200 sq metres? (Village may change the minimum by 70% rule-change vote -- but cannot go below 100 sq m.) Will any family exceed 3 plots after division? (R-24) If either check fails: application rejected. Recorder states reason in writing.'),
            ('3', 'All 3 Verifiers measure the new boundary lines together. New sketch maps drawn -- one per new plot. Minimum 2 landmarks identified per new plot.'),
            ('4', '2 neighbour witnesses for each new plot boundary. Total minimum: 4 neighbour signatures.'),
            ('5', 'Create new Boundary Documents for each new plot.'),
            ('6', 'Original plot entry: note "Divided -- see [new Plot IDs]." Status = Cancelled. 2 new plot entries created with next available Plot IDs. Both entries: Status = Pending.'),
            ('7', 'Village vote. 60% YES needed. Passed: both new entries become Final. Not passed: original plot stays Final, division abandoned, both Pending entries marked Cancelled.'),
        ],
    },
    {
        "num":   '9',
        "title": 'PLOT MERGER',
        "use":   'when two stewards want to combine adjacent plots into one.',
        "steps": [
            ('1', 'Both stewards submit joint written application to Recorder: "We want to merge plots [BP-XXX-YYY] and [BP-XXX-ZZZ] into one plot."'),
            ('2', 'Recorder checks: Are both plots physically adjacent (sharing a boundary)? Will the merged plot keep both families within the 3-plot limit? (R-24) If either check fails: application rejected with written reason.'),
            ('3', 'All 3 Verifiers measure the new combined boundary together. One new sketch map drawn for the entire merged plot. Minimum 2 landmarks confirmed for the merged boundary.'),
            ('4', 'Neighbour witnesses: 2 from each original plot = minimum 4 signatures.'),
            ('5', 'New Boundary Document created for the merged plot.'),
            ('6', 'Both original entries: marked "Cancelled -- Merged, see [new Plot ID]." One new entry created with next available Plot ID. Status = Pending.'),
            ('7', 'Village vote. 60% YES needed. Passed: new entry becomes Final. Not passed: both originals restored to Final. Pending entry Cancelled. 19'),
        ],
    },
    {
        "num":   '10',
        "title": 'INTER-VILLAGE DISPUTE',
        "use":   'when a boundary or land dispute crosses the boundary of two separate villages.',
        "steps": [
            ('1', 'The resident who discovers the dispute notifies their own Recorder first. That Recorder notifies the other village\'s Recorder in writing within 7 days. Both villages enter the dispute in their own Dispute Registers. Both affected plots: Status = "Suspended" in both Land Registers.'),
            ('2', "Both Councils call a joint meeting. Location: neutral ground -- not in either village. (A road between villages, a field, or a third village's space.) 7-day notice posted in both villages."),
            ('3', 'Assemble joint panel: 2 Council members from Village A (not involved in the case) 2 Council members from Village B (not involved in the case) 1 neutral person from a third, unrelated village Total: 5 panel members. Decision requires 3 of 5 to agree.'),
            ('4', "Both villages' Verifiers visit the disputed boundary together. Measure, draw sketch, review both villages' Land Register entries. Write a joint physical inspection report -- signed by all present."),
            ('5', "Joint panel holds hearing in open meeting. Both parties present. All residents from both villages may observe. Decision: 3 of 5 panel members must agree. Decision entered in BOTH villages' Dispute Registers."),
            ('6', 'The joint panel decision is binding. Both Councils must implement it without a secondary vote. Both Land Registers updated to reflect the decision. If one village refuses to accept: their plot remains " Suspended" until agreement is reached. The other village\'s plot is resolved.'),
            ('7', 'If both villages have a signed Inter-Village Agreement (Section 25): this workflow is binding. If not: either village may file in civil court.'),
        ],
    },
    {
        "num":   '11',
        "title": 'DISASTER RECOVERY',
        "use":   'after flood, fire, earthquake, or displacement destroys village records.',
        "steps": [
            ('1', 'Within 30 days after the disaster: All surviving Verifiers, Council members, and Recorder gather. Check: does the off-site backup copy survive? Backup survives: go to Step 3. Both copies destroyed: go to Step 2.'),
            ('2', 'Reconstruction from memory (both copies lost): Every surviving Verifier verbally recalls every plot they physically visited. Every neighbour recalls where their boundaries were. All recalled entries recorded as "Reconstructed -- Disaster [Date]." Status = "Pending Confirmation" until physically re-verified.'),
            ('3', 'Transcribe from the surviving backup copy into new notebooks. Every transcribed entry noted: "Transcribed [Date] -- [Reason]." Buy 6 new notebooks. Label them the same as the originals.'),
            ('4', 'Within 90 days: physically re-verify all "Final" plots. Landmarks may have changed after disaster -- identify new ones. Draw new sketch maps. Note old and new landmarks both. The 180-day abandonment rule (R-23) is suspended for the disaster year by 70% village vote.'),
            ('5', "Invite Verifiers from at least one neighbouring village. They independently verify the reconstructed records. Their signed report entered in both villages' Verification Registers."),
            ('6', 'Mass displacement (whole village moved): 180-day limit extended to 2 years by 70% Council vote. Re-registration deadlines extended proportionally. First village meeting after return: review all suspended entries.'),
        ],
    },
    {
        "num":   '12',
        "title": 'EXIT -- Dissolving the Trust',
        "use":   'if the system fails, is captured, or the village chooses to close it.',
        "steps": [
            ('1', 'Any 30 registered residents (or 20%, whichever is greater) may submit a written "Proposal to End the System" to the Recorder. Proposal must state specific reasons. Recorder posts as a vote notice. Standard 7-day notice required.'),
            ('2', 'Village votes. 70% YES required -- the strictest threshold. If not reached: proposal rejected. May be resubmitted after 90 days.'),
            ('3', 'If 70% passes: First 30 days: all 6 registers placed in neutral custody. (School, temple, or neighbouring village -- residents decide by 60% vote.) Every steward family receives a written copy of their own Plot ID entry. All active entries stamped: "System Paused [Date]."'),
            ('4', 'Days 30 to 90: village decides next step. Option A: Restart under new leadership -- run Workflow 1 again. Option B: Transition to another community governance system. Option C: Transfer records to government land authority. 60% vote for whichever option is chosen.'),
            ('5', 'Registers are NEVER destroyed -- under any option chosen. They are historical records. They go into permanent village archive. Any family may request a copy of their own entry at any time, forever. The Integrity Register is especially permanent -- it records history.'),
        ],
    },
    {
        "num":   '13',
        "title": 'RECORDER HANDOVER',
        "use":   "when a Recorder's term ends or when they cannot continue.",
        "steps": [
            ('1', '30 days before term end: Council nominates new Recorder candidates. New Recorder must be from the Ready List (Cont-2) if one exists. 60% vote to confirm the new Recorder.'),
            ('2', '7-day overlap period: outgoing and incoming Recorder work together. Outgoing shows: last entry in every notebook, all pending work, all suspended plots, all open disputes, backup copy location, Deputy Recorder identity.'),
            ('3', '3 Council members inspect every notebook: Confirm last entry is complete, no blank fields in Final entries, no unsigned entries, backup copy matches main register. Each notebook gets a handover entry: "Recorder Transfer [Date]: [Old Name] to [New Name]."'),
            ('4', 'Handover document signed by: New Recorder [signature] Outgoing Recorder [signature] All 3 inspecting Council members [signatures] This is the permanent handover record.'),
            ('5', 'First entry by new Recorder: signed with name + date. Living History Register: outgoing Recorder writes what they learned, what problems occurred, what the next Recorder should know.'),
        ],
    },
    {
        "num":   '14',
        "title": 'ENFORCEMENT LADDER -- When a Decision is Ignored',
        "use":   'when a party refuses to comply with a confirmed Trust decision.',
        "steps": [
            ('1', 'After decision (Workflow 5): violating party does not comply. Recorder notes non-compliance in Dispute Register. Date of non-compliance entered.'),
            ('2', 'RUNG 1 -- Formal Notice (Day 1 to 7): Recorder drafts a Formal Notice. 3 Council members review and sign. All 3 Verifiers sign. 2 Witnesses deliver to violating party personally. Notice states: the decision, the deadline (7 days), the consequences. Violating party signs "Notice Received." If they refuse to sign: 2 Witnesses certify in writing: "Notice delivered on [Date], recipient refused to sign." All entered in Integrity Register.'),
            ('3', 'After 7 days: 21 Complied: Dispute Register entry "Resolved -- complied [Date]." Done. Not complied: proceed to Rung 2.'),
            ('4', 'RUNG 2 -- Community Declaration (Day 8 to 14): Village meeting. 7-day notice still required. 60% vote: "This person is in violation of Trust decision [ID]." Integrity Register: "Declared in violation as of [Date]." This is permanent public record.'),
            ('5', 'RUNG 3 -- Commons Suspension (Day 15 to 60): 60% Council vote required. Violating person loses access to Trust-managed collective resources: grazing rights, pond/water access, collective labour participation, community grain/seed stores if any. Notified in writing. Duration: until compliance or 60 days, whichever first. This is economic pressure without any physical element.'),
            ('6', "After 60 days of Commons Suspension, still non-compliant: RUNG 4 Inter-Village Broadcast (Day 76 to 90): Notify all neighbouring Bhumi Trust villages in writing. Share the Integrity Register entry and the decision. Violating person's standing in all inter-village exchanges suspended. This is social pressure beyond the village."),
            ('7', 'RUNG 5 -- Formal Legal Filing (Day 91 onwards): 60% village vote to proceed. File with: Gram Sabha (under panchayat law), civil court, or District Legal Services Authority (DLSA -- free in all districts). Evidence Package (Section 26, Legal-7) prepared by Recorder. 3 Council members authorised as community representatives. All filings and dates entered in Dispute Register.'),
        ],
    },
    {
        "num":   '15',
        "title": 'CAPTURE RESPONSE -- When the System Is Captured',
        "use":   'when 3 or more Red Flags (Cap-1) appear in the same 6-month period.',
        "steps": [
            ('1', 'Any resident files written "Capture Concern" to Recorder or Council member. Must state: which Red Flags observed, dates, specific evidence. If Recorder is suspected: Capture Concern goes to any 3 Council members. If Council is entirely compromised: goes to neighbouring Bhumi Trust.'),
            ('2', '3 non-suspected Council members acknowledge the Concern in writing. If all Council suspected: request oversight from neighbouring Trust.'),
            ('3', "STAGE 1 -- Internal Audit (Days 1 to 14): 3 non-suspected Council members review all 6 registers independently. Looking for: unsigned entries, skipped audits, blocked disputes, pattern of one family's plots always passing, refused inspections. Written report in 14 days."),
            ('4', 'STAGE 2 -- External Audit (Days 15 to 28): Invite Verifiers from minimum 2 different neighbouring villages. They re-audit 100% of all Final entries -- not the usual 10%. Their full findings entered in Verification Register. This is the independent evidence base.'),
            ('5', 'STAGE 3 -- Open Village Meeting (Days 29 to 35): Both audit reports read aloud to all residents. All 6 registers open for any resident to inspect. Any resident may speak -- 3-minute limit. No suspected Council member may chair. Chair = senior external Verifier.'),
            ('6', 'STAGE 4 -- Reform Vote (Days 36 to 42): Secret ballot -- always, for every person voted on. Vote individually on each suspected person: 60% YES to remove each Council member. 60% YES to remove the Recorder. 60% YES to remove any Verifier. 60% YES to appoint emergency replacements. Emergency appointees serve maximum 90 days.'),
            ('7', 'STAGE 5 -- Remediation (Days 43 to 120): 22 Entirely new Verifier team re-verifies all flagged entries. All blocked disputes re-heard with external panel members. Full remediation report written in Living History Register: date found, what was found, what was fixed, who was removed.'),
            ('8', "Proper elections held within 90 days of emergency appointment. Standard election procedure (Workflow 1, Steps 6 and 7). New Council's first act: read the Capture Response entries aloud. 23"),
        ],
    },
]

# =============================================================================
# PART 6 -- INTEGRITY: ATTACK TESTS AND PROTECTION FRAMEWORK
# =============================================================================
PART6_TITLE = "INTEGRITY AND PROTECTION"
S17_TITLE   = "ATTACK TESTS"
S17_INTRO   = "Ten real-world attacks tested against this system. For each: how the attack works, where it fails, and the fix rule."

ATTACKS = [
    {
        "num":    '1',
        "title":  'Fake Land Claim',
        "attack": 'A person claims ancestral land with no documents. Pressures the Recorder to create an entry.',
        "fails":  '1. All 3 Verifiers must physically visit the plot -- they cannot sign without going. 2. 2 Neighbour Witnesses must walk the boundary and sign -- they know the real boundary. 3. The whole village must vote 60% YES. 4. If a plot is already registered to someone else: status clash opens Dispute immediately.',
        "fix":    'R-43 (core rule) -- No entry is valid without all 3 Verifier signatures and 2 Witness signatures. See also Fix-R-01 (Section 13).',
    },
    {
        "num":    '2',
        "title":  'Fake Identity',
        "attack": "Person A impersonates Person B to claim B's use-right, especially after B's death.",
        "fails":  "1. All residents have thumbprints in the Resident List. 2. The Land Register has the steward's thumbprint. 3. Rotating Verifier checks identity during weekly audit. 4. Any resident may challenge any identity at any time.",
        "fix":    'Fix-R-02 -- Identity = thumbprint match + 2 confirming residents. On death: plot Suspended until re-registration (Workflow 6).',
    },
    {
        "num":    '3',
        "title":  'Vote Manipulation',
        "attack": 'A faction brings 50 outsiders to meet quorum and push a favourable proposal through.',
        "fails":  '1. Only registered residents vote -- Resident List is the authority. 2. New residents must wait 30 days to vote (R-14). 3. Recorder reads the name list and checks identity before voting begins. 4. Both Witnesses sign the final count.',
        "fix":    'Fix-R-03 -- Resident List read aloud before voting. Eligibility challenged before voting. Outsider voter found: entire vote cancelled, redo in 7 days, person who brought outsiders: 30-day ban.',
    },
    {
        "num":    '4',
        "title":  'Verifier Collusion',
        "attack": 'Two permanent Verifiers accept a bribe and sign a false boundary measurement together.',
        "fails":  '1. The third Verifier (rotating, external) must also sign -- harder to bribe. 2. Weekly 10% audit compares boundary to registered sketch. 3. Neighbour Witnesses also signed the original boundary -- they know the truth. 4. Any resident may challenge any Final entry by filing a Dispute.',
        "fix":    'Fix-R-04 -- Two colluding Verifiers: both 30-day banned, entry cancelled, 3 entirely new Verifiers re-verify. Third confirmed collusion: whole team replaced.',
    },
    {
        "num":    '5',
        "title":  'Boundary Creep',
        "attack": "Steward moves a boundary marker 10 centimetres each month. After 2 years: 2-metre encroachment into a neighbour's land.",
        "fails":  '1. Land Register records permanent landmarks -- they cannot be secretly moved. 2. Sketch map shows original dimensions -- any surveyor can measure the deviation. 3. Weekly audit checks boundary against sketch. 4. Neighbour Witnesses signed the original line -- they will notice the change.',
        "fix":    'Fix-R-05 -- Markers must be permanent natural features or concrete/stone. Wooden stakes invalid. Displaced marker: immediate Suspension + Dispute. Deliberate displacement = fraud (R-06).',
    },
    {
        "num":    '6',
        "title":  'Council Capture',
        "attack": 'One powerful family gradually occupies 8 of 11 Council seats over 3 election cycles.',
        "fails":  "1. R-38: maximum 2 family members on Council simultaneously. 2. R-03: rule changes require 70% -- a captured Council alone cannot change this. 3. R-32: Council members cannot vote on their own family's land. 4. Cap-1 Red Flags B and C will be triggered -- any resident can file a Capture Concern.",
        "fix":    'Fix-R-06 -- 2-family limit enforced at election. Found after: one resigns in 7 days. Neither resigns: both removed, by-election in 30 days. Caste bias alleged: neighbouring village joint panel called.',
    },
    {
        "num":    '7',
        "title":  'Register Burning',
        "attack": 'A powerful person burns or steals the Land Register to erase inconvenient entries and deny their existence.',
        "fails":  '1. Off-site backup copy exists (R-37) -- updated monthly. 2. All Verifiers have seen and physically verified all Final plots. 3. Neighbour Witnesses know and can testify to every boundary they signed. 4. Village memory -- 50+ people attended the vote for every Final entry.',
        "fix":    'Fix-R-07 -- Backup copy location publicly known. Deliberate destruction: 30-day ban + 70% vote for permanent exclusion. Reconstruction: Workflow 11.',
    },
    {
        "num":    '8',
        "title":  'Vexatious Disputes',
        "attack": 'Losing party re-files the same dispute 31 days later with slightly different wording. Then again. Then again. The goal is to drain the system of time and energy.',
        "fails":  '1. Recorder tracks all prior Dispute IDs -- the history is visible. 2. Panel sees prior decisions before the hearing even starts. 3. After 3 losses in the same case: 30-day filing ban (R-19).',
        "fix":    'Fix-R-08 -- Panel checks prior Dispute IDs at the start of every hearing. Re-filed case must state new evidence in writing at time of filing. No actual new evidence: dismissed in 15 minutes without full hearing.',
    },
    {
        "num":    '9',
        "title":  'Threats and Coercion',
        "attack": 'A powerful person privately threatens a Verifier: "Sign the false entry or something will happen to your family."',
        "fails":  '1. Threatening someone is itself an offence under R-41. 2. There are 3 Verifiers -- threatening one is not enough to control the outcome. 3. The rotating Verifier is from outside the village -- less social pressure on them.',
        "fix":    'Fix-R-09 -- Threatened Verifier reports in writing within 24 hours. Threat confirmed: 30-day ban + 60% vote for permanent exclusion. Threatened Verifier may be removed from that specific case, replaced by an external Verifier with no social connection to the village.',
    },
    {
        "num":    '10',
        "title":  "Women's Exclusion",
        "attack": 'Powerful men prevent women from attending meetings by social pressure, or declare women\'s signatures "not valid" or "not traditional."',
        "fails":  "1. All residents including women are on the Resident List -- their status is equal. 2. R-39: 33% minimum women's Council representation is mandatory and enforced. 3. R-40: no one may demand another be excluded from any meeting. 4. Protection-8: blocking a woman from a meeting = same penalty as a physical threat.",
        "fix":    "Fix-R-10 -- Women's signatures fully valid in every register. Council below 33% women: by-election within 30 days. Blocking a woman from attending = immediate 30-day ban.",
    },
]

S18_TITLE            = "PROTECTION FRAMEWORK"
S18_GENDER_TITLE     = "18.1 Why Gender Protection Needs Its Own Rules"
S18_GENDER           = "18.1 Why Gender Protection Needs Its Own Rules In most real villages, women are systematically excluded from meetings through social pressure rather than explicit rules. A powerful man does not need to ban women -- he simply schedules meetings at times women cannot attend, ensures women are not nominated for Council, and treats female Witness signatures as informal or irrelevant. The Trust prevents this structurally: - The 33% Council minimum is not aspirational -- it has an enforcement floor (R-39) - Women's signatures are explicitly stated as fully valid in every register - Blocking attendance is treated identically to making a physical threat - Inheritance explicitly states daughters and sons are equal (R-49)"
S18_CASTE_TITLE      = "18.2 Why Caste Protection Needs Its Own Rules"
S18_CASTE            = '18.2 Why Caste Protection Needs Its Own Rules A dominant-caste Council can ignore lower-caste disputes without ever making an explicit caste-based statement. They simply delay hearings, find procedural reasons to reject filings, or ensure the panel always rules against lower-caste claimants. The Trust prevents this structurally: - Panel composition rule: at least 1 member not from the dominant-caste group (Protection-10) - If entire Council is one caste and bias alleged: neighbouring village panel mandatory - All collective land open to all residents regardless of caste (Protection-11) - Discrimination allegations permanently recorded in Integrity Register'
S18_SEASONAL_TITLE   = "18.3 Why Seasonal and Migrant Protection Needs Its Own Rules"
S18_SEASONAL         = 'The 180-day abandonment rule, without modification, is hostile to seasonal farmers, pastoralists, and migrant workers. A farmer who takes his family to a city for 6 months to earn wages and returns in time for planting would automatically lose their plot. The Trust prevents this with Seasonal Status registration: - Registered at time of land entry -- one step, permanent protection - The Temporary Manager registration allows a family member to act in their absence - The 3-year use-right review accommodates seasonal absences when notified PART 7 -- ENFORCEMENT SECTION 19 -- THE ENFORCEMENT SPINE 19.1 The Honest Situation The Trust has no police, no bailiff, no court officer. If a powerful person encroaches on a verified plot and the Verifiers say "stop" -- he can say "so what." The system\'s old answer was: "Open a dispute." His answer is: "Fine. I\'ll ignore that too." Force does not have to be physical. Communities have used economic and social pressure for thousands of years. The Trust formalises this into the 5-Rung Enforcement Ladder (Workflow 14). The key insight: Rung 3 (Commons Suspension) creates real, tangible, daily economic consequences -- without any physical action. 19.2 Why the Ladder Works RUNG 1 Formal Notice Creates a permanent record of refusal. RUNG 2 Community Declaration Makes the violation public. Social consequences begin. RUNG 3 Commons Suspension Loss of grazing, water, collective labo'

# =============================================================================
# PART 7 -- ENFORCEMENT
# =============================================================================
PART7_TITLE  = "ENFORCEMENT"
S19_TITLE    = "THE ENFORCEMENT SPINE"
S19_HONEST   = '19.1 The Honest Situation The Trust has no police, no bailiff, no court officer. If a powerful person encroaches on a verified plot and the Verifiers say "stop" -- he can say "so what." The system\'s old answer was: "Open a dispute." His answer is: "Fine. I\'ll ignore that too." Force does not have to be physical. Communities have used economic and social pressure for thousands of years. The Trust formalises this into the 5-Rung Enforcement Ladder (Workflow 14). The key insight: Rung 3 (Commons Suspension) creates real, tangible, daily economic consequences -- without any physical action.'
S19_WHY      = '19.2 Why the Ladder Works RUNG 1 Formal Notice Creates a permanent record of refusal. RUNG 2 Community Declaration Makes the violation public. Social consequences begin. RUNG 3 Commons Suspension Loss of grazing, water, collective labour. This is real economic pain, every day. RUNG 4 Inter-Village Broadcast Outside the village, reputation and trade affected. RUNG 5 Legal Filing Real legal process with Trust records as evidence. Each rung increases pressure. Most violations stop at Rung 1 or 2. A person who ignores all 5 rungs is rare -- and by Rung 5, the Trust has built a legal case that civil courts will take seriously.'
S19_CANNOT   = '19.3 What the Ladder Cannot Do It cannot stop a physically violent person. If there is a physical threat, go directly to Rung 5 AND notify police immediately. The Trust is never a justification for counter-violence.'
S20_TITLE    = "CAPTURE RESPONSE"
S20_WHAT     = '20.1 What Capture Looks Like Capture is not dramatic. It does not happen overnight. It looks like this: A respected family nominates 2 members to the Council (within the 2-family rule). They also arrange for a cousin\'s cousin -- technically outside 2nd-degree -- to stand. They appoint a friendly Recorder. The 2 permanent Verifiers are their social allies. Disputes against their family take 8 days instead of 7. Then 12 days. Then they stop being heard at all. The rotating Verifier slot "keeps forgetting" to rotate. The 5 notebooks say everything is fine. This is not a hypothetical. It is what happens in every village governance system that lacks structural protection against it.'
S20_FIVE     = '20.3 The Five-Stage Response See Workflow 15. Key points: - Stage 2 (external audit) is 100% of all Final entries -- not the usual 10% - Stage 4 (reform vote) is always secret ballot -- always - Stage 5 (remediation) re-hears all blocked disputes with external panels - The Living History Register records everything that was found and fixed - This history is the protection for future generations 26'

# =============================================================================
# PART 8 -- SUSTAINABILITY
# =============================================================================
PART8_TITLE          = "SUSTAINABILITY"
S21_TITLE            = "TRAINING STANDARDS"
S21_VERIFIER_TITLE   = "21.1 Verifier Training -- 7 Days"
S21_VERIFIER         = '21.1 Verifier Training -- 7 Days Requirements to become a Verifier: - Resident for minimum 1 year - Able to read and write (or work with a literate assistant for writing) - No family member currently serving on Council Training Program: Day 1 Read and understand the Land Register completely. Meaning of every field. Practice reading existing Final entries. Learn what "Pending / Final / Suspended / Cancelled" means. Day 2 Measuring a plot with rope. Calibrating personal pace: walk 10 metres, count paces, calculate. Identifying and recording landmarks: describe size, shape, location. Day 3 Drawing sketch maps on paper. Finding North/South/East/West using sunlight and shadow. Shadow method: stand a stick vertical at noon -- shadow points north. Day 4 The Verification Register -- every field in detail. Practice the audit process on an existing Final entry. Identifying and recording "Clear / Discrepancy / Fraud Suspected." Day 5 Role-play simulations: Simulated claimant with a false boundary. How to handle disagreement. Simulated neighbour who refuses to sign. Documenting the refusal. Simulated threat from a steward. Reporting to Recorder in writing. Day 6 Real plot inspection accompanied by an experienced Verifier. Trainee conducts the full inspection. Experienced Verifier observes only. After: experienced Verifier gives detailed verbal feedback. Day 7 Final review. Trainee fully measures and enters 1 real plot in the register. Both permanent Verifiers observe. If satisfactory: Council votes 60% to certify. Recorded in Voting Register. If not satisfactory: additional Days 6-7 repeated once. Certification: 60% Council vote. Recorded in Voting Register as a formal resolution.'
S21_RECORDER_TITLE   = "21.2 Recorder Training -- 7 Days"
S21_RECORDER         = '21.2 Recorder Training -- 7 Days Requirements: - Strong reading and writing ability (the clearest writer available) - Resident for minimum 2 years - No family member currently serving on Council Training Program: Day 1 All 6 registers: purpose, format, ID numbering, every field in detail. Practice reading existing entries in all notebooks. Day 2 Voting procedure: calculating quorum (R-01 formula with examples), counting present voters, announcing results, what to do when challenged. Day 3 Dispute filing: recording statements word-for-word (not summarising), assembling a 3-person panel, scheduling within 7 days. Day 4 Correcting mistakes: single line through error, initials beside it, never erase. What requires 3 new Verifier signatures to change (R-33). Practice on a deliberately incorrect sample entry. Day 5 Backup copy: how to update monthly, what to copy, where to store. Monthly activity summary: format and what to include. Day 6 Resident List: monthly update cycle (RL-1 through RL-8), annual audit procedure, contested membership process, Labour Exchange Credits column -- how to record and reset. Day 7 Live session: outgoing or supervising Recorder watches trainee handle a simulated Bhumi Daan, a simulated vote, and a simulated dispute filing. All in sequence. Recorder intervenes only if a procedural error would cause permanent damage to the record. Council votes 60% to certify. Recorded in Voting Register.'
S22_TITLE            = "RESIDENT LIST MAINTENANCE"
S22_WHY              = '22.1 Why This Matters Everything in the system -- quorum, eligibility, voting rights -- depends on the Resident List being accurate. A list maintained only at startup and never updated will be 30-40% wrong within 3 years. Everything built on a wrong list is wrong.'
RESIDENT_LIST_STATUS = ["Active", "Deceased", "Departed", "Seasonal", "Minor (under 18)", "Disputed"]
S23_TITLE            = "INTERGENERATIONAL CONTINUITY"
S23_RISK             = '23.1 The Real Risk Every governance system started by passionate founders and given no succession plan eventually fails. The founder knows why every rule exists. Their successor sees a rule and wonders why it is there. Within one generation, rules without understood reasons are quietly abandoned. The system hollows out from the inside.'
S23_HISTORY          = '23.2 The Living History Register (Notebook 6) The sixth notebook is the institutional memory of the Trust. It is not a legal record. It is not operational. It is the stories, the decisions, the attacks tried, and why each rule was written. Any Council member or Recorder may write in it at any time. Future Councils read it to understand the system they are running. It grows across decades. When someone opens this notebook in 30 years, they will know exactly what happened in Year 1 and why.'
S23_READY            = '23.3 The Ready List The village targets a minimum of 5 people at all times who have completed the Youth Apprenticeship (Cont-1) and are ready to serve as Recorder or Verifier. When a Recorder changes: the new one comes from the Ready List. When a Verifier is removed: the replacement comes from the Ready List. The Ready List is maintained by the Council and reviewed at every 5-Year Review.'
S23_FIVEYEAR         = '23.4 The Five-Year System Review Every 5 years: a dedicated 2-day gathering. Not a regular meeting. The entire system is reviewed consciously. Rules that never worked are revised. Rules that are always violated are examined. New attacks discovered since the last review are documented and new fix rules proposed. This is the system evolving deliberately, not drifting accidentally.'
S24_TITLE            = "ECONOMIC GRAVITY"
S24_PROBLEM          = '24.1 The Sustainability Problem The Trust asks people to spend time: attending meetings, doing audits, serving on panels. It gives security in return. Security is valuable. But it is invisible until the moment it is needed. Day-to-day, participation feels like a cost. People stop attending. Quorum fails. The system hollows out -- not from fraud, not from capture, but from boredom and busyness. The Trust must generate tangible benefits every week, not just in a crisis.'
S24_COLLECTIVE       = '24.2 Collective Resources Are the Mechanism Grazing land, ponds, forests, grain storage -- these generate real value every day. The Trust formally manages their allocation. Who gets the grazing slot on Tuesday. Who gets fishing rights on which days. Who gets first claim on surplus grain. These are not abstract rights -- they are daily material benefits that can only be accessed through the Trust system. When participation in the Trust means better access to the pond and the grazing ground, people participate. When it means nothing tangible, they drift away.'
S24_LABOUR           = '24.3 Labour Exchange Credits The credits system (Econ-3) creates a simple record: who contributed how many community work-days this year? Building a path, clearing the pond, planting collective trees, maintaining the boundary markers -- all count. Credits give first priority when collective resources are oversubscribed. They reset January 1. This is not money. It is a recognised measure of contribution. 29'

# =============================================================================
# PART 9 -- EXTERNAL AND LEGAL
# =============================================================================
PART9_TITLE       = "EXTERNAL AND LEGAL"
S25_TITLE         = "INTER-VILLAGE PROTOCOL"
S25_AGREEMENT     = '25.1 The Simple Agreement When two or more neighbouring villages adopt the Bhumi Trust system, they sign a one-page agreement: "We, the Bhumi Trusts of [Village A] and [Village B], agree: 1. In inter-village disputes we will follow Workflow 10. 2. We will provide rotating Verifiers for each other monthly. 3. In disaster we will help each other recover records (Workflow 11). 4. We will conduct annual cross-village audits (Cap-7). 5. This agreement changes only by 70% vote of both Councils." This agreement is entered in both villages\' Voting Registers. It is signed by both Councils. A copy is kept in each village\'s archive.'
S25_ROTATING      = "25.2 The Rotating Verifier Exchange Village A's Verifier spends 4 days per month in Village B. Village B's Verifier spends 4 days per month in Village A. This exchange ensures independence -- each village always has one outside perspective in every audit. It is the single most important safeguard against capture that requires only cooperation between two villages."
S25_CROSS_AUDIT   = "25.3 The Annual Cross-Village Audit Once per year: neighbouring village Verifiers audit 25% of each other's Final entries. Not the usual 10% -- 25%. The findings are entered in both villages' Verification Registers. This is the outside health check."
S26_TITLE         = "LEGAL ANCHORING"
S26_HONEST        = '26.1 The Honest Starting Point In India, land is governed by state revenue law. The chain is: Survey -> Khasra -> Khatauni -> Patta -> Registered Sale Deed. A Trust notebook is not in this chain. A court ignores it. This is not a bug -- it is a design constraint. The Trust works until a party with a government title appears. Then the government title wins. Always. The four layers below do not change this today. They build toward changing it.'
S26_GRAM          = '26.2 Layer 1 -- Gram Sabha Integration Legal-1 At first Gram Sabha meeting after Trust formation: present the system formally. Request a resolution: "The Gram Sabha of [Village] recognises the Bhumi Trust Register as a community record." Not legally binding -- but it is a government body acknowledging existence. Legal-2 Every Trust vote where 60% or more residents participate should be documented so the Gram Sabha secretary can certify attendance. A certified community vote is evidence in civil court of consensus. Legal-3 Submit a copy of every Final Land Register entry to the Gram Panchayat. Request acknowledgement of receipt. Keep the stamp in the Land Register. This creates a paper trail inside the government system itself.'
S26_REVENUE       = '26.3 Layer 2 -- Revenue Record Cross-Reference Legal-4 For every Trust plot: check the state revenue record. Find: Khasra number, Khatauni, currently recorded owner. Enter in Land Register: "Govt. Record: Khasra No. [XXX]." Legal-5 Three situations: A. Records match: Trust entry aligns with revenue record. Document this. A matching Trust + Government record is very strong. B. Records differ -- government shows different name, but that person has voluntarily donated (Bhumi Daan): Draft a written statement: "I, [Name], holder of Khasra [XXX], give community use-rights to [Steward Name] under the Bhumi Trust. I do not waive government title. I waive use-rights only." Two Witnesses sign. Panchayat stamp if obtainable. This is a legal private use agreement between two parties. C. Government record shows no private owner (common land, government wasteland): Trust entry is STRONGER -- it establishes community possession with documented evidence. Continuous documented possession matters under adverse possession law. Legal-6 Forest Rights Act 2006 (FRA): for eligible scheduled tribes and traditional forest dwellers -- check eligibility for Community Forest Rights claims. The Trust Register is exactly the kind of documentation the FRA expects. This can convert Trust entries into legal rights today. Do this immediately for any eligible community.'
S26_EVIDENCE      = "26.4 Layer 3 -- The Evidence Package Legal-7 For any plot that may reach a court, prepare an Evidence Package: Document 1: Land Register entry -- original, with all signatures Document 2: All Verification Register entries for that plot Document 3: The Voting Register entry for that plot's confirmation Document 4: List of all Witnesses who signed, with contact details Document 5: The Boundary Document with all signatures Document 6: Gram Sabha resolution or Panchayat stamp (if obtained) Document 7: Written statements from 10 or more neighbours confirming the boundary as of [date] Document 8: Photographs of landmarks (if a camera was available) A civil court judge seeing 7 or 8 consistent documents, 10 witness statements, and a 3-year audited record will take this seriously. It is not a title deed. It is the strongest community evidence possible. Legal-8 For every internal hearing: enter the Evidence Package summary in the Dispute Register. Even if resolved internally, the record exists if the case reaches a court later."
S26_LONG_GAME     = '26.5 Layer 4 -- Long Game Legal-9 When 10 villages are running the system: Form an inter-village council. Approach the state government with a formal proposal for "Community Land Trust Recognition Rules" under state land law. Precedents exist: Maharashtra (watan lands), Kerala (Kudumbashree), Uttarakhand (Van Panchayats). Legal-10 Every Trust register is evidence for this campaign. Well-maintained registers covering 5 or more years of community governance are exactly what a government needs to see before passing enabling legislation.'
S27_TITLE         = "STATE INTERFACE AND LEGISLATIVE PATHWAY"
S27_DEF_A         = 'Definition A -- Parallel Legitimacy The Trust runs alongside the state system. Communities use it for internal disputes. The state system handles formal transactions and court proceedings. STATUS: Achievable on Day 1. This is what the Trust already delivers.'
S27_DEF_B         = 'Definition B -- Functional Superiority The Trust resolves disputes faster, more fairly, and more accurately. Communities default to Trust decisions even when courts are available -- because the Trust works better in practice. STATUS: Achievable in 2 to 5 years in a well-run village.'
S27_DEF_C         = 'Definition C -- Legal Equivalence Trust entries have the same legal standing as state revenue records. A Trust entry can defeat a state title in court. A Trust Recorder has the same authority as a Patwari. STATUS: Requires legislation. Cannot be achieved without a state or national government passing enabling law. Timeline: 15 to 30 years.'
S27_WEAKNESSES    = "27.2 Why the State System Is Vulnerable Weakness 1 CORRUPTION: One Patwari bribe of Rs.5,000 to 50,000 changes a khasra entry. No witnesses. No audit. No community. The Trust requires corrupting 6 independent people simultaneously. Weakness 2 INACCESSIBILITY: Average rural land dispute in India takes 20 years in court. Legal fees destroy families. Courts are in district towns. Documents are in languages many residents cannot read. The Trust: 7-day resolution, no fees, in the village, in local language. Weakness 3 WRONG RECORDS: Revenue records were designed for tax collection, not justice. They are systematically wrong for common land, tribal land, women's land, and land held by oral agreement. The Trust records all of this. The state system ignores all of it. Weakness 4 DIGITISATION WITHOUT VERIFICATION: India's DILRMP programme is digitising land records -- but digitising a wrong record makes it wronger faster. Errors reach courts without any community verification. The Trust's physical verification is more accurate than the state's digitised record for every plot it covers."
LEGISLATIVE_PHASES = [
    {"num":"1","title":"OPERATIONAL PROOF (Years 1 to 5)",       "goal":"Demonstrate the Trust works better in the same village, same land, 5 years.",                              "body":'PHASE 1 -- OPERATIONAL PROOF (Years 1 to 5) Goal: Demonstrate the Trust works better in the same village, same land, 5 years. Action 1.1 Run in 1 to 3 villages. Document everything. Compare dispute resolution time to state system. Action 1.2 Collect testimony: women with use-rights who had none before, inheritance disputes resolved without families breaking apart, disputes resolved in 7 days vs. 20 years in court. Action 1.3 Cross-reference every Trust entry with state revenue records. File RTI requests for state records. Document every discrepancy. Build the factual case: "The state\'s records are wrong. Here are 50 witnesses. Here is the community\'s accurate record."'},
    {"num":"2","title":"REPLICATION (Years 3 to 8)",              "goal":"50 or more villages. Critical mass.",                                                                    "body":'PHASE 2 -- REPLICATION (Years 3 to 8) Goal: 50 or more villages. Critical mass. Action 2.1 Publish the Trust system as an open resource. Any village can adopt it without permission. Add simplified guides in regional languages. Action 2.2 Form an Inter-Village Federation when 10 or more villages join. Annual gathering of all Recorders and Council members. Shared Living History Register, joint audits, one collective voice. Action 2.3 Activate existing legal frameworks: FRA 2006: file Community Forest Rights claims backed by Trust records. PESA 1996 (tribal areas): gram sabhas already have land governance authority. Trust system formalises what is already legally permitted. State panchayat land laws: many states have unused gram sabha land management provisions. The Trust is the implementation mechanism. Action 2.4 Document 50 villages. Publish findings. Send to: State Land Revenue Department, Law Commission of India, National Legal Services Authority, academic researchers, journalists.'},
    {"num":"3","title":"LEGAL RECOGNITION (Years 7 to 15)",       "goal":"Legislative or judicial recognition of Trust entries as legal evidence.",                                "body":'PHASE 3 -- LEGAL RECOGNITION (Years 7 to 15) Goal: Legislative or judicial recognition of Trust entries as legal evidence. Action 3.1 Pilot a "Dual Register" with one state government. Target: Kerala (panchayat tradition), Uttarakhand (Van Panchayat precedent), or any state with progressive land reform history. Action 3.2 Strategic litigation -- select ONE clean case: Trust records clearly show the truth. State record is clearly wrong. Person wronged is a widow, minor, or displaced family. Evidence Package is complete. File in High Court. Argue: 50 witness signatures and 5 years of audited records is better evidence than a state record with none. Even partial win -- " Trust record admitted as evidence" -- is precedent. Action 3.3 Draft model legislation: "Community Land Trust Recognition Act, [State], [Year]." Key: a Bhumi Trust register maintained for 5 or more years with these procedures is a legal instrument. Entries are primary evidence. Submit to Law Commission and relevant state ministries. Action 3.4 Build political constituency: 50 villages = thousands of voters who care deeply about land security. Use this leverage in election cycles.'},
    {"num":"4","title":"CONSTITUTIONAL PROTECTION (Years 15 to 30)","goal":"Amend constitutional or statutory framework to permanently protect community land governance.",        "body":"PHASE 4 -- CONSTITUTIONAL PROTECTION (Years 15 to 30) Goal: Amend constitutional or statutory framework to permanently protect community land governance. Action 4.1 This requires a national political moment. Such moments come from: large-scale displacement crises, climate migration, political movements with land justice platforms, or judicial decisions that create reform pressure. Action 4.2 The Trust's role: to have 30 years of documented, audited, functioning community land governance on record when that moment arrives. Political moments without prepared systems produce chaos. This system is the preparation."},
]
S27_CAN_DO_NOW    = '27.4 What the System Can Do Right Now Today Register every plot with 8 signatures -- more witnessed than most state records. Today File FRA community claims using Trust records as documentation (for eligible communities -- do this immediately). Today Use Trust records as primary evidence in Gram Sabha hearings. Today Use Trust records as negotiating basis in land acquisition proceedings: "Here are 300 people with documented use-rights for 5 years. Compensation must reflect all of them." Today Resolve internal disputes in 7 days instead of 20 years in court. Today Prevent casual encroachment -- most land grabs are by neighbours who think no one is watching. The Trust makes someone always watching. Year 3 Approach Gram Sabha for formal community record resolution. Year 5 File first RTI challenges against incorrect revenue records. Year 8 File FRA claims backed by 8-year documented record. Year 10 File first strategic High Court case with full Evidence Package.'
S27_TIMELINE      = '27.5 The Honest Timeline Year 1: One village. Internal disputes resolved. System operational. Year 3: Five villages. Shared learnings. First Gram Sabha resolutions. Year 5: Documented proof. 500 or more disputes resolved. State comparison ready. Year 8: 50 villages. Inter-Village Federation. First FRA claims filed. Year 10: First strategic court case. Model legislation drafted. Year 15: Dual Register pilot with one state government. Year 20: State-level legal recognition in 1 to 2 states. Year 30: National model. Constitutional protection possible. This is a 30-year project. That is not weakness. That is honesty. The alternative -- claiming to replace state law today -- is fraud. 33'

# =============================================================================
# PART 10 -- EMERGENCIES AND CLOSURE
# =============================================================================
PART10_TITLE = "EMERGENCIES AND CLOSURE"
S28_TITLE    = "DISASTER RECOVERY PREPARATIONS"
S28_BODY     = 'SECTION 28 -- DISASTER RECOVERY PREPARATIONS The operational recovery is in Workflow 11. These are the always-on preparations: Preparation 1 Backup copy updated monthly. Kept in a strong building, different from where the main registers are stored. Preparation 2 All Verifiers have personally visited every Final plot. They are human backups. Their memory matters. Preparation 3 Every steward holds a written copy of their own Plot ID entry. They are the third backup for their own record. Preparation 4 Inter-village agreement in place. Neighbouring village can help reconstruct records from their cross-reference records. For flood: Registers in waterproof bag in an elevated location. If flood warning: move registers first. For fire: Backup copy in a metal box if available. Never store both copies in the same building. For displacement: Council takes registers when leaving. On return: begin Workflow 11. Extend all deadlines.'
DISASTER_PREPARATIONS = [
    ("Prep 1", "Backup copy updated monthly. Kept in a strong building, different from where the main registers are stored."),
    ("Prep 2", "All Verifiers have personally visited every Final plot. They are human backups. Their memory matters."),
    ("Prep 3", "Every steward holds a written copy of their own Plot ID entry. They are the third backup for their own record."),
    ("Prep 4", "Inter-village agreement in place. Neighbouring village can help reconstruct records from their cross-reference records."),
]
DISASTER_SCENARIOS = [
    ("For flood",        "Registers in waterproof bag in an elevated location. If flood warning: move registers first."),
    ("For fire",         "Backup copy in a metal box if available. Never store both copies in the same building."),
    ("For displacement", "Council takes registers when leaving. On return: begin Workflow 11 immediately. Extend all deadlines."),
]
S29_TITLE    = "EXIT PROCEDURE"
S29_BODY     = 'SECTION 29 -- EXIT PROCEDURE When exit may be needed: - One family has captured the system completely and Workflow 15 has failed - Three consecutive corrupted Council elections - Village merges into another administration - A better system exists and the village chooses it Exit is always democratic. 70% vote required -- the highest threshold. Registers are NEVER destroyed on exit. They are permanent historical records. Any steward may request a copy of their own entry at any time, forever, even decades after the system closes. See Workflow 12 for full procedure. 34'
EXIT_TRIGGERS = [
    "One family has captured the system completely and Workflow 15 has failed.",
    "Three consecutive corrupted Council elections.",
    "Village merges into another administration.",
    "A better system exists and the village chooses it.",
]
EXIT_KEY_RULE = "Exit is always democratic. 70% vote required -- the highest threshold. Registers are NEVER destroyed on exit. They are permanent historical records. Any steward may request a copy of their own entry at any time, forever, even decades after the system closes. Full procedure: Workflow 12."

# =============================================================================
# PART 11 -- REFERENCE
# =============================================================================
PART11_TITLE   = "REFERENCE"
S30_TITLE      = "BOOTSTRAP: HOW TO START ON DAY 1"
S30_MINIMUM    = "The absolute minimum to start: 7 willing people, 6 hardcover notebooks (buy today), pens and ink (and a spare pen), one person who can write clearly, one plot of land someone wants to donate (even collective land)."
S30_TIME       = "Time to first registered plot: 2 to 3 weeks (including 7-day vote notice). Time to fully operational system: 30 to 60 days. Cost: Price of 6 notebooks and pens."
S30_FIRST_ENTRY= "The Living History Register begins on Day 1. First entry: We started this system on [Date] because [reason]. The people present were: [names]. Sign it. This will matter in 30 years."

S31_TITLE      = "SIMPLIFIED VERSION"
S31_SUBTITLE   = "For reading at village meeting. One page. Understood instantly."
S31_BIG_IDEA   = "The land does not belong to any one person. The village takes care of it together. You can live on it, farm it, build a house. But nobody can sell it, nobody can steal it, nobody can gamble it away. Bhumi Daan -- giving land back to the community."
S31_NOTEBOOKS  = [
    ("1","Land Notebook",    "which land, where, who is using it"),
    ("2","Check Notebook",   "did we inspect the land this week?"),
    ("3","Vote Notebook",    "what did the village decide?"),
    ("4","Dispute Notebook", "what was the fight? What did we decide?"),
    ("5","Honesty Notebook", "who was caught cheating? What happened?"),
    ("6","Memory Notebook",  "why were our rules written? What did we learn?"),
]
S31_JOBS = [
    ("1","Resident",        "lives here. Can vote. Can complain. Can look at any notebook."),
    ("2","Land Checker",    "visits the land and checks it. Signs the notebook. 3 per village."),
    ("3","Council",         "7 to 15 people chosen by the village. Make decisions together. Not alone."),
    ("4","Recorder",        "writes everything down. Keeps notebooks. Makes no decisions."),
    ("5","Witness",         "saw it with own eyes. Signs to confirm."),
    ("6","Backup Recorder", "steps in if the Recorder is sick or away."),
]
S31_NUMBERS = [
    ("60 out of 100", "must say YES -- only then is a decision made"),
    ("70 out of 100", "must say YES -- only then is a rule changed"),
    ("3",             "Land Checkers must personally visit -- only then is land registered"),
    ("2",             "Neighbours must walk the boundary and sign"),
    ("7 days",        "maximum time to resolve a dispute"),
    ("30 days",       "ban for lying or threatening someone"),
    ("Every week",    "1 in 10 pieces of land are inspected"),
    ("Quorum",        "20% of all village residents must attend, or 50 people -- whichever is MORE"),
]
S31_HOW_REGISTER = [
    ("1","Tell the Recorder you want to give your land to the Trust."),
    ("2","Three Land Checkers come, measure, draw a map."),
    ("3","Two neighbours walk the boundary and sign."),
    ("4","The village votes. 60% YES needed."),
    ("5","Done. Your land is in the Trust."),
]
S31_HOW_DISPUTE = [
    ("1","Tell the Recorder. They write it down."),
    ("2","The other side is informed within 1 day."),
    ("3","A panel of 3 people hears both sides within 7 days."),
    ("4","Decision is written down."),
    ("5","You have 2 days to appeal."),
    ("6","That is the end. The same dispute cannot be filed again."),
]
S31_WOMEN = [
    "1 in 3 Council members must be a woman",
    "Daughters and sons have equal rights to land",
    "Husband and wife: land is registered in both names",
    "Nobody stopped on the basis of caste or religion",
    "Blocking any woman from a meeting: 30-day ban",
]
S31_SEASONAL = [
    "Register as Seasonal at the start: your land is safe when you are away",
    "A family member can be registered to look after the land",
    "Return and inform the Recorder -- that is all",
]
S31_HOW_START = [
    ("1","Find 7 willing people"),
    ("2","Give 7 days notice to the whole village"),
    ("3","Village votes: shall we start?"),
    ("4","Buy 6 notebooks"),
    ("5","Choose Recorder, Land Checkers, Council"),
    ("6","Register the first plot -- as practice"),
    ("7","System is running"),
]

S32_TITLE  = "THE BULLETPROOF TEST"
S32_INTRO  = "Run this test before declaring any village system fully operational. If all 10 pass: the system is a functioning institution, not just a document."
BULLETPROOF_TESTS = [
    ('1', 'Can a single powerful person block a valid land registration?', 'Requires 3 Verifiers + 2 Witnesses + 60% village vote. No single person controls all of these simultaneously.'),
    ('2', 'Can a single powerful person ignore a Trust decision permanently?', 'Enforcement Ladder (Workflow 14) is active. Rung 3 creates daily economic consequences. Rung 5 creates legal consequences.'),
    ('3', 'Can the Trust be captured by one family?', 'All 8 Cap rules are active. Annual external audit (Cap-7) provides outside check. Capture Response (Workflow 15) can reverse it.'),
    ('4', 'Does the system survive the founders dying?', 'Living History Register is being written. Youth Apprenticeship has run at least once. Ready List has 5 or more names. 5-Year Review has been scheduled.'),
    ('5', 'Is a woman guaranteed meaningful participation?', '33% Council minimum enforced with floor (R-39). Blocking a woman = offence (Protection-8, Fix-R-10). Women can be sole stewards, Recorders, Verifiers.'),
    ('6', 'Does a seasonal migrant lose rights when absent?', 'Seasonal status registered at entry (R-30). 180-day rule does not apply to registered seasonal stewards. Temporary Manager option is available.'),
    ('7', 'Can a dispute be filed 40 years from now and records found?', 'Registers are never destroyed (R-37, Workflow 12 Step 5). Backup copy maintained monthly. Living History Register adds context across decades.'),
    ('8', 'Does the Resident List reflect reality after 5 years?', 'Monthly update cycle (RL-1) operating every month. Annual full audit (RL-7) completed every year. Contested membership procedure (RL-6) has been used at least once.'),
    ('9', 'Do Trust records have weight in a real court?', 'Boundary Document created for every Final plot. Gram Panchayat acknowledgement obtained (Legal-1, Legal-3). Revenue records cross-referenced for every plot (Legal-4). Evidence Package (Legal-7) ready for any dispute that may reach court.'),
    ('10', 'Is the system worth participating in every week, not just in crisis?', 'Collective land allocated with clear rules (Econ-2). Labour exchange credits actively tracked (Econ-3). At least one commons dividend distributed this year (Econ-4).'),
]

S33_TITLE  = "HISTORICAL PRECEDENTS"
S33_INTRO  = "Five cases where community land systems succeeded or achieved recognition. None are hypothetical. All happened."
HISTORICAL_PRECEDENTS = [
    ('1', 'Van Panchayats, Uttarakhand (1931 to present)', 'Created in 1931 under British rule to manage forest land that had been over-extracted. Now manage over 500,000 hectares of forest land across Uttarakhand. They have their own registers, their own rules, their own enforcement. The Indian state formally recognises them and they have legal standing. This took 30 years of documented, audited community management before full recognition.', '30 years of clean records is what converts a community system into a legally recognised one.'),
    ('2', 'Forest Rights Act, India 2006', 'The Scheduled Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act 2006 converted community possession into legal title for eligible forest land. It explicitly requires community documentation of historical use as evidence. The Trust Register is exactly the kind of documentation the FRA expects. This is not a future possibility. It is current law. Eligible communities can file Community Forest Rights claims backed by Trust records today.', ''),
    ('3', 'Kudumbashree, Kerala (2000 to present)', "A community women's collective managing land, credit, and agricultural operations for 4.5 million families across Kerala. It operates its own records, its own dispute resolution, its own resource allocation -- all parallel to the state. The state government now channels official programmes through it. Critical mass -- 4.5 million families -- converted a community system into a de facto state partner.", ''),
    ('4', 'Community Land Trusts, USA and UK (1969 to present)', 'Started with one Community Land Trust in Georgia, USA in 1969. Now over 300 CLTs in the USA and 50 or more in the UK. They own land collectively in perpetuity, sell or lease use-rights to residents. Many are now recognised in state law and receive government funding. Replication across many communities is what forces legal recognition. One CLT is a curiosity. 300 CLTs is a political constituency.', ''),
    ('5', 'Ejidos, Mexico (1917 to 1992)', 'After the Mexican Revolution, ejido (community land) was constitutionally protected. No state title could override ejido registration. This lasted 75 years until 1992 reforms weakened it. Constitutional protection is the strongest form -- but it requires a political moment of transformation. The 1917 moment came from revolution. A future moment may come from climate displacement, housing crisis, or democratic reform movements. When that moment comes: the system must already be running, documented, and ready.', ''),
]

S34_TITLE     = "FINAL STATEMENT"
S34_CAN_DO    = "What This System Can Do Today: Register every plot with 8 signatures -- more witnessed than most state records. File FRA claims for eligible communities (this is current law). Use Trust records as primary evidence in Gram Sabha hearings. Resolve internal disputes in 7 days instead of 20 years in court. Prevent casual encroachment -- the Trust makes someone always watching."
S34_CANNOT_DO = "What This System Cannot Do: It cannot override a state-registered title deed -- not today. It cannot stop a physically violent person without police. It cannot work in a village where no one wants to participate. It cannot create trust where there is none at all. It cannot replace state law without 15 to 30 years of operation first. Anyone who says otherwise is selling something."
S34_FINAL     = 'What This System Can Do Today Resolve internal land disputes in 7 days instead of 20 years. Today Prevent casual encroachment by opportunistic neighbours. Today Register use-rights for women who have none in the state system. Today Document community land use with 8 witness signatures per plot. Today File FRA claims for eligible communities (this is current law). Today Build evidence that strengthens a civil court case. Year 3 Obtain Gram Sabha acknowledgement of community records. Year 5 File RTI challenges against incorrect state revenue records. Year 8 File FRA claims backed by 8 years of audited community records. Year 10 File the first strategic High Court case with full Evidence Package. Year 20 Seek state-level legal recognition in progressive states. Year 30 Build toward constitutional protection of community land governance. What This System Cannot Do It cannot override a state-registered title deed -- not today. It cannot stop a physically violent person without police. It cannot work in a village where no one wants to participate. It cannot create trust where there is none at all. It cannot replace state law without 15 to 30 years of operation first. Anyone who says otherwise is selling something. The Final Honest Statement The Bhumi Trust cannot replace the state land system today. No community paper system can. What it can do: work better than the state system for the people it covers, starting today. Build the evidence, the constituency, and the legal precedent for formal recognition over the next 10 to 30 years. In the meantime, protect the people who have nothing else. That is not a small thing. That is what Van Panchayats did in 1931. That is what the Forest Rights Act recognised in 2006. That is what 300 Community Land Trusts did across America and Britain. The path from a community notebook to a legally recognised instrument has been walked before. It takes 15 to 30 years of consistent, honest, documented operation. This system is the documentation. The walking is done by the village. Bhumi Trust Land Governance System -- Version 5.0 Single authoritative edition. Supersedes all previous versions. Part of the Satya Yuga Bhumi Trust three-document system: Vishwadharma Granth (soul) -- Vishwa Samvidhan (conscience) -- Bhumi Trust Blueprint (hands) github.com/chyrenselin/Satya-Yuga-Bhumi-Trust-DAO Offline. Paper-based. Community-owned. Legally anchored. Generationally durable. Honest about its limits. COMPLETE INVENTORY Rules: R-01 to R-50 (core) = 50 Fix-R-02 to Fix-R-10 = 9 Protection-1 to 19 = 19 Legal-1 to Legal-10 = 10 Enf-1 to Enf-5 = 5 RL-1 to RL-8 = 8 Cap-1 to Cap-8 = 8 Cont-1 to Cont-5 = 5 Econ-1 to Econ-7 = 7 TOTAL RULES: = 121 Workflows: 1 to 15 = 15 Registers: 6 notebooks = 6 Roles: 6 defined roles = 6 Attack tests: 10 full attack scenarios = 10 Bulletproof: 10 binary tests = 10 Precedents: 5 historical cases = 5 Phases: 4-phase roadmap = 4 Sections: 34 sections = 34 Version 5.0 --'

COMPLETE_INVENTORY = {
    "rules_core": 50, "rules_fix": 9, "rules_enf": 5, "rules_rl": 8,
    "rules_cap": 8, "rules_cont": 5, "rules_econ": 7, "rules_prot": 19,
    "rules_legal": 10, "total_rules": 121, "workflows": 15, "registers": 6,
    "roles": 6, "attack_tests": 10, "bulletproof_tests": 10, "precedents": 5,
    "legislative_phases": 4, "sections": 34,
}


# =============================================================================
# UI STRINGS — match these in every language content file
# =============================================================================

UI_QUICK_REF_TITLE       = "QUICK REFERENCE CARD"
UI_QUICK_REF_SUBTITLE    = "The 10 numbers you must know  --  6 roles  --  How to register land  --  How a dispute is resolved"
UI_KEY_NUMBERS_TITLE     = "THE 10 KEY NUMBERS"
UI_SIX_ROLES_TITLE       = "THE 6 ROLES -- WHO DOES WHAT"
UI_TOC_INTRO             = "This document has <b>11 Parts</b>, <b>34 Sections</b>, and <b>121 numbered rules</b>. Use this table to jump to any section. Start with §1 (One-Page Summary) or §31 (Simplified Village Version) if reading for the first time."

UI_ROLE_RESIDENT         = "RESIDENT"
UI_ROLE_RESIDENT_DESC    = "Lives here. Can vote, donate land, inspect registers, file disputes."
UI_ROLE_VERIFIER         = "VERIFIER (x3)"
UI_ROLE_VERIFIER_DESC    = "Physically visits every plot. Measures. Signs. Cannot verify own land."
UI_ROLE_COUNCIL          = "COUNCIL (7-15)"
UI_ROLE_COUNCIL_DESC     = "Elected body. Makes decisions. Hears disputes. Cannot block filings."
UI_ROLE_RECORDER         = "RECORDER (x1)"
UI_ROLE_RECORDER_DESC    = "Writes everything. Assigns IDs. Keeps notebooks. Makes no decisions."
UI_ROLE_WITNESS          = "WITNESS (x2)"
UI_ROLE_WITNESS_DESC     = "Personally saw the event. Walks the boundary. Signs to confirm."
UI_ROLE_DEP_RECORDER     = "DEP. RECORDER"
UI_ROLE_DEP_RECORDER_DESC = "Backup writer. Steps in when Recorder is absent 7+ days."

UI_LAND_REG_TITLE        = "HOW TO REGISTER LAND (WF-02)"
UI_LAND_STEP_1           = "(1) Donor tells Recorder -- gets a Plot ID"
UI_LAND_STEP_2           = "(2) 3 Verifiers visit together, measure, draw map"
UI_LAND_STEP_3           = "(3) 4 Neighbours walk boundary and sign"
UI_LAND_STEP_4           = "(4) Boundary Document created with 8 signatures"
UI_LAND_STEP_5           = "(5) Notice posted at 3 public places (7 days)"
UI_LAND_STEP_6           = "(6) Village votes -- 60% YES needed"
UI_LAND_STEP_7           = "(7) Status = FINAL. Land is in the Trust."

UI_DISPUTE_TITLE         = "HOW A DISPUTE IS RESOLVED (WF-05)"
UI_DISPUTE_STEP_1        = "(1) Any resident files -- Recorder writes it word-for-word"
UI_DISPUTE_STEP_2        = "(2) Respondent notified in writing within 24 hours"
UI_DISPUTE_STEP_3        = "(3) 3-person panel assembled (neutral members only)"
UI_DISPUTE_STEP_4        = "(4) Hearing held openly within 7 days"
UI_DISPUTE_STEP_5        = "(5) Panel decides -- written decision read aloud"
UI_DISPUTE_STEP_6        = "(6) 48 hours to appeal on new evidence only"
UI_DISPUTE_STEP_7        = "(7) Full Council hears appeal -- final decision"

UI_CAN_DO_TODAY          = "<b>What this system can do TODAY:</b> Resolve disputes in 7 days -- Register land with 8 witness signatures -- Protect women rights -- File FRA community forest claims -- Prevent casual encroachment."
UI_CANNOT_DO             = "<b>What it cannot do yet:</b> Override a government title deed in court. That requires 15-30 years of documented operation. This document is that documentation."

UI_SIMP_NOTEBOOKS_TITLE  = "SIX NOTEBOOKS -- Write Everything Down"
UI_SIMP_JOBS_TITLE       = "SIX JOBS -- Who Does What"
UI_SIMP_NUMBERS_TITLE    = "THE NUMBERS TO REMEMBER"
UI_SIMP_REG_TITLE        = "HOW TO REGISTER YOUR LAND"
UI_SIMP_DISPUTE_TITLE    = "HOW A DISPUTE IS RESOLVED"
UI_SIMP_WOMEN_TITLE      = "WOMEN AND ALL COMMUNITIES"
UI_SIMP_SEASONAL_TITLE   = "SEASONAL AND MIGRANT FAMILIES"
UI_SIMP_START_TITLE      = "HOW TO START -- TODAY"
UI_SIMP_SUBTITLE         = "For reading at village meeting. Understood by anyone. No education needed."
UI_NOTEBOOK_LABEL        = "NOTEBOOK"

UI_HONEST_START          = "THE HONEST STARTING POINT"
UI_BOUNDARY_DOC          = "THE BOUNDARY DOCUMENT"
UI_ROTATING_VER_NOTE     = "ROTATING VERIFIER NOTE"
UI_HONEST_SITUATION      = "THE HONEST SITUATION"
UI_WHAT_CAPTURE          = "WHAT CAPTURE LOOKS LIKE"
UI_WHY_MATTERS           = "WHY THIS MATTERS"
UI_REAL_RISK             = "THE REAL RISK"
UI_SUSTAINABILITY_PROB   = "THE SUSTAINABILITY PROBLEM"
UI_SIMPLE_AGREEMENT      = "THE SIMPLE AGREEMENT"
UI_WHEN_EXIT             = "WHEN EXIT MAY BE NEEDED"
UI_KEY_RULE              = "KEY RULE"
UI_ABS_MINIMUM           = "THE ABSOLUTE MINIMUM TO START"
UI_WHAT_CAN_DO           = "WHAT THIS SYSTEM CAN DO TODAY"
UI_WHAT_CANNOT_DO        = "WHAT THIS SYSTEM CANNOT DO"

UI_COVER_LABEL           = "BHUMI TRUST"
UI_THREE_DOC_LABEL       = "PART OF A THREE-DOCUMENT SYSTEM"
UI_WHAT_YOU_NEED_LABEL   = "What you need:"
UI_WHERE_WORKS_LABEL     = "Where it works:"
UI_WHEN_STARTS_LABEL     = "When it starts:"

UI_RUNG_1_TITLE          = "FORMAL NOTICE"
UI_RUNG_1_DAYS           = "Day 1-7"
UI_RUNG_1_DESC           = "Creates a permanent record of refusal. 3 Council + 3 Verifiers sign. Delivered personally by 2 Witnesses."
UI_RUNG_2_TITLE          = "COMMUNITY DECLARATION"
UI_RUNG_2_DAYS           = "Day 8-14"
UI_RUNG_2_DESC           = "Makes the violation public. 60% village vote. Social consequences begin. Permanent record in Integrity Register."
UI_RUNG_3_TITLE          = "COMMONS SUSPENSION"
UI_RUNG_3_DAYS           = "Day 15-60"
UI_RUNG_3_DESC           = "60% Council vote. Loss of grazing, water access, collective labour, community grain stores. Real economic pain, every day. No physical element."
UI_RUNG_4_TITLE          = "INTER-VILLAGE BROADCAST"
UI_RUNG_4_DAYS           = "Day 76-90"
UI_RUNG_4_DESC           = "Notify all neighbouring Bhumi Trusts in writing. Violator standing in all inter-village exchanges suspended."
UI_RUNG_5_TITLE          = "FORMAL LEGAL FILING"
UI_RUNG_5_DAYS           = "Day 91+"
UI_RUNG_5_DESC           = "60% village vote. File with Gram Sabha, civil court, or DLSA (free in all districts). By Rung 5 the Trust has built a legal case courts will take seriously."

# Quick Reference Card — 10 key numbers (for the Quick Ref card grid)
UI_QUICK_NUMS = [
    ("60%",      "YES votes for\nevery decision"),
    ("70%",      "YES votes to\nchange a rule"),
    ("3",        "Verifiers must\nvisit every plot"),
    ("2",        "Neighbour witnesses\nmust sign"),
    ("7 days",   "Maximum time to\nresolve a dispute"),
    ("30 days",  "Ban for fraud\nor threats"),
    ("10%",      "Random audit\nevery week"),
    ("33%",      "Minimum women\non Council"),
    ("90 days",  "Re-register after\nsteward's death"),
    ("180 days", "Empty = plot\nreturns to Trust"),
]

# Cover stats labels
UI_STAT_RULES      = "Rules"
UI_STAT_WORKFLOWS  = "Workflows"
UI_STAT_REGISTERS  = "Registers"
UI_STAT_ROLES      = "Roles"
UI_STAT_DAYS       = "Days to\nResolve"

UI_TOC_TITLE = "TABLE OF CONTENTS"

# TOC short labels
UI_TOC = {
    "S1":  "§1 One-Page Summary",
    "S2":  "§2 Full Explanation",
    "S3":  "§3 Core Numbers (R-01 - R-19)",
    "S4":  "§4 Land Rules (R-20 - R-30)",
    "S5":  "§5 Integrity Rules (R-31 - R-43)",
    "S6":  "§6 Inheritance Rules (R-44 - R-50)",
    "S7":  "§7 Enforcement Rules (Enf-1 - Enf-5)",
    "S8":  "§8 Resident List Rules (RL-1 - RL-8)",
    "S9":  "§9 Capture Prevention Rules (Cap-1 - Cap-8)",
    "S10": "§10 Continuity Rules (Cont-1 - Cont-5)",
    "S11": "§11 Economic Rules (Econ-1 - Econ-7)",
    "S12": "§12 Protection Rules (Protection-1 - Protection-19)",
    "S13": "§13 Attack Fix Rules (Fix-R-02 - Fix-R-10)",
    "S14": "§14 The Six Registers",
    "S15": "§15 The Six Roles",
    "S16": "§16 All 15 Workflows",
    "S17": "§17 Attack Tests",
    "S18": "§18 Protection Framework",
    "S19": "§19 The Enforcement Spine",
    "S20": "§20 Capture Response",
    "S21": "§21 Training Standards",
    "S22": "§22 Resident List Maintenance",
    "S23": "§23 Intergenerational Continuity",
    "S24": "§24 Economic Gravity",
    "S25": "§25 Inter-Village Protocol",
    "S26": "§26 Legal Anchoring",
    "S27": "§27 Legislative Pathway",
    "S28": "§28 Disaster Recovery Preparations",
    "S29": "§29 Exit Procedure",
    "S30": "§30 Bootstrap: How to Start on Day 1",
    "S31": "§31 Simplified Village Version",
    "S32": "§32 The Bulletproof Test",
    "S33": "§33 Historical Precedents",
    "S34": "§34 Final Statement",
}

LAYOUT_CONFIG = {
    "font_families": {
        'EBGaramond': {
            'url': 'https://gwfh.mranftl.com/api/fonts/eb-garamond?download=zip&subsets=latin&formats=ttf',
            'mapping': {
                'regular.ttf': 'EBGaramond-Regular.ttf',
                '700.ttf': 'EBGaramond-Bold.ttf',
                'italic.ttf': 'EBGaramond-Italic.ttf',
                '700italic.ttf': 'EBGaramond-BoldItalic.ttf'
            }
        },
        'LibreFranklin': {
            'url': 'https://gwfh.mranftl.com/api/fonts/libre-franklin?download=zip&subsets=latin&formats=ttf',
            'mapping': {
                'regular.ttf': 'LibreFranklin-Regular.ttf',
                '700.ttf': 'LibreFranklin-Bold.ttf',
                'italic.ttf': 'LibreFranklin-Italic.ttf',
                '700italic.ttf': 'LibreFranklin-BoldItalic.ttf'
            }
        }
    },
    "font_dir": "fonts/english",
    "font_mapping": {
        "sans": "LibreFranklin",
        "sans_bold": "LibreFranklin-Bold",
        "sans_oblique": "LibreFranklin-Italic",
        "serif": "EBGaramond",
        "serif_bold": "EBGaramond-Bold",
        "serif_italic": "EBGaramond-Italic",
        "mono": "Courier"
    },
    "shaping": False,
    "style_overrides": {},
    "toc_groups": {
        "S1": "§1 One-Page Summary",
        "S2": "§2 Full Explanation — The Five Principles — Seven-Layer Tamper Resistance",
        "S3": "§3 Core Numbers (R-01 – R-19) · §4 Land Rules (R-20 – R-30)",
        "S5": "§5 Integrity Rules (R-31 – R-43) · §6 Inheritance Rules (R-44 – R-50)",
        "S7": "§7 Enforcement (Enf-1–5) · §8 Resident List (RL-1–8) · §9 Capture Prevention (Cap-1–8)",
        "S10": "§10 Continuity (Cont-1–5) · §11 Economic (Econ-1–7) · §12 Protection (Prot-1–19)",
        "S13": "§13 Attack Fix Rules (Fix-R-02 – Fix-R-10)",
        "S14": "§14 The Six Registers",
        "S15": "§15 The Six Roles",
        "S16": "§16 All 15 Workflows\n      WF 1-5: Bootstrap · Daan · Weekly Audit · Voting · Dispute Resolution\n      WF 6-10: Inheritance · Collective Land · Subdivision · Merger · Inter-Village\n      WF 11-15: Disaster Recovery · Exit · Recorder Handover · Enforcement · Capture Response",
        "S17": "§17 Attack Tests & Protection Framework",
        "S19": "§19 Enforcement Spine & Capture Response",
        "S21": "§21 Sustainability: Training · Resident List · Continuity · Economic Gravity",
        "S25": "§25 External & Legal: Inter-Village · Legal Anchoring · Legislative Pathway",
        "S28": "§28 Emergencies & Closure",
        "S30": "§30 Reference: Bootstrap · Simplified Version · Bulletproof Test · Historical Precedents"
    },
    "rule_families_box": {
        "title": "Rule Families — Quick Reference",
        "col1_text": "<b>R-</b> Core rules (R-01 – R-50) = 50<br/><b>Fix-R-</b> Fraud fix rules (Fix-R-02 – Fix-R-10) = 9<br/><b>Protection-</b> Equity protections (1–19) = 19<br/><b>Legal-</b> Legal anchoring (1–10) = 10",
        "col2_text": "<b>Enf-</b> Enforcement (1–5) = 5<br/><b>RL-</b> Resident list (1–8) = 8<br/><b>Cap-</b> Capture prevention (1–8) = 8<br/><b>Cont-</b> Continuity (1–5) = 5 · <b>Econ-</b> Economic (1–7) = 7",
        "footer_text": "Total: 121 rules · 15 workflows · 6 registers · 6 roles"
    },
    "compaction": {
        "phase_p_top_bot": 0.8,
        "phase_b_bot": 1.2,
        "phase_sp_val": 1.0,
        
        "legal_rules_use_custom_style": True,
        "legal_rules_style_params": {
            "size": 9.2,
            "leading": 12.5
        },
        "legal_rules_padding_tb": 1.0,
        "legal_rules_space_after": 0.5,
        
        "back_cover_callout_style": "BackCoverCalloutTxt",
        "back_cover_final_style": "BackCoverFinalStatement",
        "back_cover_final_padding": 3.5,
        "back_cover_final_sp_before": 1.5,
        "back_cover_final_sp_after": 2.0
    }
}

