#!/usr/bin/env python3
# =============================================================================
#  BHUMI TRUST — PDF Generator  v5.0
#
#  Run with NO arguments  →  interactive menu (arrow keys + Enter)
#  Run with argument      →  direct generation
#
#  Examples:
#    python generate.py              (shows menu)
#    python generate.py english      (English PDF, no menu)
#    python generate.py hindi        (Hindi PDF, no menu)
#    python generate.py --check      (check system, no PDF)
#
#  Requires:  pip install reportlab
#  Hindi PDF: sudo apt-get install fonts-freefont-ttf   (Linux)
#             Download FreeSerif fonts manually          (Windows)
# =============================================================================

import sys
import os

# ─────────────────────────────────────────────────────────────────────────────
#  STEP 0 — Dependency check (always runs first)
# ─────────────────────────────────────────────────────────────────────────────
def check_and_download_design_fonts(lang=None):
    """Check and automatically download design fonts for the given language (or all available languages)."""
    import urllib.request
    import zipfile
    import io
    import glob

    here = os.path.dirname(os.path.abspath(__file__))
    
    # Identify which families we need to download
    families = {}
    if lang:
        try:
            mod = __import__(f"content_{lang}")
            if hasattr(mod, 'LAYOUT_CONFIG') and 'font_families' in mod.LAYOUT_CONFIG:
                families.update(mod.LAYOUT_CONFIG['font_families'])
        except Exception:
            pass
    else:
        # Check all available language contents
        for cf in glob.glob(os.path.join(here, 'content_*.py')):
            lang_name = os.path.basename(cf)[8:-3]
            try:
                mod = __import__(f"content_{lang_name}")
                if hasattr(mod, 'LAYOUT_CONFIG') and 'font_families' in mod.LAYOUT_CONFIG:
                    families.update(mod.LAYOUT_CONFIG['font_families'])
            except Exception:
                pass

    if not families:
        return True

    # Check if all files for these families already exist under their respective directories
    missing_any = False
    for fam_name, config in families.items():
        font_dir_name = "fonts"
        for cf in glob.glob(os.path.join(here, 'content_*.py')):
            lang_name = os.path.basename(cf)[8:-3]
            try:
                mod = __import__(f"content_{lang_name}")
                if hasattr(mod, 'LAYOUT_CONFIG') and fam_name in mod.LAYOUT_CONFIG.get('font_families', {}):
                    font_dir_name = mod.LAYOUT_CONFIG.get('font_dir', 'fonts')
                    break
            except Exception:
                pass
        
        target_dir = os.path.join(here, font_dir_name)
        
        for suffix, dest_name in config['mapping'].items():
            if not os.path.exists(os.path.join(target_dir, dest_name)):
                missing_any = True
                break
        if missing_any:
            break

    if not missing_any:
        return True

    print("\n  [INFO] Premium design fonts are required. Downloading from Google Web Fonts Helper...")

    for fam_name, config in families.items():
        font_dir_name = "fonts"
        for cf in glob.glob(os.path.join(here, 'content_*.py')):
            lang_name = os.path.basename(cf)[8:-3]
            try:
                mod = __import__(f"content_{lang_name}")
                if hasattr(mod, 'LAYOUT_CONFIG') and fam_name in mod.LAYOUT_CONFIG.get('font_families', {}):
                    font_dir_name = mod.LAYOUT_CONFIG.get('font_dir', 'fonts')
                    break
            except Exception:
                pass
        
        target_dir = os.path.join(here, font_dir_name)
        os.makedirs(target_dir, exist_ok=True)
        
        family_missing = [dest_name for suffix, dest_name in config['mapping'].items() 
                          if not os.path.exists(os.path.join(target_dir, dest_name))]
        if not family_missing:
            continue
            
        print(f"  Downloading {fam_name} ZIP ...")
        try:
            req = urllib.request.Request(
                config['url'],
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()
            
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                sorted_suffixes = sorted(config['mapping'].keys(), key=len, reverse=True)
                for zname in z.namelist():
                    for suffix in sorted_suffixes:
                        if zname.endswith(suffix):
                            dest_name = config['mapping'][suffix]
                            content_data = z.read(zname)
                            dest = os.path.join(target_dir, dest_name)
                            with open(dest, 'wb') as f:
                                f.write(content_data)
                            print(f"    [OK] Extracted: {font_dir_name}/{dest_name}")
                            break
        except Exception as e:
            print(f"  [ERROR] Failed to download {fam_name}: {e}")
            return False
            
    return True



def check_deps():
    """Check and install/report all dependencies."""
    ok = True

    # reportlab
    try:
        import reportlab
        rl_ver = reportlab.Version
    except ImportError:
        print("  [MISSING] reportlab -- run:  pip install reportlab")
        ok = False
    else:
        print(f"  [OK]      reportlab {rl_ver}")

    # Design fonts check
    here = os.path.dirname(os.path.abspath(__file__))
    import glob
    missing_fonts = []
    for cf in glob.glob(os.path.join(here, 'content_*.py')):
        lang_name = os.path.basename(cf)[8:-3]
        try:
            mod = __import__(f"content_{lang_name}")
            if hasattr(mod, 'LAYOUT_CONFIG'):
                f_dir = mod.LAYOUT_CONFIG.get('font_dir', 'fonts')
                target_dir = os.path.join(here, f_dir)
                for fam_name, config in mod.LAYOUT_CONFIG.get('font_families', {}).items():
                    for suffix, dest_name in config['mapping'].items():
                        path = os.path.join(target_dir, dest_name)
                        if not os.path.exists(path):
                            missing_fonts.append(f"{f_dir}/{dest_name}")
        except Exception:
            pass

    if not missing_fonts:
        print("  [OK]      Premium design fonts found and organized")
    else:
        print(f"  [WARN]    Missing design fonts: {', '.join(missing_fonts)}")
        print("            They will be automatically downloaded during PDF generation.")

    # content files
    for cf in sorted(glob.glob(os.path.join(here, 'content_*.py'))):
        print(f"  [OK]      {os.path.basename(cf)}")

    return ok, True


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 1 — Interactive terminal menu
# ─────────────────────────────────────────────────────────────────────────────

def show_menu():
    """
    Full-screen terminal menu with arrow key navigation.
    Returns chosen language string, or None to quit.
    """
    import shutil
    import glob

    # Detect available languages
    here = os.path.dirname(os.path.abspath(__file__))
    options = []
    for cf in sorted(glob.glob(os.path.join(here, 'content_*.py'))):
        lang_name = os.path.basename(cf)[8:-3]
        label_lang = lang_name.capitalize()
        options.append((lang_name, f"{label_lang} PDF    (bhumi_trust_{lang_name}.pdf)"))
    options.append(('check',   'Check system  (dependencies + fonts)'))
    options.append(('quit',    'Quit'))

    selected = 0
    WIDTH = min(shutil.get_terminal_size((80, 24)).columns, 80)

    def clear():
        os.system('cls' if os.name == 'nt' else 'clear')

    def draw(sel):
        clear()
        # Title box
        print("=" * WIDTH)
        title = "  BHUMI TRUST — PDF Generator  v5.0"
        print(title)
        print("  Bhumi Trust Land Governance System")
        print("=" * WIDTH)
        print()
        print("  Select language / action:")
        print()
        for i, (key, label) in enumerate(options):
            if i == sel:
                print(f"  --> {label}")
            else:
                print(f"      {label}")
        print()
        print("-" * WIDTH)
        print("  Arrow keys: UP / DOWN      Enter: Select      Q: Quit")
        print("=" * WIDTH)

    # Try curses (Linux/Mac) first, fall back to simple numbered menu
    try:
        import curses

        def curses_menu(stdscr):
            nonlocal selected
            curses.curs_set(0)
            curses.use_default_colors()
            while True:
                stdscr.clear()
                h, w = stdscr.getmaxyx()
                # Header
                header = "BHUMI TRUST  --  PDF Generator  v5.0"
                stdscr.addstr(0, 0, "=" * min(w-1, 70))
                stdscr.addstr(1, 2, header[:w-3])
                stdscr.addstr(2, 2, "Bhumi Trust Land Governance System"[:w-3])
                stdscr.addstr(3, 0, "=" * min(w-1, 70))
                stdscr.addstr(5, 2, "Select language / action:"[:w-3])
                # Options
                for i, (key, label) in enumerate(options):
                    row = 7 + i
                    if row >= h - 4:
                        break
                    if i == selected:
                        stdscr.attron(curses.A_REVERSE | curses.A_BOLD)
                        stdscr.addstr(row, 2, f"  {label}"[:w-3])
                        stdscr.attroff(curses.A_REVERSE | curses.A_BOLD)
                    else:
                        stdscr.addstr(row, 4, label[:w-5])
                # Footer
                footer_row = min(7 + len(options) + 2, h - 2)
                stdscr.addstr(footer_row, 0, "-" * min(w-1, 70))
                stdscr.addstr(footer_row+1, 2,
                              "UP/DOWN: navigate   ENTER: select   Q: quit"[:w-3])
                stdscr.refresh()

                key = stdscr.getch()
                if key in (curses.KEY_UP, ord('k'), ord('K')):
                    selected = (selected - 1) % len(options)
                elif key in (curses.KEY_DOWN, ord('j'), ord('J')):
                    selected = (selected + 1) % len(options)
                elif key in (curses.KEY_ENTER, ord('\n'), ord('\r'), 10, 13):
                    return options[selected][0]
                elif key in (ord('q'), ord('Q'), 27):  # Q or ESC
                    return 'quit'

        result = curses.wrapper(curses_menu)
        return result

    except Exception:
        # Fall back: simple numbered menu for Windows / no-tty
        draw(selected)
        while True:
            raw = input("  Enter number (1-{}): ".format(len(options))).strip()
            if raw.lower() in ('q', 'quit', 'exit'):
                return 'quit'
            try:
                n = int(raw) - 1
                if 0 <= n < len(options):
                    return options[n][0]
            except ValueError:
                pass
            print("  Please enter a number between 1 and {}".format(len(options)))


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 2 — Font auto-download (optional, Windows-friendly)
# ─────────────────────────────────────────────────────────────────────────────

# offer_font_download was removed as design fonts download is fully dynamic.


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 3 — Main entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    # Direct mode: argument given
    if args:
        arg = args[0].lower()
        if arg == '--check':
            print()
            print("  Checking Bhumi Trust PDF Generator dependencies...")
            print()
            ok, hindi_ok = check_deps()
            print()
            print("  Status:", "READY" if ok else "MISSING DEPENDENCIES - fix above errors")
            sys.exit(0 if ok else 1)
        # Pass through to generator below
        lang_arg = arg
    else:
        # No argument — show menu
        print()
        print("  Bhumi Trust PDF Generator - starting...")
        lang_arg = show_menu()

    if lang_arg in ('quit', 'exit', None):
        print("  Goodbye.")
        sys.exit(0)

    if lang_arg == 'check':
        print()
        print("  System Check")
        print("  " + "=" * 40)
        ok, hindi_ok = check_deps()
        print()
        # Checked dynamically
        print("  Done.")
        sys.exit(0)

    # Dynamic font check before building
    try:
        mod = __import__(f"content_{lang_arg}")
        if hasattr(mod, 'LAYOUT_CONFIG'):
            config = mod.LAYOUT_CONFIG
            f_dir = config.get('font_dir', 'fonts')
            target_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), f_dir)
            missing = []
            for fam_name, fam_config in config.get('font_families', {}).items():
                for suffix, dest_name in fam_config['mapping'].items():
                    if not os.path.exists(os.path.join(target_dir, dest_name)):
                        missing.append(dest_name)
            
            if missing:
                print(f"\n  WARNING: Fonts for {lang_arg} not installed: {', '.join(missing)}")
                check_and_download_design_fonts(lang_arg)
    except Exception:
        pass

    # Inject the language into sys.argv so the generator code below sees it
    sys.argv = [sys.argv[0], lang_arg]
    return lang_arg


# Run the menu/arg handling
if __name__ != '__no_run__':
    _chosen_lang = main()

# =============================================================================
#  ↓↓↓  ORIGINAL GENERATOR CODE BELOW — do not edit unless you know what
#         you are doing. All content lives in content_english.py / content_hindi.py
# =============================================================================

import sys
import os
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from content_english import *


# ── Load language content ──────────────────────────────────────────────
lang = sys.argv[1].lower() if len(sys.argv) > 1 else "english"

try:
    lang_module = __import__(f"content_{lang}")
    # Inject all public variables into global namespace
    for name in dir(lang_module):
        if not name.startswith('_'):
            globals()[name] = getattr(lang_module, name)
except ImportError:
    print(f"ERROR: content_{lang}.py not found.")
    sys.exit(1)

OUTPUT_FILE = f"bhumi_trust_{lang}.pdf"

# ── ReportLab imports ──────────────────────────────────────────────────
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame,
    Paragraph, Table, TableStyle, Spacer,
    PageBreak, KeepTogether, HRFlowable
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfgen import canvas as pdfcanvas

# ── Monkeypatch ReportLab shaping bug (IndexError in Table of Contents) ─
import reportlab.pdfbase.ttfonts as ttf
import reportlab.platypus.paragraph as rlp

original_shapeFragWord = ttf.shapeFragWord

def patched_shapeFragWord(w, *args, **kwargs):
    res = original_shapeFragWord(w, *args, **kwargs)
    if isinstance(res, list):
        for idx in range(1, len(res)):
            item = res[idx]
            if isinstance(item, list) and not isinstance(item, tuple):
                if len(item) == 1:
                    res[idx] = (item[0], '')
    return res

ttf.shapeFragWord = patched_shapeFragWord
rlp.shapeFragWord = patched_shapeFragWord


# ── Page dimensions ────────────────────────────────────────────────────
PAGE_W, PAGE_H = A4
MARGIN_L = 18 * mm
MARGIN_R = 14 * mm
MARGIN_T = 18 * mm
MARGIN_B = 20 * mm
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R

# ── NATURE-INSPIRED COLOR PALETTE (PREMIUM BLUEPRINT DESIGN) ──────────
COLOR_PRIMARY       = colors.HexColor('#1B5E20') # Deep Forest Green
COLOR_PRIMARY_LIGHT = colors.HexColor('#2E7D32') # Medium Forest Green
COLOR_PRIMARY_MID   = colors.HexColor('#388E3C') # Accent Green
COLOR_PRIMARY_BG    = colors.HexColor('#F1F8E9') # Soft Mint Background
COLOR_ACCENT        = colors.HexColor('#E65100') # Rich Amber
COLOR_ACCENT_WARM   = colors.HexColor('#F57F17') # Warm Amber / Border Accent
COLOR_ACCENT_BG     = colors.HexColor('#FFF8E1') # Light Sand / Warm Accent Background
COLOR_EARTH         = colors.HexColor('#4E342E') # Warm Earth Brown
COLOR_GOLD          = colors.HexColor('#F9A825') # Premium Gold Highlight
COLOR_NEAR_BLACK    = colors.HexColor('#1A1A1A') # Premium Dark Text
COLOR_DARK_GREY     = colors.HexColor('#424242') # Muted Captions / Secondary text
COLOR_LIGHT_GREY    = colors.HexColor('#F5F5F5') # Soft Grey Backgrounds
COLOR_RULE_GREY     = colors.HexColor('#BDBDBD') # Neutral Border Grey
COLOR_WHITE         = colors.white

BLACK      = COLOR_NEAR_BLACK
WHITE      = COLOR_WHITE
DARK       = COLOR_PRIMARY
NAVY       = COLOR_PRIMARY_LIGHT
NAVY_LIGHT = COLOR_PRIMARY_MID
FOREST     = COLOR_PRIMARY
EARTH      = COLOR_EARTH
GREY_DARK  = COLOR_NEAR_BLACK
GREY_MID   = COLOR_DARK_GREY
GREY_LIGHT = COLOR_RULE_GREY
GREY_BG    = COLOR_PRIMARY_BG
GREY_RULE  = COLOR_RULE_GREY
GREY_BOX   = COLOR_PRIMARY_BG
ACCENT_BG  = COLOR_ACCENT_BG
WARN_BG    = COLOR_ACCENT_BG


# ── Font setup ────────────────────────────────────────────────────────
FONT_SANS         = "Helvetica"
FONT_SANS_BOLD    = "Helvetica-Bold"
FONT_SANS_OBLIQUE = "Helvetica-Oblique"
FONT_SERIF        = "Times-Roman"
FONT_SERIF_BOLD   = "Times-Bold"
FONT_SERIF_ITALIC = "Times-Italic"
FONT_MONO         = "Courier"

_HERE = os.path.dirname(os.path.abspath(__file__))

# Try to download design fonts if missing for the current language
check_and_download_design_fonts(lang)

font_dir_name = LAYOUT_CONFIG.get("font_dir", "fonts")
target_font_dir = os.path.join(_HERE, font_dir_name)

def find_font_file(filename, fallback_names=None):
    search_dirs = [
        target_font_dir,
        _HERE,
        r'C:\Windows\Fonts',
        '/usr/share/fonts/truetype/freefont',
        '/usr/share/fonts/truetype/freefont-ttf',
        '/usr/local/share/fonts',
        os.path.expanduser('~/Library/Fonts'),
        '/Library/Fonts',
    ]
    names = [filename] + (fallback_names or [])
    for d in search_dirs:
        for name in names:
            p = os.path.join(d, name)
            if os.path.exists(p):
                return p
    return None

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

design_fonts_registered = False
try:
    families = LAYOUT_CONFIG.get("font_families", {})
    registered_families = []
    
    for fam_name, config in families.items():
        fam_mapping = config['mapping']
        family_ok = True
        for suffix, dest_name in fam_mapping.items():
            if not find_font_file(dest_name):
                family_ok = False
                break
        
        if family_ok:
            font_names = {}
            for suffix, dest_name in fam_mapping.items():
                p = find_font_file(dest_name)
                style_key = 'normal'
                if suffix == '700.ttf':
                    style_key = 'bold'
                elif suffix == 'italic.ttf':
                    style_key = 'italic'
                elif suffix == '700italic.ttf':
                    style_key = 'boldItalic'
                
                font_label = f"{fam_name}-Bold" if style_key == 'bold' else (
                             f"{fam_name}-Italic" if style_key == 'italic' else (
                             f"{fam_name}-BoldItalic" if style_key == 'boldItalic' else fam_name))
                pdfmetrics.registerFont(TTFont(font_label, p))
                font_names[style_key] = font_label
            
            f_normal = font_names.get('normal')
            f_bold = font_names.get('bold', f_normal)
            f_italic = font_names.get('italic', f_normal)
            f_bold_italic = font_names.get('boldItalic', f_bold)
            
            pdfmetrics.registerFontFamily(fam_name, normal=f_normal, bold=f_bold, italic=f_italic, boldItalic=f_bold_italic)
            registered_families.append(fam_name)
            
    if registered_families:
        print(f"  Design fonts: Registered {', '.join(registered_families)} successfully")
        design_fonts_registered = True
except Exception as e:
    print(f"  [WARN] Failed to register design fonts: {e}")

# Apply font mapping from LAYOUT_CONFIG
font_mapping = LAYOUT_CONFIG.get("font_mapping", {})
FONT_SANS         = font_mapping.get("sans", "Helvetica")
FONT_SANS_BOLD    = font_mapping.get("sans_bold", "Helvetica-Bold")
FONT_SANS_OBLIQUE = font_mapping.get("sans_oblique", "Helvetica-Oblique")
FONT_SERIF        = font_mapping.get("serif", "Times-Roman")
FONT_SERIF_BOLD   = font_mapping.get("serif_bold", "Times-Bold")
FONT_SERIF_ITALIC = font_mapping.get("serif_italic", "Times-Italic")
FONT_MONO         = font_mapping.get("mono", "Courier")

# If design fonts registration failed or not all mapping fonts exist, try system fallback for Devanagari/shaping
if not design_fonts_registered and LAYOUT_CONFIG.get("shaping", False):
    _serif      = find_font_file('FreeSerif.ttf')
    _serif_bold = find_font_file('FreeSerifBold.ttf')
    _sans       = find_font_file('FreeSans.ttf')
    _sans_bold  = find_font_file('FreeSansBold.ttf')

    if _serif and _serif_bold and _sans and _sans_bold:
        pdfmetrics.registerFont(TTFont('FreeSerif',     _serif))
        pdfmetrics.registerFont(TTFont('FreeSerifBold', _serif_bold))
        pdfmetrics.registerFont(TTFont('FreeSans',      _sans))
        pdfmetrics.registerFont(TTFont('FreeSansBold',  _sans_bold))
        FONT_SANS         = "FreeSans"
        FONT_SANS_BOLD    = "FreeSansBold"
        FONT_SANS_OBLIQUE = "FreeSans"
        FONT_MONO         = "FreeSerif"
        FONT_SERIF        = "FreeSerif"
        FONT_SERIF_BOLD   = "FreeSerifBold"
        FONT_SERIF_ITALIC = "FreeSerif"
        print("  Fallback fonts: FreeSerif and FreeSans registered from fallback search")
    elif _serif:
        pdfmetrics.registerFont(TTFont('FreeSerif', _serif))
        FONT_SANS         = "FreeSerif"
        FONT_SANS_BOLD    = "FreeSerif"
        FONT_SANS_OBLIQUE = "FreeSerif"
        FONT_MONO         = "FreeSerif"
        FONT_SERIF        = "FreeSerif"
        FONT_SERIF_BOLD   = "FreeSerif"
        FONT_SERIF_ITALIC = "FreeSerif"
        print("  Fallback fonts: FreeSerif registered (partial) from fallback search")
    else:
        print("  WARNING: Fallback fonts not found. Fallback to standard Helvetica/Times.")


# =============================================================================
# PARAGRAPH STYLES
# =============================================================================

# When shaping is enabled in LAYOUT_CONFIG, we set shaping=1 on all paragraph
# styles to enable HarfBuzz glyph-composition (Devanagari consonant clusters)
_SHAPING = 1 if LAYOUT_CONFIG.get("shaping", False) else 0

def make_style(name, font=FONT_SANS, size=9, leading=14, color=BLACK,
               align=TA_LEFT, space_before=0, space_after=2,
               left_indent=0, bold=False):
    f = FONT_SANS_BOLD if bold else font
    ps = ParagraphStyle(
        name=name,
        fontName=f,
        fontSize=size,
        leading=leading,
        textColor=color,
        alignment=align,
        spaceBefore=space_before * mm,
        spaceAfter=space_after * mm,
        leftIndent=left_indent * mm,
    )
    if _SHAPING:
        ps.shaping = 1
    return ps

# ── BASE STYLES — generous leading, clear hierarchy ─────────────────
S_NORMAL     = make_style("Normal",      size=10,  leading=15)
S_NORMAL_J   = make_style("NormalJ",     size=10,  leading=15,  align=TA_JUSTIFY)
S_SMALL      = make_style("Small",       size=8.5, leading=13)
S_SMALL_GREY = make_style("SmallGrey",   size=8.5, leading=13,  color=GREY_MID)
S_ITALIC     = make_style("Italic",      font=FONT_SANS_OBLIQUE, size=10, leading=15)
S_ITALIC_SM  = make_style("ItalicSm",   font=FONT_SANS_OBLIQUE, size=9,  leading=13, color=GREY_MID)
S_MONO       = make_style("Mono",        font=FONT_MONO, size=8.5, leading=13)

# ── SECTION AND PART HEADERS ──────────────────────────────────────────
S_PART_NUM   = make_style("PartNum",     size=18,  color=COLOR_GOLD, bold=True)
S_PART_TITLE = make_style("PartTitle",   size=16,  color=WHITE, bold=True, leading=20)
S_SECTION    = make_style("Section",     size=11,  bold=True,   space_before=6, space_after=3, color=COLOR_PRIMARY)
S_SUBSECTION = make_style("Subsection",  size=10,  bold=True,   space_before=4, space_after=2,
                           left_indent=0, color=COLOR_PRIMARY_LIGHT)

# ── RULE STYLES ───────────────────────────────────────────────────────
S_RULE_TAG   = make_style("RuleTag",     size=8,   color=WHITE, bold=True, align=TA_CENTER)
S_RULE_BODY  = make_style("RuleBody",    size=10,  leading=15, color=COLOR_NEAR_BLACK)
S_RULE_NOTE  = make_style("RuleNote",    font=FONT_SANS_OBLIQUE, size=9, leading=13,
                           color=COLOR_DARK_GREY, space_before=1)

# ── WORKFLOW STYLES ───────────────────────────────────────────────────
S_WF_HEADER  = make_style("WfHeader",    size=11,  color=WHITE, bold=True)
S_WF_USE     = make_style("WfUse",       font=FONT_SANS_OBLIQUE, size=9, color=COLOR_ACCENT)
S_WF_NUM     = make_style("WfNum",       size=9,   bold=True, color=COLOR_PRIMARY)
S_WF_BODY    = make_style("WfBody",      size=10,  leading=15, color=COLOR_NEAR_BLACK)

# ── REGISTER STYLES ───────────────────────────────────────────────────
S_REG_HEADER = make_style("RegHeader",   size=10,  color=WHITE, bold=True)
S_REG_NB     = make_style("RegNb",       size=8,   color=COLOR_PRIMARY_BG, bold=True)
S_FIELD_NAME = make_style("FieldName",   size=9.5,   bold=True, color=COLOR_PRIMARY_LIGHT)
S_FIELD_DESC = make_style("FieldDesc",   size=9,   leading=13, color=COLOR_NEAR_BLACK)

# ── ATTACK STYLES ─────────────────────────────────────────────────────
S_ATK_HEADER = make_style("AtkHeader",   size=10,  color=WHITE, bold=True)
S_ATK_NUM    = make_style("AtkNum",      size=8,   color=COLOR_ACCENT_BG, bold=True)
S_ATK_LABEL  = make_style("AtkLabel",    size=8.5,   bold=True,   color=COLOR_ACCENT)
S_ATK_BODY   = make_style("AtkBody",     size=9,   leading=13, color=COLOR_NEAR_BLACK)
S_ATK_FIX    = make_style("AtkFix",      size=8.5, bold=True, color=COLOR_PRIMARY)

# ── COVER STYLES ──────────────────────────────────────────────────────
S_COVER_TAG  = make_style("CoverTag",    size=10,   bold=True,   color=COLOR_GOLD)
S_COVER_TITLE= make_style("CoverTitle",  size=30,  bold=True,   leading=36, color=WHITE)
S_COVER_SUB  = make_style("CoverSub",    size=12,  color=COLOR_PRIMARY_BG)
S_COVER_BODY = make_style("CoverBody",   size=10,  leading=16, color=COLOR_NEAR_BLACK)
S_COVER_NOTE = make_style("CoverNote",   font=FONT_SANS_OBLIQUE, size=9.5, color=COLOR_DARK_GREY, leading=14)

# ── TOC STYLES ────────────────────────────────────────────────────────
S_TOC_PART   = make_style("TocPart",     size=10,  bold=True, color=COLOR_PRIMARY)
S_TOC_SEC    = make_style("TocSec",      size=9,   left_indent=5, color=COLOR_NEAR_BLACK)

# ── CALLOUT ───────────────────────────────────────────────────────────
S_CALLOUT_LBL= make_style("CalloutLbl",  size=8.5,   bold=True, color=COLOR_ACCENT)
S_CALLOUT_TXT= make_style("CalloutTxt",  size=10,  leading=16, color=COLOR_NEAR_BLACK)

# ── NUMBER GRID ───────────────────────────────────────────────────────
S_NUM_ID     = make_style("NumId",       size=7.5, bold=True,   color=COLOR_DARK_GREY)
S_NUM_VAL    = make_style("NumVal",      size=22,  bold=True,   leading=26, color=COLOR_PRIMARY)
S_REF_NUM_VAL = make_style("RefNumVal",  size=16,  bold=True,   leading=20, color=COLOR_PRIMARY)
S_NUM_DESC   = make_style("NumDesc",     size=8,   leading=12,  color=COLOR_DARK_GREY)

# ── SIMPLIFIED VILLAGE VERSION — very large, easy to read ────────────
# These styles are for people who may not read well
S_SIMP_HEAD  = make_style("SimpHead",    size=13,  bold=True, color=COLOR_PRIMARY)
S_SIMP_BODY  = make_style("SimpBody",    size=12,  leading=19, color=COLOR_NEAR_BLACK)
S_SIMP_LARGE = make_style("SimpLarge",   size=14,  leading=21, bold=True, color=COLOR_PRIMARY)
S_SIMP_NUM   = make_style("SimpNum",     size=26,  bold=True,  leading=30, align=TA_CENTER, color=COLOR_PRIMARY)
S_SIMP_LABEL = make_style("SimpLabel",   size=10,  leading=14, align=TA_CENTER, color=COLOR_DARK_GREY)

# ── PRECEDENT ─────────────────────────────────────────────────────────
S_PREC_TITLE = make_style("PrecTitle",   size=10,  bold=True, color=COLOR_PRIMARY)
S_PREC_BODY  = make_style("PrecBody",    size=9.5, leading=14, align=TA_JUSTIFY, color=COLOR_NEAR_BLACK)
S_PREC_LESSON= make_style("PrecLesson",  font=FONT_SANS_OBLIQUE, size=9, color=COLOR_ACCENT,
                            leading=13, left_indent=3)

# ── BULLETPROOF TEST ──────────────────────────────────────────────────
S_TEST_Q     = make_style("TestQ",       size=9.5, leading=14, color=COLOR_NEAR_BLACK)
S_TEST_PASS  = make_style("TestPass",    size=8,   bold=True,  color=COLOR_PRIMARY)

# ── ROLE ──────────────────────────────────────────────────────────────
S_ROLE_NAME  = make_style("RoleName",    size=11,  bold=True,  color=WHITE)
S_ROLE_WHO   = make_style("RoleWho",     font=FONT_SANS_OBLIQUE, size=9, color=COLOR_PRIMARY_BG)
S_ROLE_LBL   = make_style("RoleLbl",     size=8.5,   bold=True, color=COLOR_EARTH)
S_ROLE_ITEM  = make_style("RoleItem",    size=9.5, leading=14)

# ── TIMELINE ──────────────────────────────────────────────────────────
S_TL_YEAR    = make_style("TlYear",      size=9,   bold=True)
S_TL_DESC    = make_style("TlDesc",      size=9,   leading=13)

# ── PHASE ─────────────────────────────────────────────────────────────
S_PHASE_HEAD = make_style("PhaseHead",   size=9,   bold=True,  color=WHITE)
S_PHASE_GOAL = make_style("PhaseGoal",   font=FONT_SANS_OBLIQUE, size=8.5, leading=11)
S_PHASE_BODY = make_style("PhaseBody",   size=8.5,   leading=11)

# ── BACK COVER CUSTOM COMPACT STYLES (for English page alignment) ─────
S_BACK_COVER_CALLOUT_TXT = make_style("BackCoverCalloutTxt", size=8.5, leading=12.0)
S_BACK_COVER_FINAL_STATEMENT = make_style("BackCoverFinalStatement", size=8.0, leading=10.5)

# Apply style overrides from LAYOUT_CONFIG
style_overrides = LAYOUT_CONFIG.get("style_overrides", {})
import re
for s_name, params in style_overrides.items():
    # Convert CamelCase to S_SNAKE_CASE (e.g. TestQ -> S_TEST_Q, NormalJ -> S_NORMAL_J)
    s = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', s_name)
    s = re.sub('([a-z0-9])([A-Z])', r'\1_\2', s)
    target_var = "S_" + s.upper()
    
    if target_var in globals():
        orig_style = globals()[target_var]
        size = params.get("size", orig_style.fontSize)
        leading = params.get("leading", orig_style.leading)
        font_name = orig_style.fontName
        globals()[target_var] = make_style(
            orig_style.name + "2",
            font=font_name,
            size=size,
            leading=leading,
            color=orig_style.textColor,
            align=orig_style.alignment,
            space_before=orig_style.spaceBefore / mm,
            space_after=orig_style.spaceAfter / mm,
            left_indent=orig_style.leftIndent / mm
        )

# Apply shaping=1 to all ParagraphStyles in globals if shaping is enabled
if _SHAPING:
    for name, value in list(globals().items()):
        if isinstance(value, ParagraphStyle):
            value.shaping = 1



def canvas_text(text, font_name, font_size):
    """Shape text for raw canvas drawing in Devanagari if shaping is enabled."""
    if _SHAPING:
        try:
            from reportlab.pdfbase.ttfonts import shapeStr
            return shapeStr(text, font_name, font_size)
        except Exception:
            pass
    return text


# =============================================================================
# CUSTOM CANVAS - Page numbers + footer
# =============================================================================

class NumberedCanvas(pdfcanvas.Canvas):
    def __init__(self, *args, **kwargs):
        pdfcanvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            pdfcanvas.Canvas.showPage(self)
        pdfcanvas.Canvas.save(self)

    def draw_page_number(self, page_count):
        page = self._pageNumber
        # Skip cover (page 1)
        if page <= 1:
            return
        self.saveState()
        
        # ── RUNNING HEADER (Skip Cover and TOC Page) ──────────────────────
        if page > 2:
            self.setFont(FONT_SANS, 7)
            self.setFillColor(COLOR_DARK_GREY)
            header_text = f"{DOC_TITLE.upper()} — {DOC_VERSION}"
            header_shaped = canvas_text(header_text, FONT_SANS, 7)
            self.drawCentredString(PAGE_W / 2, PAGE_H - 10 * mm, header_shaped)
            
            self.setStrokeColor(COLOR_PRIMARY_LIGHT)
            self.setLineWidth(0.75)
            self.line(MARGIN_L, PAGE_H - 12 * mm, PAGE_W - MARGIN_R, PAGE_H - 12 * mm)
            
        # ── RUNNING FOOTER (Skip Cover) ──────────────────────────────────
        self.setFont(FONT_SANS, 7)
        self.setFillColor(COLOR_DARK_GREY)
        
        # Left-aligned document title
        footer_left = f"{DOC_TITLE}  ·  {DOC_VERSION}"
        footer_left_shaped = canvas_text(footer_left, FONT_SANS, 7)
        self.drawString(MARGIN_L, 10 * mm, footer_left_shaped)
        
        # Right-aligned page number
        footer_right = f"Page {page} of {page_count}"
        footer_right_shaped = canvas_text(footer_right, FONT_SANS, 7)
        self.drawRightString(PAGE_W - MARGIN_R, 10 * mm, footer_right_shaped)
        self.restoreState()


# =============================================================================
# DOCUMENT SETUP WITH TOC
# =============================================================================

class BhumiDoc(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        BaseDocTemplate.__init__(self, filename, **kwargs)
        self.toc = TableOfContents()
        self.toc.levelStyles = [
            ParagraphStyle(name='TOCPart', fontName=FONT_SANS_BOLD,
                           fontSize=9, leading=14, leftIndent=0,
                           spaceBefore=3, spaceAfter=1),
            ParagraphStyle(name='TOCSec', fontName=FONT_SANS,
                           fontSize=8.5, leading=13, leftIndent=10 * mm,
                           spaceBefore=0, spaceAfter=0.5),
        ]
        for s in self.toc.levelStyles:
            if _SHAPING:
                s.shaping = 1

    def afterFlowable(self, flowable):
        """Register headings for TOC"""
        if hasattr(flowable, 'toc_level'):
            level = flowable.toc_level
            text  = flowable.toc_text
            self.notify('TOCEntry', (level, text, self.page))


def build_doc(story, output_file):
    frame = Frame(
        MARGIN_L, MARGIN_B,
        CONTENT_W, PAGE_H - MARGIN_T - MARGIN_B,
        id='main', leftPadding=0, rightPadding=0,
        topPadding=0, bottomPadding=0
    )
    template = PageTemplate(id='main', frames=[frame])
    doc = BhumiDoc(
        output_file,
        pagesize=A4,
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T,  bottomMargin=MARGIN_B,
        title=DOC_TITLE,
    )
    doc.addPageTemplates([template])
    doc.multiBuild(story, canvasmaker=NumberedCanvas)


# =============================================================================
# HELPER FLOWABLES
# =============================================================================

class TocEntry(Paragraph):
    """A paragraph that also registers a TOC entry"""
    def __init__(self, text, style, toc_level, toc_text):
        Paragraph.__init__(self, text, style)
        self.toc_level = toc_level
        self.toc_text  = toc_text


def sp(n=3):
    """Spacer"""
    return Spacer(1, n * mm)


def hrule(color=GREY_RULE, thickness=0.5, space_before=2, space_after=2):
    return HRFlowable(
        width='100%', thickness=thickness, color=color,
        spaceAfter=space_after * mm, spaceBefore=space_before * mm
    )


def para(text, style=None):
    if style is None:
        style = S_NORMAL
    # Smart escaping: only escape bare & (not already &amp; &lt; &gt;)
    # Leave < > for intentional ReportLab markup tags like <b>, <i>, <br/>
    text = re.sub(r'&(?!amp;|lt;|gt;|apos;|quot;|#)', '&amp;', text)
    return Paragraph(text, style)


def bullet_list(items, style=None, bullet='–'):
    """Render a list of strings as bullet paragraphs"""
    if style is None:
        style = S_NORMAL
    result = []
    for item in items:
        item_clean = item.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        result.append(Paragraph(f'{bullet}  {item_clean}', style))
    return result


def numbered_list(items, style=None):
    """items: list of (num, text) tuples"""
    if style is None:
        style = S_NORMAL
    result = []
    for num, text in items:
        text_clean = text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        result.append(Paragraph(f'<b>{num}.</b>  {text_clean}', style))
    return result


# =============================================================================
# ELEMENT BUILDERS
# =============================================================================

def build_part_header(num_text, title_text, add_toc=True):
    """Deep green bar with Part number and title — forces page break before"""
    num_text_safe   = num_text.replace('&','&amp;')
    title_text_safe = title_text.replace('&','&amp;')

    tbl = Table(
        [[Paragraph(f'<b>{num_text_safe}</b>', S_PART_NUM),
          Paragraph(f'<b>{title_text_safe}</b>', S_PART_TITLE)]],
        colWidths=[32 * mm, CONTENT_W - 32 * mm]
    )
    tbl.setStyle(TableStyle([
        ('BACKGROUND',  (0, 0), (-1, -1), COLOR_PRIMARY),
        ('VALIGN',      (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING',  (0, 0), (-1, -1), 4 * mm),
        ('BOTTOMPADDING',(0, 0),(-1,-1), 4 * mm),
        ('LEFTPADDING', (0, 0), (0, -1), 6 * mm),
        ('RIGHTPADDING',(0, 0), (0, -1), 1 * mm),
        ('LEFTPADDING', (1, 0), (1, -1), 2 * mm),
        ('RIGHTPADDING',(1, 0), (1, -1), 6 * mm),
    ]))
    items = [PageBreak(), sp(0), tbl, sp(6)]
    if add_toc:
        toc_entry = TocEntry('', S_SMALL, 0, f'{num_text} — {title_text}')
        items.insert(2, toc_entry)
    return items


def build_section_header(text, toc=False, toc_text=None):
    """Deep green left-bordered bar with light green background band, matching premium blueprint section header"""
    text_safe = re.sub(r'&(?!amp;|lt;|gt;)', '&amp;', text)
    p = Paragraph(f'<b>{text_safe.upper()}</b>', S_SECTION)

    tbl = Table([[p]], colWidths=[CONTENT_W])
    tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ('LEFTPADDING',  (0,0),(-1,-1), 4 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4 * mm),
        ('TOPPADDING',   (0,0),(-1,-1), 2 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2 * mm),
        ('LINEBEFORE',   (0,0),(0,-1),  4 * mm, COLOR_PRIMARY),
    ]))

    items = [
        sp(4),
        tbl,
        sp(3)
    ]
    if toc:
        # Intercept and dynamically group/combine section entries in TOC
        match = re.search(r'§(\d+)', text)
        if match:
            sec_num = "S" + match.group(1)
            toc_needed, custom_toc_text = get_toc_text(sec_num, toc_text or text)
            toc = toc_needed
            toc_text = custom_toc_text
            
        if toc:
            label = toc_text or text
            toc_entry = TocEntry('', S_SMALL, 1, label)
            items.insert(0, toc_entry)
    return items


def build_subsection_header(text):
    text_safe = text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    p = Paragraph(f'<b>{text_safe.upper()}</b>', S_SUBSECTION)
    tbl = Table([[p]], colWidths=[CONTENT_W])
    tbl.setStyle(TableStyle([
        ('LEFTPADDING', (0,0), (-1,-1), 3 * mm),
        ('TOPPADDING', (0,0), (-1,-1), 1 * mm),
        ('BOTTOMPADDING', (0,0), (-1,-1), 1 * mm),
        ('LINEBEFORE', (0,0), (0,-1), 3, BLACK), # 3pt black left border
    ]))
    return [sp(3), tbl, sp(1.5)]


def build_rule_block(tag, body, tag_color=BLACK, keep=True, style=None, padding_tb=1.5, space_after=1.0):
    """Single rule: [TAG | body text] with clean light border and colored tags"""
    if style is None:
        style = S_RULE_BODY
    tag_safe  = tag.replace('&','&amp;')
    body_safe = body.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    
    # Infer tag color based on the tag prefix if default black is provided
    inferred_color = tag_color
    if tag_color == BLACK or tag_color == colors.black or tag_color == COLOR_NEAR_BLACK:
        if tag.startswith('R-') or tag.startswith('R_'):
            inferred_color = COLOR_PRIMARY
        elif tag.startswith('Enf-') or tag.startswith('E-') or tag.startswith('Enf_'):
            inferred_color = COLOR_ACCENT
        elif tag.startswith('L-') or tag.startswith('Legal-') or tag.startswith('Legal_'):
            inferred_color = COLOR_EARTH
        else:
            inferred_color = COLOR_PRIMARY

    tag_p = Paragraph(f'<b>{tag_safe}</b>', S_RULE_TAG)

    tbl = Table(
        [[tag_p, Paragraph(body_safe, style)]],
        colWidths=[20 * mm, CONTENT_W - 20 * mm]
    )
    tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0, 0), (0, -1), inferred_color),
        ('TEXTCOLOR',    (0, 0), (0, -1), WHITE),
        ('VALIGN',       (0, 0), (-1,-1), 'TOP'),
        ('TOPPADDING',   (0, 0), (-1,-1), padding_tb * mm),
        ('BOTTOMPADDING',(0, 0), (-1,-1), padding_tb * mm),
        ('LEFTPADDING',  (0, 0), (0, -1), 2 * mm),
        ('RIGHTPADDING', (0, 0), (0, -1), 2 * mm),
        ('LEFTPADDING',  (1, 0), (1, -1), 4 * mm),
        ('RIGHTPADDING', (1, 0), (1, -1), 3 * mm),
        ('BACKGROUND',   (1, 0), (1, -1), COLOR_WHITE),
        ('LINEBELOW',    (0, 0), (-1, -1), 0.5, COLOR_RULE_GREY),
        ('LINEBEFORE',   (0, 0), (0, -1), 0.5, COLOR_RULE_GREY),
        ('LINEAFTER',    (1, 0), (1, -1), 0.5, COLOR_RULE_GREY),
        ('LINEABOVE',    (0, 0), (-1, 0), 0.5, COLOR_RULE_GREY),
    ]))
    result = [tbl, sp(space_after)]
    if keep:
        return [KeepTogether(result)]
    return result


def build_rules_group(rules, tag_color=None, style=None, padding_tb=1.5, space_after=1.0):
    """Render a list of (tag, body) rule tuples"""
    if tag_color is None:
        tag_color = DARK
    items = []
    for tag, body in rules:
        items.extend(build_rule_block(tag, body, tag_color=tag_color, style=style, padding_tb=padding_tb, space_after=space_after))
    return items


def build_callout(label, text_or_items, border_thickness=1.5, style=None):
    """Box with label header and body text: clean amber accent left-bordered card style"""
    label_safe = label.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    
    # Custom label style to enforce COLOR_ACCENT
    lbl_style = ParagraphStyle(
        'CalloutLbl_Custom',
        parent=S_CALLOUT_LBL,
        textColor=COLOR_ACCENT
    )
    if _SHAPING:
        lbl_style.shaping = 1
        
    lbl_para = Paragraph(f'<b>{label_safe}</b>', lbl_style)

    if style is None:
        style = S_CALLOUT_TXT

    if isinstance(text_or_items, str):
        body_safe = text_or_items.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        body_para = [Paragraph(body_safe, style)]
    elif isinstance(text_or_items, list):
        body_para = []
        for item in text_or_items:
            if isinstance(item, str):
                item_safe = item.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
                body_para.append(Paragraph(f'–  {item_safe}', style))
            else:
                body_para.append(item)
    else:
        body_para = [text_or_items]

    inner = [lbl_para,
             HRFlowable(width='100%', thickness=0.75, color=COLOR_ACCENT_WARM,
                        spaceBefore=1.5*mm, spaceAfter=2*mm)]
    inner.extend(body_para)

    tbl = Table([[inner]], colWidths=[CONTENT_W])
    tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_ACCENT_BG),
        ('TOPPADDING',   (0,0),(-1,-1), 4 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 5 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 5 * mm),
        ('LINEBEFORE',   (0,0),(0,-1),  4 * mm, COLOR_ACCENT), # 4mm thick left border in amber
        ('BOX',          (0,0),(-1,-1), 0.5, COLOR_RULE_GREY), # thin grey border around the rest
    ]))
    return [KeepTogether([tbl, sp(3)])]


def build_two_col(left_items, right_items, gap=6):
    """Two-column layout using a table"""
    col_w = (CONTENT_W - gap * mm) / 2
    tbl = Table(
        [[left_items, right_items]],
        colWidths=[col_w, col_w]
    )
    tbl.setStyle(TableStyle([
        ('VALIGN',      (0,0),(-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0),(0,-1),  0),
        ('RIGHTPADDING',(0,0),(0,-1),  gap/2 * mm),
        ('LEFTPADDING', (1,0),(1,-1),  gap/2 * mm),
        ('RIGHTPADDING',(1,0),(1,-1),  0),
        ('TOPPADDING',  (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1),0),
    ]))
    return [tbl]


def build_workflow(wf):
    """Build one workflow block with premium styling"""
    num   = wf['num']
    title = wf['title']
    use   = wf['use']
    steps = wf['steps']

    title_safe = title.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    use_safe   = use.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    # Label styles for header cells
    wf_label_style = ParagraphStyle(
        'WfLabel_Custom',
        parent=S_WF_USE,
        textColor=COLOR_GOLD
    )
    if _SHAPING:
        wf_label_style.shaping = 1
        
    wf_use_style = ParagraphStyle(
        'WfUse_Custom',
        parent=S_WF_USE,
        textColor=COLOR_ACCENT,
        alignment=TA_RIGHT
    )
    if _SHAPING:
        wf_use_style.shaping = 1

    # Header row: deep forest green background, except the use cell which is soft amber background
    header_tbl = Table(
        [[Paragraph(f'<b>WF-{num.zfill(2)}</b>', wf_label_style),
          Paragraph(f'<b>{title_safe}</b>', S_WF_HEADER),
          Paragraph(f'<i>{use_safe}</i>', wf_use_style)]],
        colWidths=[18 * mm, CONTENT_W - 18 * mm - 52 * mm, 52 * mm]
    )
    header_tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(1,-1), COLOR_PRIMARY),
        ('BACKGROUND',   (2,0),(2,-1), COLOR_ACCENT_BG),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('TOPPADDING',   (0,0),(-1,-1), 3.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3.5 * mm),
        ('LEFTPADDING',  (0,0),(0,-1),  3 * mm),
        ('LEFTPADDING',  (1,0),(1,-1),  4 * mm),
        ('RIGHTPADDING', (2,0),(2,-1),  3 * mm),
        ('ALIGN',        (2,0),(2,-1),  'RIGHT'),
        ('LINEBELOW',    (2,0),(2,-1),  1, COLOR_ACCENT_WARM),
    ]))

    # Steps
    step_rows = []
    for step_num, step_body in steps:
        body_safe = re.sub(r'&(?!amp;|lt;|gt;)', '&amp;', step_body)
        step_rows.append([
            Paragraph(f'<b>{step_num}</b>', S_WF_NUM),
            Paragraph(body_safe, S_WF_BODY)
        ])

    steps_tbl = Table(
        step_rows,
        colWidths=[14 * mm, CONTENT_W - 14 * mm]
    )
    step_style = TableStyle([
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('ALIGN',        (0,0),(0,-1),  'CENTER'),
        ('TOPPADDING',   (0,0),(-1,-1), 2.2 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.2 * mm),
        ('LEFTPADDING',  (0,0),(0,-1),  2 * mm),
        ('LEFTPADDING',  (1,0),(1,-1),  4 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3 * mm),
        ('LINEBELOW',    (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
        ('BOX',          (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
        ('BACKGROUND',   (0,0),(0,-1),  COLOR_PRIMARY_BG),
        ('BACKGROUND',   (1,0),(1,-1),  COLOR_WHITE),
    ])
    steps_tbl.setStyle(step_style)

    return [KeepTogether([header_tbl, steps_tbl, sp(4)])]


def build_register(reg):
    """Build one register block with premium styling"""
    num     = reg['num']
    name    = reg['name']
    purpose = reg['purpose']
    fields  = reg['fields']
    example = reg['example']

    name_safe    = name.replace('&','&amp;')
    purpose_safe = purpose.replace('&','&amp;')

    # Custom styles for register header
    nb_label_style = ParagraphStyle(
        'RegNbLabel_Custom',
        parent=S_REG_NB,
        textColor=COLOR_GOLD
    )
    if _SHAPING:
        nb_label_style.shaping = 1

    purpose_style = ParagraphStyle(
        'RegPurpose_Custom',
        parent=S_WF_USE,
        textColor=COLOR_PRIMARY_BG
    )
    if _SHAPING:
        purpose_style.shaping = 1

    # Header: Earth brown background
    header_tbl = Table(
        [[Paragraph(f'<b>NOTEBOOK {num}</b>', nb_label_style)],
         [Paragraph(f'<b>{name_safe}</b>', S_REG_HEADER)],
         [Paragraph(f'<i>{purpose_safe}</i>', purpose_style)]],
        colWidths=[CONTENT_W]
    )
    header_tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_EARTH),
        ('TEXTCOLOR',    (0,0),(-1,-1), WHITE),
        ('TOPPADDING',   (0,0),(-1,-1), 1 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 1 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4 * mm),
        ('TOPPADDING',   (0,0),(0, 0),  3 * mm),
        ('BOTTOMPADDING',(0,2),(-1,-1), 3 * mm),
    ]))

    # Fields table
    field_rows = []
    for fname, fdesc in fields:
        fname_safe = fname.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        fdesc_safe = fdesc.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        field_rows.append([
            Paragraph(f'<b>{fname_safe}</b>', S_FIELD_NAME),
            Paragraph(fdesc_safe, S_FIELD_DESC)
        ])

    if field_rows:
        fields_tbl = Table(
            field_rows,
            colWidths=[42 * mm, CONTENT_W - 42 * mm]
        )
        fields_tbl.setStyle(TableStyle([
            ('BACKGROUND',   (0,0),(0,-1),  COLOR_PRIMARY_BG),
            ('BACKGROUND',   (1,0),(1,-1),  COLOR_WHITE),
            ('VALIGN',       (0,0),(-1,-1), 'TOP'),
            ('TOPPADDING',   (0,0),(-1,-1), 1.5 * mm),
            ('BOTTOMPADDING',(0,0),(-1,-1), 1.5 * mm),
            ('LEFTPADDING',  (0,0),(0,-1),  3 * mm),
            ('RIGHTPADDING', (0,0),(0,-1),  2 * mm),
            ('LEFTPADDING',  (1,0),(1,-1),  3 * mm),
            ('LINEAFTER',    (0,0),(0,-1),  0.5, COLOR_RULE_GREY),
            ('LINEBELOW',    (0,0),(-1,-1), 0.25, COLOR_RULE_GREY),
            ('BOX',          (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
        ]))
    else:
        fields_tbl = Table([[Paragraph('(No field definitions)', S_SMALL)]],
                           colWidths=[CONTENT_W])

    items = [header_tbl, fields_tbl]

    # Example entry: light amber highlight box
    if example:
        ex_safe = example.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        ex_label = Paragraph('<b>EXAMPLE ENTRY</b>', S_CALLOUT_LBL)
        ex_text  = Paragraph(ex_safe, S_MONO)
        ex_tbl   = Table(
            [[ex_label], [ex_text]],
            colWidths=[CONTENT_W]
        )
        ex_tbl.setStyle(TableStyle([
            ('BACKGROUND',   (0,0),(-1,-1), COLOR_ACCENT_BG),
            ('TOPPADDING',   (0,0),(-1,-1), 2 * mm),
            ('BOTTOMPADDING',(0,0),(-1,-1), 2 * mm),
            ('LEFTPADDING',  (0,0),(-1,-1), 4 * mm),
            ('RIGHTPADDING', (0,0),(-1,-1), 4 * mm),
            ('LINEABOVE',    (0,0),(-1,0),  0.75, COLOR_ACCENT_WARM),
        ]))
        items.append(ex_tbl)

    outer = Table([[items]], colWidths=[CONTENT_W])
    outer.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_PRIMARY),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
    ]))
    return [outer, sp(4)]


def build_role(role):
    """Build one role card with premium nature-themed layout"""
    from reportlab.graphics.shapes import Drawing, PolyLine, Line

    name     = role['name']
    who      = role['who']
    do_items = role['do']
    cant_items = role['cannot']

    name_safe = name.replace('&','&amp;')
    who_safe  = who.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    # Header with Earth brown background
    header = Table(
        [[Paragraph(f'<b>{name_safe}</b>', S_ROLE_NAME)],
         [Paragraph(f'<i>{who_safe}</i>', S_ROLE_WHO)]],
        colWidths=[CONTENT_W]
    )
    header.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_EARTH),
        ('TOPPADDING',   (0,0),(-1,-1), 2.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.5 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4 * mm),
    ]))

    # DOES items
    do_lbl  = Paragraph('<b>DOES</b>', S_ROLE_LBL)
    do_rows = []
    for x in do_items:
        d = Drawing(12, 12)
        d.add(PolyLine([2, 6, 5, 3, 10, 9], strokeColor=COLOR_PRIMARY, strokeWidth=2))
        do_rows.append([
            d,
            Paragraph(x.replace("&","&amp;"), S_ROLE_ITEM)
        ])
    
    does_content = [[do_lbl, '']] + do_rows
    does_tbl = Table(does_content, colWidths=[6 * mm, CONTENT_W - 6 * mm])
    does_tbl.setStyle(TableStyle([
        ('SPAN',         (0,0),(1,0)),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('VALIGN',       (0,1),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 1.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 1.5 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4 * mm),
        ('LEFTPADDING',  (0,1),(0,-1),  4 * mm),
        ('RIGHTPADDING', (0,1),(0,-1),  0 * mm),
        ('LEFTPADDING',  (1,1),(1,-1),  2 * mm),
        ('RIGHTPADDING', (1,1),(1,-1),  4 * mm),
        ('TOPPADDING',   (0,1),(0,-1),  2.2 * mm),
        ('LINEBELOW',    (0,1),(-1,-1), 0.25, COLOR_RULE_GREY),
    ]))

    # CANNOT items
    cant_lbl  = Paragraph('<b>CANNOT DO</b>', S_ROLE_LBL)
    cant_rows = []
    for x in cant_items:
        d = Drawing(12, 12)
        d.add(Line(2, 2, 10, 10, strokeColor=COLOR_ACCENT, strokeWidth=2))
        d.add(Line(2, 10, 10, 2, strokeColor=COLOR_ACCENT, strokeWidth=2))
        cant_rows.append([
            d,
            Paragraph(x.replace("&","&amp;"), S_ROLE_ITEM)
        ])

    cant_content = [[cant_lbl, '']] + cant_rows
    cant_tbl = Table(cant_content, colWidths=[6 * mm, CONTENT_W - 6 * mm])
    cant_tbl.setStyle(TableStyle([
        ('SPAN',         (0,0),(1,0)),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_ACCENT_BG),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('VALIGN',       (0,1),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 1.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 1.5 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4 * mm),
        ('LEFTPADDING',  (0,1),(0,-1),  4 * mm),
        ('RIGHTPADDING', (0,1),(0,-1),  0 * mm),
        ('LEFTPADDING',  (1,1),(1,-1),  2 * mm),
        ('RIGHTPADDING', (1,1),(1,-1),  4 * mm),
        ('TOPPADDING',   (0,1),(0,-1),  2.2 * mm),
        ('LINEBELOW',    (0,1),(-1,-1), 0.25, COLOR_RULE_GREY),
    ]))

    body_items = [does_tbl, cant_tbl]

    outer = Table([[header], [body_items]], colWidths=[CONTENT_W])
    outer.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_PRIMARY),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
    ]))
    return [KeepTogether(outer), sp(3)]


def build_attack(atk):
    """Build one attack test block"""
    num    = atk['num']
    title  = atk['title']
    attack = atk['attack']
    fails  = atk['fails']
    fix    = atk['fix']

    title_safe  = title.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    attack_safe = attack.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    fails_safe  = fails.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    fix_safe    = fix.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    # Header
    header = Table(
        [[Paragraph(f'<b>ATTACK {num}</b>', S_ATK_NUM),
          Paragraph(f'<b>{title_safe}</b>', S_ATK_HEADER)]],
        colWidths=[20 * mm, CONTENT_W - 20 * mm]
    )
    header.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), colors.HexColor('#333333')),
        ('TEXTCOLOR',    (0,0),(-1,-1), WHITE),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('TOPPADDING',   (0,0),(-1,-1), 2 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3 * mm),
    ]))

    # Two-column body
    col_w = (CONTENT_W) / 2
    body = Table(
        [[
            [Paragraph('<b>THE ATTACK</b>', S_ATK_LABEL),
             sp(1),
             Paragraph(attack_safe, S_ATK_BODY)],
            [Paragraph('<b>WHERE IT FAILS</b>', S_ATK_LABEL),
             sp(1),
             Paragraph(fails_safe, S_ATK_BODY)]
        ]],
        colWidths=[col_w, col_w]
    )
    body.setStyle(TableStyle([
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 2.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.5 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3 * mm),
        ('LINEAFTER',    (0,0),(0,-1),  0.5, colors.HexColor('#cccccc')),
    ]))

    # Fix row
    fix_tbl = Table(
        [[Paragraph(f'<b>FIX:</b>  {fix_safe}', S_ATK_FIX)]],
        colWidths=[CONTENT_W]
    )
    fix_tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), colors.HexColor('#f0f0f0')),
        ('TOPPADDING',   (0,0),(-1,-1), 2 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3 * mm),
        ('LINEABOVE',    (0,0),(-1,-1), 0.5, colors.HexColor('#cccccc')),
    ]))

    outer = Table([[header], [body], [fix_tbl]], colWidths=[CONTENT_W])
    outer.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1, colors.HexColor('#cccccc')),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
    ]))
    return [KeepTogether([outer, sp(4)])]


def build_precedent(prec):
    num    = prec[0]; title = prec[1]; body = prec[2]; lesson = prec[3]
    title_safe  = title.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    body_safe   = body.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    lesson_safe = lesson.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    items = [
        sp(1),
        Paragraph(f'<b>Precedent {num} — {title_safe}</b>', S_PREC_TITLE),
        HRFlowable(width='100%', thickness=0.5, color=GREY_RULE,
                   spaceBefore=1*mm, spaceAfter=2*mm),
        Paragraph(body_safe, S_PREC_BODY),
    ]
    if lesson_safe:
        items.append(sp(1))
        items.append(Paragraph(f'<i>The lesson: {lesson_safe}</i>', S_PREC_LESSON))

    tbl = Table([[[i for i in items]]], colWidths=[CONTENT_W])
    tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 0.5, GREY_RULE),
        ('LINEBEFORE',   (0,0),(0,-1),  3,   BLACK),
        ('TOPPADDING',   (0,0),(-1,-1), 2*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4*mm),
    ]))
    return [KeepTogether([tbl, sp(3)])]


def build_test(test_tuple):
    num = test_tuple[0]; question = test_tuple[1]; pass_if = test_tuple[2]
    q_safe = question.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    p_safe = pass_if.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    tbl = Table(
        [[Paragraph(f'<b>{num}</b>', S_RULE_TAG),
          [Paragraph(q_safe, S_TEST_Q),
           Paragraph(f'<font color="{COLOR_PRIMARY.hexval()}"><b>PASS IF:</b></font>  {p_safe}', S_TEST_PASS)]]],
        colWidths=[10 * mm, CONTENT_W - 10 * mm]
    )
    tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(0,-1),  BLACK),
        ('TEXTCOLOR',    (0,0),(0,-1),  WHITE),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 2.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.5 * mm),
        ('LEFTPADDING',  (0,0),(0,-1),  2 * mm),
        ('LEFTPADDING',  (1,0),(1,-1),  3 * mm),
        ('BOX',          (0,0),(-1,-1), 0.5, GREY_RULE),
    ]))
    return [KeepTogether([tbl, sp(1.5)])]


def build_phase(phase):
    num   = phase['num']; title = phase['title']
    goal  = phase['goal']; body  = phase['body']
    title_safe = title.replace('&','&amp;')
    goal_safe  = goal.replace('&','&amp;')
    body_safe  = body.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    # Compact parameters from LAYOUT_CONFIG
    compaction = LAYOUT_CONFIG.get("compaction", {})
    p_top_bot = compaction.get("phase_p_top_bot", 0.8)
    b_bot = compaction.get("phase_b_bot", 1.2)
    sp_val = compaction.get("phase_sp_val", 1.0)

    header = Table(
        [[Paragraph(f'<b>PHASE {num} — {title_safe}</b>', S_PHASE_HEAD)]],
        colWidths=[CONTENT_W]
    )
    header.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), BLACK),
        ('TOPPADDING',   (0,0),(-1,-1), p_top_bot*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), p_top_bot*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
    ]))
    goal_tbl = Table(
        [[Paragraph(f'<i>{goal_safe}</i>', S_PHASE_GOAL)]],
        colWidths=[CONTENT_W]
    )
    goal_tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), GREY_BG),
        ('TOPPADDING',   (0,0),(-1,-1), p_top_bot*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), p_top_bot*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('LINEBELOW',    (0,0),(-1,-1), 0.5, GREY_RULE),
    ]))
    body_tbl = Table(
        [[Paragraph(body_safe, S_PHASE_BODY)]],
        colWidths=[CONTENT_W]
    )
    body_tbl.setStyle(TableStyle([
        ('TOPPADDING',   (0,0),(-1,-1), p_top_bot*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), b_bot*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4*mm),
    ]))
    outer = Table([[header], [goal_tbl], [body_tbl]], colWidths=[CONTENT_W])
    outer.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, BLACK),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
    ]))
    return [KeepTogether([outer, sp(sp_val)])]


def build_enforcement_rungs():
    """Build the 5-rung enforcement ladder table with premium styling"""
    rungs = [
        ("Rung 1", UI_RUNG_1_TITLE, UI_RUNG_1_DAYS, UI_RUNG_1_DESC),
        ("Rung 2", UI_RUNG_2_TITLE, UI_RUNG_2_DAYS, UI_RUNG_2_DESC),
        ("Rung 3", UI_RUNG_3_TITLE, UI_RUNG_3_DAYS, UI_RUNG_3_DESC),
        ("Rung 4", UI_RUNG_4_TITLE, UI_RUNG_4_DAYS, UI_RUNG_4_DESC),
        ("Rung 5", UI_RUNG_5_TITLE, UI_RUNG_5_DAYS, UI_RUNG_5_DESC),
    ]
    rows = []
    for rung, title, timing, desc in rungs:
        timing_safe = timing.replace('&','&amp;')
        desc_safe   = desc.replace('&','&amp;')
        rows.append([
            Paragraph(f'<b>{rung}</b>', S_RULE_TAG),
            [Paragraph(f'<b>{title}</b>', S_WF_NUM),
             Paragraph(desc_safe, S_RULE_BODY)],
            Paragraph(f'<i>{timing_safe}</i>', S_SMALL_GREY),
        ])
    tbl = Table(rows, colWidths=[16*mm, CONTENT_W - 16*mm - 22*mm, 22*mm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(0,-1),  COLOR_ACCENT),
        ('TEXTCOLOR',    (0,0),(0,-1),  WHITE),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 2.5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.5*mm),
        ('LEFTPADDING',  (0,0),(0,-1),  2*mm),
        ('LEFTPADDING',  (1,0),(1,-1),  3*mm),
        ('RIGHTPADDING', (2,0),(2,-1),  3*mm),
        ('ALIGN',        (2,0),(2,-1),  'RIGHT'),
        ('LINEBELOW',    (0,0),(-1,-2), 0.5, COLOR_RULE_GREY),
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_PRIMARY),
        ('LINEBEFORE',   (1,0),(1,-1),  0.5, COLOR_RULE_GREY),
        ('LINEAFTER',    (1,0),(1,-1),  0.5, COLOR_RULE_GREY),
        ('BACKGROUND',   (1,0),(1,-1),  COLOR_WHITE),
        ('BACKGROUND',   (2,0),(2,-1),  COLOR_ACCENT_BG),
    ]))
    return [tbl, sp(3)]


def build_seven_layers():
    """Seven-layer tamper resistance — clean layout: first column green gradient, premium borders"""
    layers = SEC2_LAYERS
    rows = []
    for i, (layer, desc) in enumerate(layers):
        desc_safe = desc.replace('&','&amp;')
        rows.append([
            Paragraph(f'<b>{layer}</b>', S_RULE_TAG),
            Paragraph(desc_safe, S_RULE_BODY),
        ])
    tbl = Table(rows, colWidths=[22*mm, CONTENT_W - 22*mm])
    style_cmds = [
        ('TEXTCOLOR',    (0,0),(0,-1),  WHITE),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('ALIGN',        (0,0),(0,-1),  'CENTER'),
        ('TOPPADDING',   (0,0),(-1,-1), 3.5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3.5*mm),
        ('LEFTPADDING',  (0,0),(0,-1),  2*mm),
        ('LEFTPADDING',  (1,0),(1,-1),  4*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3*mm),
        ('BOX',          (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
        ('LINEBELOW',    (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
        ('LINEAFTER',    (0,0),(0,-1),  0.5, COLOR_RULE_GREY),
    ]
    # Apply forest green gradient to the first column (Layer 1 to Layer 7)
    gradient = ['#1B5E20', '#2E7D32', '#388E3C', '#43A047', '#4CAF50', '#66BB6A', '#81C784']
    for i in range(len(layers)):
        col_hex = gradient[i] if i < len(gradient) else '#81C784'
        style_cmds.append(('BACKGROUND', (0,i),(0,i), colors.HexColor(col_hex)))
        if i % 2 == 0:
            style_cmds.append(('BACKGROUND', (1,i),(1,i), COLOR_PRIMARY_BG))
        else:
            style_cmds.append(('BACKGROUND', (1,i),(1,i), COLOR_WHITE))
    tbl.setStyle(TableStyle(style_cmds))
    return [tbl, sp(2)]


def build_numbers_grid():
    """Build core numbers grid (R-01 to R-19) with soft green background cells"""
    key_nums = [
        ("R-01", "20% or 50", "Quorum = 20% of residents OR 50 — whichever is LESS"),
        ("R-02", "60%",       "Approval = 60% YES vote of those present"),
        ("R-03", "70%",       "Rule Change = 70% YES vote of those present"),
        ("R-04", "3",         "Verifiers per village (2 local + 1 rotating external)"),
        ("R-05", "10%",       "Audit = 10% of all Final entries every 7 days"),
        ("R-06", "30 days",   "Fraud Ban from all system participation"),
        ("R-07", "7 days",    "Dispute limit: filing to initial decision"),
        ("R-08", "3 years",   "Use-Right Review per plot"),
        ("R-09", "24 months", "Recorder maximum total service"),
        ("R-10", "7 – 15",    "Council size: minimum 7, maximum 15 members"),
        ("R-11", "7 days",    "Vote Notice: written notice before any vote"),
        ("R-12", "3 min",     "Speaker limit per person in any meeting"),
    ]
    rows = []
    row = []
    col_w = CONTENT_W / 4
    for i, (rid, val, desc) in enumerate(key_nums):
        rid_safe  = rid.replace('&','&amp;')
        val_safe  = val.replace('&','&amp;')
        desc_safe = desc.replace('&','&amp;')
        cell = [
            Paragraph(f'<b>{rid_safe}</b>', S_NUM_ID),
            Paragraph(f'<b>{val_safe}</b>', S_NUM_VAL),
            Paragraph(desc_safe, S_NUM_DESC),
        ]
        row.append(cell)
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        while len(row) < 4:
            row.append([Paragraph('', S_SMALL)])
        rows.append(row)

    tbl = Table(rows, colWidths=[col_w]*4)
    style_cmds = [
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 3*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3.5*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3.5*mm),
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_PRIMARY),
        ('INNERGRID',    (0,0),(-1,-1), 0.5, COLOR_PRIMARY_MID),
    ]
    tbl.setStyle(TableStyle(style_cmds))
    return [tbl, sp(4)]


def build_cap_flags():
    """Build the 8 Capture Prevention red flags in a 4-column grid (checkbox-desc side-by-side) with amber accents"""
    flags = CAP1_RED_FLAGS
    box_w = 6 * mm
    gap_w = 4 * mm
    col_text_w = (CONTENT_W - 2 * box_w - gap_w) / 2
    
    rows = []
    for i in range(0, len(flags), 2):
        left_flag, left_desc = flags[i]
        if i+1 < len(flags):
            right_flag, right_desc = flags[i+1]
        else:
            right_flag, right_desc = '', ''

        left_safe  = left_desc.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        right_safe = right_desc.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;') if right_flag else ''

        S_CAP_LETTER = ParagraphStyle(
            name=f'CapLetter_{i}',
            fontName=FONT_SANS_BOLD,
            fontSize=8.5,
            leading=10,
            alignment=TA_CENTER,
            textColor=COLOR_ACCENT
        )
        if _SHAPING:
            S_CAP_LETTER.shaping = 1

        rows.append([
            Paragraph(f'<b>{left_flag}</b>', S_CAP_LETTER),
            Paragraph(left_safe, S_RULE_BODY),
            Paragraph(f'<b>{right_flag}</b>', S_CAP_LETTER) if right_flag else Paragraph('', S_CAP_LETTER),
            Paragraph(right_safe, S_RULE_BODY) if right_flag else Paragraph('', S_RULE_BODY),
        ])

    tbl = Table(rows, colWidths=[box_w, col_text_w, box_w, col_text_w])
    
    style_cmds = [
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('TOPPADDING',   (0,0),(-1,-1), 2.5 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.5 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
        ('LEFTPADDING',  (1,0),(1,-1),  3 * mm),
        ('RIGHTPADDING', (1,0),(1,-1),  4 * mm),
        ('LEFTPADDING',  (3,0),(3,-1),  3 * mm),
    ]
    
    for r in range(len(rows)):
        style_cmds.append(('BOX', (0, r), (0, r), 0.75, COLOR_ACCENT_WARM))
        style_cmds.append(('BACKGROUND', (0, r), (0, r), COLOR_ACCENT_BG))
        if r * 2 + 1 < len(flags):
            style_cmds.append(('BOX', (2, r), (2, r), 0.75, COLOR_ACCENT_WARM))
            style_cmds.append(('BACKGROUND', (2, r), (2, r), COLOR_ACCENT_BG))
            
    tbl.setStyle(TableStyle(style_cmds))
    return [tbl, sp(3)]


def build_timeline():
    """Build the honest timeline with a forest green left-bar indicator"""
    timeline_data = [
        ("Year 1",  "One village. Internal disputes resolved. System operational."),
        ("Year 3",  "Five villages. Shared learnings. First Gram Sabha resolutions."),
        ("Year 5",  "Documented proof. 500+ disputes resolved. State comparison ready."),
        ("Year 8",  "50 villages. Inter-Village Federation. First FRA claims filed."),
        ("Year 10", "First strategic court case. Model legislation drafted."),
        ("Year 15", "Dual Register pilot with one state government."),
        ("Year 20", "State-level legal recognition in 1 to 2 states."),
        ("Year 30", "National model. Constitutional protection possible."),
    ]
    items = []
    for year, desc in timeline_data:
        year_safe = year.replace('&','&amp;')
        desc_safe = desc.replace('&','&amp;')
        items.append(
            Table(
                [[Paragraph(f'<b>{year_safe}</b>', S_TL_YEAR),
                  Paragraph(desc_safe, S_TL_DESC)]],
                colWidths=[18*mm, CONTENT_W - 18*mm - 4*mm]
            )
        )
        items[-1].setStyle(TableStyle([
            ('VALIGN',      (0,0),(-1,-1),'TOP'),
            ('TOPPADDING',  (0,0),(-1,-1),1.5*mm),
            ('BOTTOMPADDING',(0,0),(-1,-1),1.5*mm),
            ('LEFTPADDING', (0,0),(0,-1), 0),
            ('LEFTPADDING', (1,0),(1,-1), 3*mm),
        ]))
    # Wrap in a left-bar table
    wrapper = Table([[items]], colWidths=[CONTENT_W])
    wrapper.setStyle(TableStyle([
        ('LINEBEFORE',   (0,0),(0,-1), 2, COLOR_PRIMARY),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
    ]))
    return [wrapper, sp(3)]


# =============================================================================
# COVER PAGE
# =============================================================================

def build_cover():
    story = []

    # 1. Full-width dark green header band
    header_p = Paragraph(f'<font size="11" color="{COLOR_GOLD.hexval()}"><b>{UI_COVER_LABEL.upper()}</b></font>', S_COVER_TAG)
    title_p = Paragraph(f'<font size="28" color="#FFFFFF"><b>{DOC_TITLE}</b></font>', S_COVER_TITLE)
    
    header_tbl = Table([[header_p], [title_p]], colWidths=[CONTENT_W])
    header_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), COLOR_PRIMARY),
        ('TOPPADDING', (0,0), (-1,-1), 8 * mm),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8 * mm),
        ('LEFTPADDING', (0,0), (-1,-1), 8 * mm),
        ('RIGHTPADDING', (0,0), (-1,-1), 8 * mm),
    ]))
    story.append(header_tbl)

    # 2. Earth-brown subtitle panel
    sub_p = Paragraph(f'<font color="#FFFFFF"><b>{DOC_SUBTITLE}</b>  ·  {DOC_VERSION}</font>', S_COVER_SUB)
    sub_tbl = Table([[sub_p]], colWidths=[CONTENT_W])
    sub_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), COLOR_EARTH),
        ('TOPPADDING', (0,0), (-1,-1), 3 * mm),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3 * mm),
        ('LEFTPADDING', (0,0), (-1,-1), 8 * mm),
        ('RIGHTPADDING', (0,0), (-1,-1), 8 * mm),
    ]))
    story.append(sub_tbl)
    story.append(sp(6))

    cover_body = []

    # 3. What You Need Row (3 facts)
    facts = [
        (UI_WHAT_YOU_NEED_LABEL, DOC_NEED.split(':', 1)[-1].strip()),
        (UI_WHERE_WORKS_LABEL, DOC_WHERE.split(':', 1)[-1].strip()),
        (UI_WHEN_STARTS_LABEL, DOC_WHEN.split(':', 1)[-1].strip()),
    ]
    fact_rows = []
    for label, value in facts:
        fact_rows.append([
            Paragraph(f'<b>{label}</b>', S_SMALL_GREY),
            Paragraph(value, S_COVER_BODY),
        ])
    fact_tbl = Table(fact_rows, colWidths=[38*mm, CONTENT_W - 6*mm - 38*mm])
    fact_tbl.setStyle(TableStyle([
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 1.5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 1.5*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
        ('LINEBELOW',    (0,0),(-1,-2), 0.5, COLOR_RULE_GREY),
    ]))
    cover_body.append(fact_tbl)
    cover_body.append(sp(6))

    # 4. Stat Grid — 5 key numbers
    stats = [
        ('121', UI_STAT_RULES),
        ('15',  UI_STAT_WORKFLOWS),
        ('6',   UI_STAT_REGISTERS),
        ('6',   UI_STAT_ROLES),
        ('7',   UI_STAT_DAYS),
    ]
    col_w = (CONTENT_W - 6*mm) / len(stats)
    
    stat_tbl = Table(
        [
            [Paragraph(f'<b>{v}</b>', S_NUM_VAL)  for v, _ in stats],
            [Paragraph(l,             S_NUM_ID)   for _, l in stats],
        ],
        colWidths=[col_w] * len(stats)
    )
    stat_tbl.setStyle(TableStyle([
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ('BOX',          (0,0),(-1,-1), 2, COLOR_PRIMARY),
        ('INNERGRID',    (0,0),(-1,-1), 0.5, COLOR_PRIMARY_MID),
        ('ALIGN',        (0,0),(-1,-1), 'CENTER'),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('TOPPADDING',   (0,0),(-1, 0), 4*mm),
        ('BOTTOMPADDING',(0,0),(-1, 0), 1.5*mm),
        ('TOPPADDING',   (0,1),(-1,-1), 1.5*mm),
        ('BOTTOMPADDING',(0,1),(-1,-1), 4*mm),
    ]))
    cover_body.append(stat_tbl)
    cover_body.append(sp(6))

    # 5. Three-Document System
    three_rows = []
    for i, doc in enumerate(THREE_DOCS, 1):
        num_s  = doc["num"].replace('&','&amp;')
        name_s = doc["name"].replace('&','&amp;')
        desc_s = doc["desc"].replace('&','&amp;')
        three_rows.append([
            Paragraph(f'<font size="8" color="{COLOR_EARTH.hexval()}"><b>{num_s}</b></font><br/><b>{name_s}</b>', S_COVER_BODY),
            Paragraph(desc_s, S_SMALL_GREY),
        ])
    three_tbl = Table(
        three_rows,
        colWidths=[55*mm, CONTENT_W - 6*mm - 55*mm]
    )
    three_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_PRIMARY),
        ('LINEBELOW',    (0,0),(-1,-2), 0.5, COLOR_RULE_GREY),
        ('LINEAFTER',    (0,0),(0,-1),  0.5, COLOR_PRIMARY_MID),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 2.5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 2.5*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3*mm),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_WHITE),
    ]))
    cover_body.append(Paragraph(f'<b>{UI_THREE_DOC_LABEL}</b>', S_CALLOUT_LBL))
    cover_body.append(sp(1))
    cover_body.append(three_tbl)
    cover_body.append(sp(4))

    # 6. Tagline in amber highlight box
    tagline_style = ParagraphStyle(
        'CoverTagline',
        parent=S_COVER_NOTE,
        textColor=COLOR_ACCENT,
        alignment=TA_CENTER
    )
    if _SHAPING:
        tagline_style.shaping = 1
    tagline_p = Paragraph(f'<b>{UI_CAN_DO_TODAY}</b> — <i>{UI_CANNOT_DO}</i>', tagline_style)
    tagline_tbl = Table([[tagline_p]], colWidths=[CONTENT_W - 6*mm])
    tagline_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), COLOR_ACCENT_BG),
        ('BOX', (0,0), (-1,-1), 1, COLOR_ACCENT_WARM),
        ('TOPPADDING', (0,0), (-1,-1), 3 * mm),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3 * mm),
        ('LEFTPADDING', (0,0), (-1,-1), 4 * mm),
        ('RIGHTPADDING', (0,0), (-1,-1), 4 * mm),
    ]))
    cover_body.append(tagline_tbl)

    # Wrap the cover_body in an outer table cell with a 1.5pt solid green left border
    outer_tbl = Table([[cover_body]], colWidths=[CONTENT_W])
    outer_tbl.setStyle(TableStyle([
        ('LINEBEFORE',   (0,0),(0,-1), 1.5, COLOR_PRIMARY),
        ('LEFTPADDING',  (0,0),(0,-1), 6 * mm),
        ('RIGHTPADDING', (0,0),(0,-1), 0),
        ('TOPPADDING',   (0,0),(0,-1), 0),
        ('BOTTOMPADDING',(0,0),(0,-1), 0),
    ]))
    story.append(outer_tbl)

    # ── BOTTOM RULE + FOOTER ──────────────────────────────────────────
    story.append(HRFlowable(width='100%', thickness=2, color=COLOR_PRIMARY,
                            spaceBefore=4*mm, spaceAfter=2*mm))
    foot = Table(
        [[Paragraph('Offline · Paper-Based · Community-Owned · Generationally Durable', S_SMALL_GREY),
          Paragraph('github.com/chyrenselin/Satya-Yuga-Bhumi-Trust-DAO', S_SMALL_GREY)]],
        colWidths=[CONTENT_W * 0.6, CONTENT_W * 0.4]
    )
    foot.setStyle(TableStyle([
        ('ALIGN',        (1,0),(1,-1), 'RIGHT'),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
    ]))
    story.append(foot)
    story.append(PageBreak())
    return story


def build_quick_ref():
    """One-page visual quick reference: the numbers that matter, the roles, the flow."""
    story = []

    # ── Header ──────────────────────────────────────────────────────────
    story.append(HRFlowable(width='100%', thickness=4, color=COLOR_PRIMARY,
                            spaceBefore=0, spaceAfter=0))
    story.append(HRFlowable(width='100%', thickness=1.5, color=COLOR_EARTH,
                            spaceBefore=0, spaceAfter=2*mm))

    story.append(Paragraph(f'<b>{UI_QUICK_REF_TITLE}</b>', S_SECTION))
    story.append(para(UI_QUICK_REF_SUBTITLE, S_ITALIC_SM))
    story.append(sp(1.5))

    # ── Row 1: The 10 Key Numbers ───────────────────────────────────────
    story.append(Paragraph(f'<b>{UI_KEY_NUMBERS_TITLE}</b>', S_CALLOUT_LBL))
    story.append(sp(0.5))

    nums = UI_QUICK_NUMS
    col_n = 5
    col_w = CONTENT_W / col_n
    num_data_v = [[Paragraph(f'<b>{v}</b>', S_REF_NUM_VAL) for v, _ in nums[:col_n]],
                  [Paragraph(l.replace('\n', '<br/>'), S_NUM_ID) for _, l in nums[:col_n]]]
    num_data_b = [[Paragraph(f'<b>{v}</b>', S_REF_NUM_VAL) for v, _ in nums[col_n:]],
                  [Paragraph(l.replace('\n', '<br/>'), S_NUM_ID) for _, l in nums[col_n:]]]

    def make_num_table(data):
        t = Table(data, colWidths=[col_w]*col_n)
        t.setStyle(TableStyle([
            ('BOX',          (0,0),(-1,-1), 2,   COLOR_PRIMARY),
            ('INNERGRID',    (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
            ('ALIGN',        (0,0),(-1,-1), 'CENTER'),
            ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
            ('TOPPADDING',   (0,0),(-1,-1), 1.5*mm),
            ('BOTTOMPADDING',(0,0),(-1,-1), 1*mm),
            ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ]))
        return t

    story.append(make_num_table(num_data_v))
    story.append(sp(0.25))
    story.append(make_num_table(num_data_b))
    story.append(sp(1.5))

    # ── Row 2: 6 Roles ──────────────────────────────────────────────────
    story.append(Paragraph(f'<b>{UI_SIX_ROLES_TITLE}</b>', S_CALLOUT_LBL))
    story.append(sp(0.5))

    roles = [
        (UI_ROLE_RESIDENT,     UI_ROLE_RESIDENT_DESC),
        (UI_ROLE_VERIFIER,     UI_ROLE_VERIFIER_DESC),
        (UI_ROLE_COUNCIL,      UI_ROLE_COUNCIL_DESC),
        (UI_ROLE_RECORDER,     UI_ROLE_RECORDER_DESC),
        (UI_ROLE_WITNESS,      UI_ROLE_WITNESS_DESC),
        (UI_ROLE_DEP_RECORDER, UI_ROLE_DEP_RECORDER_DESC),
    ]
    role_col_w = CONTENT_W / 2
    role_rows = []
    for i in range(0, len(roles), 2):
        left  = roles[i]
        right = roles[i+1] if i+1 < len(roles) else ("", "")
        row = [
            Paragraph(f'<b>{left[0]}</b>  {left[1]}',   S_NORMAL),
            Paragraph(f'<b>{right[0]}</b>  {right[1]}',  S_NORMAL),
        ]
        role_rows.append(row)

    role_tbl = Table(role_rows, colWidths=[role_col_w]*2)
    role_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
        ('INNERGRID',    (0,0),(-1,-1), 0.3, COLOR_RULE_GREY),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 1.5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 1.5*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3*mm),
        ('BACKGROUND',   (0,0),(0,-1),  COLOR_PRIMARY_BG),
        ('LINEBEFORE',   (0,0),(0,-1),  4, COLOR_PRIMARY),
    ]))
    story.append(role_tbl)
    story.append(sp(1.5))

    # ── Row 3: Two mini flows side-by-side ──────────────────────────────
    story.append(Paragraph(f'<b>{UI_LAND_REG_TITLE}</b>      --      <b>{UI_DISPUTE_TITLE}</b>', S_CALLOUT_LBL))
    story.append(sp(0.5))

    land_steps = [
        UI_LAND_STEP_1,
        UI_LAND_STEP_2,
        UI_LAND_STEP_3,
        UI_LAND_STEP_4,
        UI_LAND_STEP_5,
        UI_LAND_STEP_6,
        UI_LAND_STEP_7,
    ]
    dispute_steps = [
        UI_DISPUTE_STEP_1,
        UI_DISPUTE_STEP_2,
        UI_DISPUTE_STEP_3,
        UI_DISPUTE_STEP_4,
        UI_DISPUTE_STEP_5,
        UI_DISPUTE_STEP_6,
        UI_DISPUTE_STEP_7,
    ]

    def mini_steps(steps, color):
        rows = []
        for s in steps:
            rows.append([Paragraph(s, S_NORMAL)])
        t = Table(rows, colWidths=[CONTENT_W/2 - 3*mm])
        t.setStyle(TableStyle([
            ('BOX',          (0,0),(-1,-1), 0.5, COLOR_RULE_GREY),
            ('LINEBEFORE',   (0,0),(0,-1),  4, color),
            ('LINEBELOW',    (0,0),(-1,-2), 0.3, COLOR_RULE_GREY),
            ('TOPPADDING',   (0,0),(-1,-1), 0.8*mm),
            ('BOTTOMPADDING',(0,0),(-1,-1), 0.8*mm),
            ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
            ('RIGHTPADDING', (0,0),(-1,-1), 3*mm),
        ]))
        return t

    flow_tbl = Table(
        [[mini_steps(land_steps, COLOR_PRIMARY_LIGHT), mini_steps(dispute_steps, COLOR_ACCENT)]],
        colWidths=[CONTENT_W/2 - 2*mm, CONTENT_W/2 + 2*mm]
    )
    flow_tbl.setStyle(TableStyle([
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(-1,-1), 0),
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('COLPADDING',   (0,0),(0,-1),  2*mm),
    ]))
    story.append(flow_tbl)
    story.append(sp(1.5))

    # ── Bottom note ──────────────────────────────────────────────────────
    story.append(HRFlowable(width='100%', thickness=1, color=COLOR_PRIMARY,
                            spaceBefore=0.5*mm, spaceAfter=0.5*mm))
    story.append(para(UI_CAN_DO_TODAY + '  ' + UI_CANNOT_DO, S_SMALL_GREY))

    # Page break removed — TOC starts fresh
    return story
def build_simplified_village():
    story = []

    # ── BIG IDEA BOX — thick border, large text ──────────────────────────
    story.append(sp(1))
    story.append(para(
        UI_SIMP_SUBTITLE,
        S_ITALIC_SM
    ))
    story.append(sp(2))

    big_idea_inner = [
        Paragraph('<b>THE BIG IDEA</b>', S_SIMP_HEAD),
        Spacer(1, 3*mm),
        Paragraph(S31_BIG_IDEA, S_SIMP_BODY),
    ]
    big_tbl = Table([[big_idea_inner]], colWidths=[CONTENT_W])
    big_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 3, COLOR_PRIMARY),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ('TOPPADDING',   (0,0),(-1,-1), 5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 5*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 6*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 6*mm),
        ('LINEBEFORE',   (0,0),(0,-1),  8, COLOR_PRIMARY_LIGHT),
    ]))
    story.append(big_tbl)
    story.append(sp(4))

    # ── SIX NOTEBOOKS — visual grid of boxes ────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph('<b>SIX NOTEBOOKS — Write Everything Down</b>', S_SIMP_HEAD))
    story.append(sp(1))

    nb_rows = []
    for i in range(0, len(S31_NOTEBOOKS), 2):
        row = []
        for n, name, desc in S31_NOTEBOOKS[i:i+2]:
            cell = [
                Paragraph(f'{UI_NOTEBOOK_LABEL} {n}', S_NUM_ID),
                Spacer(1, 2*mm),
                Paragraph(f'<b>{name}</b>', S_SIMP_LARGE),
                Spacer(1, 1.5*mm),
                Paragraph(desc, S_NORMAL),
            ]
            row.append(cell)
        if len(row) == 1:
            row.append([Paragraph('', S_NORMAL)])
        nb_rows.append(row)

    nb_tbl = Table(nb_rows, colWidths=[CONTENT_W/2 - 2*mm, CONTENT_W/2 - 2*mm])
    nb_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1, COLOR_PRIMARY),
        ('INNERGRID',    (0,0),(-1,-1), 0.5, COLOR_PRIMARY_MID),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 4*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4*mm),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
    ]))
    story.append(nb_tbl)
    story.append(sp(4))

    # ── SIX JOBS — visual grid of boxes ─────────────────────────────────
    story.append(Paragraph('<b>SIX JOBS — Who Does What</b>', S_SIMP_HEAD))
    story.append(sp(1))

    job_rows = []
    for i in range(0, len(S31_JOBS), 3):
        row = []
        for n, name, desc in S31_JOBS[i:i+3]:
            cell = [
                Paragraph(f'<b>{n}. {name}</b>', S_SIMP_HEAD),
                Spacer(1, 2*mm),
                Paragraph(desc, S_NORMAL),
            ]
            row.append(cell)
        while len(row) < 3:
            row.append([Paragraph('', S_NORMAL)])
        job_rows.append(row)

    job_col = CONTENT_W / 3
    job_tbl = Table(job_rows, colWidths=[job_col]*3)
    job_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_ACCENT),
        ('INNERGRID',    (0,0),(-1,-1), 0.5, COLOR_ACCENT_WARM),
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 4*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3*mm),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_ACCENT_BG),
    ]))
    story.append(job_tbl)
    story.append(sp(4))

    # ── NUMBERS TO REMEMBER — very large, one per box ───────────────────
    story.append(PageBreak())
    story.append(Paragraph('<b>THE NUMBERS TO REMEMBER</b>', S_SIMP_HEAD))
    story.append(sp(1))

    num_data_top = [[
        Paragraph(f'<b>{val}</b>', S_SIMP_NUM)
        for val, desc in S31_NUMBERS[:5]
    ],[
        Paragraph(desc, S_SIMP_LABEL)
        for val, desc in S31_NUMBERS[:5]
    ]]
    num_data_bot = [[
        Paragraph(f'<b>{val}</b>', S_SIMP_NUM)
        for val, desc in S31_NUMBERS[5:]
    ],[
        Paragraph(desc, S_SIMP_LABEL)
        for val, desc in S31_NUMBERS[5:]
    ]]

    def num_table(data, n_cols):
        col_w = CONTENT_W / n_cols
        t = Table(data, colWidths=[col_w]*n_cols)
        t.setStyle(TableStyle([
            ('BOX',          (0,0),(-1,-1), 2, COLOR_PRIMARY),
            ('INNERGRID',    (0,0),(-1,-1), 0.75, COLOR_PRIMARY_MID),
            ('ALIGN',        (0,0),(-1,-1), 'CENTER'),
            ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
            ('TOPPADDING',   (0,0),(-1,0),  4*mm),
            ('BOTTOMPADDING',(0,0),(-1,0),  1*mm),
            ('TOPPADDING',   (0,1),(-1,-1), 1*mm),
            ('BOTTOMPADDING',(0,1),(-1,-1), 4*mm),
            ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ]))
        return t

    story.append(num_table(num_data_top, len(S31_NUMBERS[:5])))
    story.append(sp(1))
    story.append(num_table(num_data_bot, len(S31_NUMBERS[5:])))
    story.append(sp(4))

    # ── HOW TO REGISTER + HOW DISPUTE RESOLVED — step boxes ─────────────
    def step_box(title, steps, color_primary, color_bg, color_light):
        rows = []
        for i, step in enumerate(steps, 1):
            step_text = step[1] if isinstance(step, tuple) else step
            
            num_style = ParagraphStyle(
                f'SimpNum_{title}_{i}',
                parent=S_SIMP_NUM,
                textColor=color_primary
            )
            if _SHAPING:
                num_style.shaping = 1
                
            rows.append([
                Paragraph(f'<b>{i}</b>', num_style),
                Paragraph(step_text, S_SIMP_BODY),
            ])
        step_col_w = 18*mm
        t = Table(rows, colWidths=[step_col_w, CONTENT_W/2 - step_col_w - 4*mm])
        t.setStyle(TableStyle([
            ('ALIGN',        (0,0),(0,-1), 'CENTER'),
            ('VALIGN',       (0,0),(-1,-1),'MIDDLE'),
            ('TOPPADDING',   (0,0),(-1,-1), 2.5*mm),
            ('BOTTOMPADDING',(0,0),(-1,-1), 2.5*mm),
            ('LEFTPADDING',  (0,0),(0,-1),  2*mm),
            ('LEFTPADDING',  (1,0),(1,-1),  3*mm),
            ('LINEBELOW',    (0,0),(-1,-2), 0.5, COLOR_RULE_GREY),
            ('BACKGROUND',   (0,0),(0,-1),  color_bg),
            ('BACKGROUND',   (1,0),(1,-1),  COLOR_WHITE),
            ('BOX',          (0,0),(-1,-1), 1.5, color_primary),
        ]))
        inner = [
            Paragraph(f'<b>{title}</b>', S_SIMP_HEAD),
            Spacer(1, 3*mm),
            t,
        ]
        outer = Table([[inner]], colWidths=[CONTENT_W/2 - 2*mm])
        outer.setStyle(TableStyle([
            ('BOX',          (0,0),(-1,-1), 2, color_primary),
            ('TOPPADDING',   (0,0),(-1,-1), 4*mm),
            ('BOTTOMPADDING',(0,0),(-1,-1), 4*mm),
            ('LEFTPADDING',  (0,0),(-1,-1), 3*mm),
            ('RIGHTPADDING', (0,0),(-1,-1), 3*mm),
            ('LINEBEFORE',   (0,0),(0,-1),  6, color_light),
        ]))
        return outer

    story.append(PageBreak())
    reg_box = step_box(UI_SIMP_REG_TITLE, S31_HOW_REGISTER, COLOR_PRIMARY, COLOR_PRIMARY_BG, COLOR_PRIMARY_LIGHT)
    dis_box = step_box(UI_SIMP_DISPUTE_TITLE, S31_HOW_DISPUTE, COLOR_ACCENT, COLOR_ACCENT_BG, COLOR_ACCENT_WARM)

    two_col = Table([[reg_box, dis_box]],
                    colWidths=[CONTENT_W/2 + 2*mm, CONTENT_W/2 - 2*mm])
    two_col.setStyle(TableStyle([
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(0,-1),  3*mm),
        ('RIGHTPADDING', (1,0),(1,-1),  0),
    ]))
    story.append(two_col)
    story.append(sp(4))

    story.append(PageBreak())
    # ── PROTECTIONS — clear boxes ────────────────────────────────────────
    inner_items_women = [
        Paragraph(f'<b>{UI_SIMP_WOMEN_TITLE}</b>', S_SIMP_HEAD),
        Spacer(1, 3*mm),
    ] + [Paragraph(f'[ ] {item}', S_SIMP_BODY) for item in S31_WOMEN]
    cell_women = Table([[inner_items_women]], colWidths=[CONTENT_W/2 - 3*mm])
    cell_women.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_PRIMARY),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_PRIMARY_BG),
        ('TOPPADDING',   (0,0),(-1,-1), 4*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4*mm),
    ]))

    inner_items_seasonal = [
        Paragraph(f'<b>{UI_SIMP_SEASONAL_TITLE}</b>', S_SIMP_HEAD),
        Spacer(1, 3*mm),
    ] + [Paragraph(f'[ ] {item}', S_SIMP_BODY) for item in S31_SEASONAL]
    cell_seasonal = Table([[inner_items_seasonal]], colWidths=[CONTENT_W/2 - 3*mm])
    cell_seasonal.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, COLOR_ACCENT),
        ('BACKGROUND',   (0,0),(-1,-1), COLOR_ACCENT_BG),
        ('TOPPADDING',   (0,0),(-1,-1), 4*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 4*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4*mm),
    ]))

    prot_row = Table([[cell_women, cell_seasonal]], colWidths=[CONTENT_W/2, CONTENT_W/2])
    prot_row.setStyle(TableStyle([
        ('TOPPADDING',   (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
        ('LEFTPADDING',  (0,0),(-1,-1), 0),
        ('RIGHTPADDING', (0,0),(0,-1),  4*mm),
        ('RIGHTPADDING', (1,0),(1,-1),  0),
    ]))
    story.append(prot_row)
    story.append(sp(4))

    # ── HOW TO START TODAY — large numbered checklist ────────────────────
    story.append(Paragraph('<b>HOW TO START -- TODAY</b>', S_SIMP_HEAD))
    story.append(sp(1))

    start_rows = []
    for i, step in enumerate(S31_HOW_START, 1):
        step_text = step[1] if isinstance(step, tuple) else step
        start_rows.append([
            Paragraph(f'<b>{i}</b>', S_SIMP_NUM),
            Paragraph(step_text, S_SIMP_LARGE),
        ])
    start_tbl = Table(start_rows, colWidths=[18*mm, CONTENT_W - 18*mm])
    start_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 2, COLOR_PRIMARY),
        ('LINEBELOW',    (0,0),(-1,-2), 0.75, COLOR_PRIMARY_MID),
        ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
        ('ALIGN',        (0,0),(0,-1),  'CENTER'),
        ('TOPPADDING',   (0,0),(-1,-1), 3.5*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3.5*mm),
        ('LEFTPADDING',  (0,0),(0,-1),  2*mm),
        ('LEFTPADDING',  (1,0),(1,-1),  5*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 4*mm),
        ('BACKGROUND',   (0,0),(0,-1),  COLOR_PRIMARY_BG),
    ]))
    story.append(start_tbl)
    story.append(sp(3))

    return story

def get_toc_text(sec_num, default_text):
    """Group/combine adjacent sections for a compact 1-page TOC matching HTML layout."""
    groups = LAYOUT_CONFIG.get("toc_groups", {})
    
    if sec_num in groups:
        return True, groups[sec_num]
    
    skip_sections = {
        "S4", "S6", "S8", "S9", "S11", "S12", "S18", "S20", "S22", "S23", "S24",
        "S26", "S27", "S29", "S31", "S32", "S33", "S34"
    }
    if sec_num in skip_sections:
        return False, ""
        
    return True, default_text


def build_rule_families_box():
    """Rule families callout box matching HTML design."""
    box_config = LAYOUT_CONFIG.get("rule_families_box", {})
    title = box_config.get("title", "Rule Families — Quick Reference")
    col1_text = box_config.get("col1_text", "")
    col2_text = box_config.get("col2_text", "")
    footer_text = box_config.get("footer_text", "")

    lbl_para = Paragraph(f'<b>{title.upper()}</b>', S_CALLOUT_LBL)
    p1 = Paragraph(col1_text, S_NORMAL)
    p2 = Paragraph(col2_text, S_NORMAL)
    
    col_w = (CONTENT_W - 10 * mm) / 2
    tbl = Table([[p1, p2]], colWidths=[col_w, col_w])
    tbl.setStyle(TableStyle([
        ('VALIGN',      (0,0),(-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0),(-1,-1), 0),
        ('RIGHTPADDING',(0,0),(-1,-1), 4 * mm),
        ('TOPPADDING',  (0,0),(-1,-1), 0),
        ('BOTTOMPADDING',(0,0),(-1,-1), 0),
    ]))
    
    footer_para = Paragraph(f'<i>{footer_text}</i>', S_SMALL_GREY)
    
    inner = [
        lbl_para,
        HRFlowable(width='100%', thickness=0.5, color=BLACK, spaceBefore=1.5*mm, spaceAfter=2*mm),
        tbl,
        HRFlowable(width='100%', thickness=0.25, color=GREY_RULE, spaceBefore=2*mm, spaceAfter=2*mm),
        footer_para
    ]
    
    outer = Table([[inner]], colWidths=[CONTENT_W])
    outer.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 1.5, BLACK),
        ('BACKGROUND',   (0,0),(-1,-1), WHITE),
        ('TOPPADDING',   (0,0),(-1,-1), 4 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 5 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 5 * mm),
    ]))
    return [outer]


def build_toc_page(toc):
    story = [PageBreak()]   # always start TOC on a fresh page
    story.extend(build_section_header(UI_TOC_TITLE))
    story.append(sp(1))
    story.append(para(UI_TOC_INTRO, S_ITALIC_SM))
    story.append(sp(2))
    story.append(toc)
    story.append(sp(4))
    story.extend(build_rule_families_box())
    # No PageBreak at the end since Part 1 starts with PageBreak
    return story


# =============================================================================
# MAIN STORY BUILDER
# =============================================================================

def build_story():
    story = []

    # ── TOC object (filled automatically during build) ─────────────────
    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle(name='TOC0', fontName=FONT_SANS_BOLD, fontSize=9,
                       leading=12, leftIndent=0, spaceBefore=2, spaceAfter=0.5,
                       textColor=BLACK, rightIndent=12*mm),
        ParagraphStyle(name='TOC1', fontName=FONT_SANS, fontSize=8,
                       leading=11, leftIndent=10*mm, spaceBefore=0.5, spaceAfter=0.5,
                       textColor=BLACK, rightIndent=12*mm),
    ]
    for s in toc.levelStyles:
        if _SHAPING:
            s.shaping = 1

    # ── COVER ──────────────────────────────────────────────────────────
    story.extend(build_cover())

    # ── QUICK REFERENCE CARD ───────────────────────────────────────────
    story.extend(build_quick_ref())

    # ── TOC PAGE ───────────────────────────────────────────────────────
    story.extend(build_toc_page(toc))

    # ══════════════════════════════════════════════════════════════════
    # PART 1 -- WHAT IS THIS SYSTEM
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 1", PART1_TITLE))

    story.extend(build_section_header("§1 — " + SEC1_TITLE, toc=True, toc_text=UI_TOC["S1"]))

    for label, text in [
        (SEC1_PROBLEM_LABEL, SEC1_PROBLEM),
        (SEC1_SOLUTION_LABEL, SEC1_SOLUTION),
        (SEC1_HOW_LABEL, SEC1_HOW),
        (SEC1_WHY_LABEL, SEC1_WHY),
        (SEC1_CANNOT_LABEL, SEC1_CANNOT),
    ]:
        story.extend(build_callout(label, text))

    story.extend(build_section_header("§2 — " + SEC2_TITLE, toc=True, toc_text=UI_TOC["S2"]))
    story.append(Paragraph(f'<b>{SEC2_CORE_IDEA_TITLE}</b>', S_SUBSECTION))
    story.append(para(SEC2_CORE_IDEA, S_NORMAL_J))
    story.append(sp(3))

    story.extend(build_subsection_header(SEC2_PRINCIPLES_TITLE))
    story.append(sp(1))
    # Five principles as a horizontal 5-column grid table with thin borders
    princ_cols = []
    for pnum, ptitle, pdesc in SEC2_PRINCIPLES:
        p_digit = pnum.split()[-1]
        cell_content = [
            Paragraph(f'<b>P-0{p_digit}</b>', S_NUM_ID),
            Spacer(1, 1.5 * mm),
            Paragraph(f'<b>{ptitle}</b>', ParagraphStyle(name=f'PTitle_{p_digit}', parent=S_NORMAL, fontName=FONT_SANS_BOLD, fontSize=8.5, leading=10, textColor=BLACK, shaping=_SHAPING)),
            Spacer(1, 1 * mm),
            Paragraph(pdesc, S_SMALL),
        ]
        princ_cols.append(cell_content)

    p_tbl = Table([princ_cols], colWidths=[CONTENT_W / 5] * 5)
    p_tbl.setStyle(TableStyle([
        ('VALIGN',       (0,0),(-1,-1), 'TOP'),
        ('TOPPADDING',   (0,0),(-1,-1), 4 * mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), 4 * mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 3 * mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 3 * mm),
        ('BOX',          (0,0),(-1,-1), 1.5, BLACK),
        ('INNERGRID',    (0,0),(-1,-1), 0.5, colors.HexColor('#cccccc')),
    ]))
    story.append(p_tbl)
    story.append(sp(3))

    story.append(Paragraph(f'<b>{SEC2_LAYERS_TITLE}</b>', S_SUBSECTION))
    story.append(para(SEC2_LAYERS_INTRO, S_ITALIC_SM))
    story.append(sp(2))
    story.extend(build_seven_layers())
    story.append(para(SEC2_LAYERS_FOOTER, S_ITALIC_SM))

    # ══════════════════════════════════════════════════════════════════
    # PART 2 -- THE RULES
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 2", PART2_TITLE))
    story.append(para(PART2_INTRO, S_ITALIC_SM))
    story.append(sp(3))

    story.extend(build_section_header("§3 — " + S3_TITLE, toc=True, toc_text=UI_TOC["S3"]))
    story.append(para(S3_INTRO, S_ITALIC_SM))
    story.append(sp(2))
    story.extend(build_numbers_grid())
    story.extend(build_rules_group(RULES_CORE[:19]))

    story.extend(build_section_header("§4 — " + S4_TITLE, toc=True, toc_text=UI_TOC["S4"]))
    story.extend(build_rules_group([r for r in RULES_CORE if r[0] >= 'R-20' and r[0] <= 'R-30']))

    story.extend(build_section_header("§5 — " + S5_TITLE, toc=True, toc_text=UI_TOC["S5"]))
    story.extend(build_rules_group([r for r in RULES_CORE if r[0] >= 'R-31' and r[0] <= 'R-43']))

    story.extend(build_section_header("§6 — " + S6_TITLE, toc=True, toc_text=UI_TOC["S6"]))
    story.extend(build_rules_group([r for r in RULES_CORE if r[0] >= 'R-44']))

    story.extend(build_section_header("§7 — " + S7_TITLE, toc=True, toc_text=UI_TOC["S7"]))
    story.extend(build_rules_group(RULES_ENF, tag_color=GREY_MID))

    story.extend(build_section_header("§8 — " + S8_TITLE, toc=True, toc_text=UI_TOC["S8"]))
    story.extend(build_rules_group(RULES_RL, tag_color=GREY_MID))

    story.extend(build_section_header("§9 — " + S9_TITLE, toc=True, toc_text=UI_TOC["S9"]))
    story.extend(build_callout(
        "CAP-1 — RED FLAGS: Any 3 of these in the same 6-month period = possible capture",
        build_cap_flags()
    ))
    story.extend(build_rules_group(RULES_CAP[1:], tag_color=GREY_MID))

    story.extend(build_section_header("§10 — " + S10_TITLE, toc=True, toc_text=UI_TOC["S10"]))
    story.extend(build_rules_group(RULES_CONT))

    story.extend(build_section_header("§11 — " + S11_TITLE, toc=True, toc_text=UI_TOC["S11"]))
    story.extend(build_rules_group(RULES_ECON))

    story.extend(build_section_header("§12 — " + S12_TITLE, toc=True, toc_text=UI_TOC["S12"]))
    story.extend(build_subsection_header(S12_GENDER_TITLE))
    story.extend(build_rules_group(RULES_PROT[:8]))
    story.extend(build_subsection_header(S12_CASTE_TITLE))
    story.extend(build_rules_group(RULES_PROT[8:14]))
    story.extend(build_subsection_header(S12_SEASONAL_TITLE))
    story.extend(build_rules_group(RULES_PROT[14:]))

    story.extend(build_section_header("§13 — " + S13_TITLE, toc=True, toc_text=UI_TOC["S13"]))
    story.append(para(S13_NOTE, S_ITALIC_SM))
    story.append(sp(2))
    story.extend(build_rules_group(RULES_FIX, tag_color=GREY_MID))

    # ══════════════════════════════════════════════════════════════════
    # PART 3 -- THE REGISTERS
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 3", PART3_TITLE))
    story.append(para(PART3_INTRO, S_ITALIC_SM))
    story.append(sp(3))
    story.extend(build_section_header("§14 — " + S14_TITLE, toc=True, toc_text=UI_TOC["S14"]))
    for reg in REGISTERS:
        story.extend(build_register(reg))

    story.append(sp(2))
    story.extend(build_callout(UI_BOUNDARY_DOC, BOUNDARY_DOCUMENT_NOTE))

    # ══════════════════════════════════════════════════════════════════
    # PART 4 -- THE ROLES
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 4", PART4_TITLE))
    story.extend(build_section_header("§15 — " + S15_TITLE,
                                       toc=True, toc_text=UI_TOC["S15"]))
    for role in ROLES:
        story.extend(build_role(role))
    story.append(sp(2))
    story.extend(build_callout(UI_ROTATING_VER_NOTE, VERIFIER_ROTATING_NOTE))

    # ══════════════════════════════════════════════════════════════════
    # PART 5 -- THE WORKFLOWS
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 5", PART5_TITLE))
    story.extend(build_section_header("§16 — " + S16_TITLE,
                                       toc=True, toc_text=UI_TOC["S16"]))
    for wf in WORKFLOWS:
        story.append(PageBreak())
        story.extend(build_workflow(wf))

    # ══════════════════════════════════════════════════════════════════
    # PART 6 -- INTEGRITY AND PROTECTION
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 6", PART6_TITLE))
    story.extend(build_section_header("§17 — " + S17_TITLE,
                                       toc=True, toc_text=UI_TOC["S17"]))
    story.append(para(S17_INTRO, S_ITALIC_SM))
    story.append(sp(2))
    for idx, atk in enumerate(ATTACKS):
        if idx in (3, 6):
            story.append(PageBreak())
        story.extend(build_attack(atk))

    story.append(PageBreak())
    story.extend(build_section_header("§18 — " + S18_TITLE,
                                       toc=True, toc_text=UI_TOC["S18"]))
    for title, text in [
        (S18_GENDER_TITLE, S18_GENDER),
        (S18_CASTE_TITLE,  S18_CASTE),
        (S18_SEASONAL_TITLE, S18_SEASONAL),
    ]:
        story.extend(build_subsection_header(title))
        story.append(para(text, S_NORMAL_J))
        story.append(sp(2))

    # ══════════════════════════════════════════════════════════════════
    # PART 7 -- ENFORCEMENT
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 7", PART7_TITLE))
    story.extend(build_section_header("§19 — " + S19_TITLE,
                                       toc=True, toc_text=UI_TOC["S19"]))
    story.extend(build_callout(UI_HONEST_SITUATION, S19_HONEST))
    story.append(sp(2))
    story.extend(build_subsection_header("Why the Ladder Works — 5 Rungs"))
    story.extend(build_enforcement_rungs())
    story.append(para(S19_CANNOT, S_ITALIC_SM))

    story.extend(build_section_header("§20 — " + S20_TITLE,
                                       toc=True, toc_text=UI_TOC["S20"]))
    story.extend(build_callout(UI_WHAT_CAPTURE, S20_WHAT))
    story.append(para(S20_FIVE, S_NORMAL_J))

    # ══════════════════════════════════════════════════════════════════
    # PART 8 -- SUSTAINABILITY
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 8", PART8_TITLE))
    story.extend(build_section_header("§21 — " + S21_TITLE,
                                       toc=True, toc_text=UI_TOC["S21"]))
    story.extend(build_subsection_header(S21_VERIFIER_TITLE))
    story.append(para(S21_VERIFIER, S_NORMAL_J))
    story.append(sp(2))
    story.extend(build_subsection_header(S21_RECORDER_TITLE))
    story.append(para(S21_RECORDER, S_NORMAL_J))

    story.append(PageBreak())
    story.extend(build_section_header("§22 — " + S22_TITLE,
                                       toc=True, toc_text=UI_TOC["S22"]))
    story.extend(build_callout(UI_WHY_MATTERS, S22_WHY))
    story.append(sp(1))
    story.append(para('Status values: ' +
                       '  --  '.join(RESIDENT_LIST_STATUS), S_SMALL_GREY))

    story.append(PageBreak())
    story.extend(build_section_header("§23 — " + S23_TITLE,
                                       toc=True, toc_text=UI_TOC["S23"]))
    story.extend(build_callout(UI_REAL_RISK, S23_RISK))
    for title, text in [
        ("The Living History Register", S23_HISTORY),
        ("The Ready List",              S23_READY),
        ("The Five-Year System Review", S23_FIVEYEAR),
    ]:
        story.extend(build_subsection_header(title))
        story.append(para(text, S_NORMAL_J))
        story.append(sp(2))

    story.append(PageBreak())
    story.extend(build_section_header("§24 — " + S24_TITLE,
                                       toc=True, toc_text=UI_TOC["S24"]))
    story.extend(build_callout(UI_SUSTAINABILITY_PROB, S24_PROBLEM))
    story.append(para(S24_COLLECTIVE, S_NORMAL_J))
    story.append(sp(2))
    story.append(para(S24_LABOUR, S_NORMAL_J))

    # ══════════════════════════════════════════════════════════════════
    # PART 9 -- EXTERNAL AND LEGAL
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 9", PART9_TITLE))
    story.extend(build_section_header("§25 — " + S25_TITLE,
                                       toc=True, toc_text=UI_TOC["S25"]))
    story.extend(build_callout(UI_SIMPLE_AGREEMENT, S25_AGREEMENT))
    for title, text in [
        ("The Rotating Verifier Exchange", S25_ROTATING),
        ("The Annual Cross-Village Audit", S25_CROSS_AUDIT),
    ]:
        story.extend(build_subsection_header(title))
        story.append(para(text, S_NORMAL_J))
        story.append(sp(2))

    story.extend(build_section_header("§26 — " + S26_TITLE,
                                       toc=True, toc_text=UI_TOC["S26"]))
    story.extend(build_callout(UI_HONEST_START, S26_HONEST))
    first_layer = True
    for title, text in [
        ("Layer 1 — Gram Sabha Integration",   S26_GRAM),
        ("Layer 2 — Revenue Record Cross-Reference", S26_REVENUE),
        ("Layer 3 — The Evidence Package",    S26_EVIDENCE),
        ("Layer 4 — The Long Game",           S26_LONG_GAME),
    ]:
        if first_layer:
            story.append(PageBreak())
            first_layer = False
        story.extend(build_subsection_header(title))
        story.append(para(text, S_NORMAL_J))
        story.append(sp(2))

    story.append(PageBreak())
    story.extend(build_subsection_header("Legal Rules (Legal-1 – Legal-10)"))
    story.append(para("These numbered rules operationalise the four legal layers above. Apply them in sequence.", S_ITALIC_SM))
    story.append(sp(2))
    compaction = LAYOUT_CONFIG.get("compaction", {})
    if compaction.get("legal_rules_use_custom_style", False):
        params = compaction.get("legal_rules_style_params", {"size": 9.2, "leading": 12.5})
        S_LEGAL_RULE_BODY = make_style("LegalRuleBody", size=params.get("size", 9.2), leading=params.get("leading", 12.5))
        padding_tb = compaction.get("legal_rules_padding_tb", 1.0)
        space_after = compaction.get("legal_rules_space_after", 0.5)
        story.extend(build_rules_group(RULES_LEGAL, tag_color=GREY_MID, style=S_LEGAL_RULE_BODY, padding_tb=padding_tb, space_after=space_after))
    else:
        padding_tb = compaction.get("legal_rules_padding_tb", 1.5)
        space_after = compaction.get("legal_rules_space_after", 1.0)
        story.extend(build_rules_group(RULES_LEGAL, tag_color=GREY_MID, padding_tb=padding_tb, space_after=space_after))

    story.append(PageBreak())
    story.extend(build_section_header("§27 — " + S27_TITLE,
                                       toc=True, toc_text=UI_TOC["S27"]))
    story.extend(build_subsection_header("Three Definitions of 'Replace a State Land System'"))
    for title, text in [
        ("Definition A — Parallel Legitimacy",   S27_DEF_A),
        ("Definition B — Functional Superiority",S27_DEF_B),
        ("Definition C — Legal Equivalence",     S27_DEF_C),
    ]:
        story.append(para(f'<b>{title.replace("&","&amp;")}:</b>  {text.replace("&","&amp;")}', S_NORMAL))
        story.append(sp(1))
    story.append(sp(2))

    story.extend(build_subsection_header("27.2 — Why the State System Is Vulnerable"))
    story.append(para(S27_WEAKNESSES, S_NORMAL_J))
    story.append(sp(2))

    story.append(PageBreak())
    story.extend(build_subsection_header("27.3 — The Four-Phase Legislative Pathway"))
    for phase in LEGISLATIVE_PHASES:
        story.extend(build_phase(phase))

    story.append(PageBreak())
    story.extend(build_callout("WHAT THE SYSTEM CAN DO RIGHT NOW", S27_CAN_DO_NOW))
    story.append(sp(2))
    story.extend(build_subsection_header("The Honest Timeline"))
    story.extend(build_timeline())
    story.append(para(S27_TIMELINE, S_ITALIC_SM))

    # ══════════════════════════════════════════════════════════════════
    # PART 10 -- EMERGENCIES AND CLOSURE
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 10", PART10_TITLE))
    story.extend(build_section_header("§28 — " + S28_TITLE,
                                       toc=True, toc_text=UI_TOC["S28"]))
    for prep, desc in DISASTER_PREPARATIONS:
        prep_safe = prep.replace('&','&amp;')
        desc_safe = desc.replace('&','&amp;')
        story.extend(build_rule_block(prep_safe, desc_safe, tag_color=BLACK))
    story.append(sp(2))
    for scenario, instructions in DISASTER_SCENARIOS:
        story.append(para(f'<b>{scenario.replace("&","&amp;")}:</b>  {instructions.replace("&","&amp;")}', S_NORMAL))
    story.append(sp(3))

    story.extend(build_section_header("§29 — " + S29_TITLE,
                                       toc=True, toc_text=UI_TOC["S29"]))
    story.extend(build_callout(UI_WHEN_EXIT, EXIT_TRIGGERS))
    story.append(sp(2))
    story.append(PageBreak())
    story.extend(build_callout(UI_KEY_RULE, EXIT_KEY_RULE))

    # ══════════════════════════════════════════════════════════════════
    # PART 11 -- REFERENCE
    # ══════════════════════════════════════════════════════════════════
    story.extend(build_part_header("PART 11", PART11_TITLE))
    story.extend(build_section_header("§30 — " + S30_TITLE,
                                       toc=True, toc_text=UI_TOC["S30"]))
    story.extend(build_callout(UI_ABS_MINIMUM, S30_MINIMUM))
    story.append(para(S30_TIME, S_NORMAL))
    story.append(sp(2))
    story.extend(build_callout("THE FIRST ENTRY IN NOTEBOOK 6 (LIVING HISTORY REGISTER)",
                                S30_FIRST_ENTRY))

    story.extend(build_section_header("§31 — " + S31_TITLE,
                                       toc=True, toc_text=UI_TOC["S31"]))
    story.extend(build_simplified_village())

    story.append(PageBreak())
    story.extend(build_section_header("§32 — " + S32_TITLE,
                                       toc=True, toc_text=UI_TOC["S32"]))
    story.append(para(S32_INTRO, S_ITALIC_SM))
    story.append(sp(2))
    for test in BULLETPROOF_TESTS:
        story.extend(build_test(test))

    story.append(PageBreak())
    story.extend(build_section_header("§33 — " + S33_TITLE,
                                       toc=True, toc_text=UI_TOC["S33"]))
    story.append(para(S33_INTRO, S_ITALIC_SM))
    story.append(sp(2))
    for prec in HISTORICAL_PRECEDENTS:
        story.extend(build_precedent(prec))

    story.append(PageBreak())
    story.extend(build_section_header("§34 — " + S34_TITLE,
                                       toc=True, toc_text=UI_TOC["S34"]))
    compaction = LAYOUT_CONFIG.get("compaction", {})
    callout_style_name = compaction.get("back_cover_callout_style", "CalloutTxt")
    final_style_name = compaction.get("back_cover_final_style", "NormalJ")
    
    # Retrieve style objects from globals
    callout_style = globals().get(f"S_{callout_style_name.upper()}") or S_CALLOUT_TXT
    final_style = globals().get(f"S_{final_style_name.upper()}") or S_NORMAL_J
    
    story.extend(build_callout(UI_WHAT_CAN_DO, S34_CAN_DO, style=callout_style))
    story.extend(build_callout(UI_WHAT_CANNOT_DO, S34_CANNOT_DO, style=callout_style))
    
    final_padding = compaction.get("back_cover_final_padding", 5.0)
    final_sp_before = compaction.get("back_cover_final_sp_before", 3.0)
    final_sp_after = compaction.get("back_cover_final_sp_after", 4.0)

    # Final statement box
    final_safe = S34_FINAL.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    final_tbl = Table(
        [[Paragraph(f'<i>{final_safe}</i>', final_style)]],
        colWidths=[CONTENT_W]
    )
    final_tbl.setStyle(TableStyle([
        ('BOX',          (0,0),(-1,-1), 2, BLACK),
        ('TOPPADDING',   (0,0),(-1,-1), final_padding*mm),
        ('BOTTOMPADDING',(0,0),(-1,-1), final_padding*mm),
        ('LEFTPADDING',  (0,0),(-1,-1), 5*mm),
        ('RIGHTPADDING', (0,0),(-1,-1), 5*mm),
    ]))
    story.append(sp(final_sp_before))
    story.append(final_tbl)
    story.append(sp(final_sp_after))

    # Document end signature
    end_tbl = Table(
        [[Paragraph(f'<b>{DOC_TITLE}  —  {DOC_VERSION}</b>', S_SMALL),
          Paragraph(f'<b>{DOC_GITHUB}</b>', S_SMALL)]],
        colWidths=[CONTENT_W * 0.6, CONTENT_W * 0.4]
    )
    end_tbl.setStyle(TableStyle([
        ('ALIGN',        (1,0),(1,-1),'RIGHT'),
        ('TOPPADDING',   (0,0),(-1,-1),0),
        ('BOTTOMPADDING',(0,0),(-1,-1),0),
        ('LEFTPADDING',  (0,0),(-1,-1),0),
        ('RIGHTPADDING', (0,0),(-1,-1),0),
    ]))
    story.append(HRFlowable(width='100%', thickness=1, color=BLACK,
                            spaceBefore=2*mm, spaceAfter=2*mm))
    story.append(end_tbl)

    return story


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print(f"Building Bhumi Trust PDF - language: {lang}")
    print(f"Output file: {OUTPUT_FILE}")
    print("Please wait...")

    story = build_story()
    build_doc(story, OUTPUT_FILE)

    size_kb = os.path.getsize(OUTPUT_FILE) / 1024
    print(f"\nDone! File saved: {OUTPUT_FILE}")
    print(f"File size: {size_kb:.0f} KB")
    print(f"Open {OUTPUT_FILE} to review.")

