#!/usr/bin/env python3
# =============================================================================
#  BHUMI TRUST — Unified Manager & Developer Toolkit (bhumi_manager.py)
#
#  An all-in-one developer toolkit that consolidates all testing, validation,
#  generation, rendering, extraction, shaping diagnostics, and cleanup 
#  operations into a single premium, portable script in the root directory.
#
#  Features:
#    - Interactive TUI Dashboard (UP/DOWN/ENTER arrow navigation)
#    - Native PDF Quality Assurance & Validation Suite
#    - Direct CLI Subcommand Dispatch
#
#  Usage:
#    python bhumi_manager.py                  (Triggers Interactive Dashboard)
#    python bhumi_manager.py generate all     (Direct PDF Blueprint compilation)
#    python bhumi_manager.py validate         (Direct QA Parity & Alignment checks)
#    python bhumi_manager.py render           (Direct High-Fidelity Previews render)
# =============================================================================

import sys
import os
import re
import shutil
import argparse
import glob

# Ensure console supports UTF-8 on Windows
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

# ── ANSI COLORS FOR COLOURED OUTPUT ──────────────────────────────────────────
CLR_GREEN  = "\033[92m"
CLR_RED    = "\033[91m"
CLR_YELLOW = "\033[93m"
CLR_BLUE   = "\033[94m"
CLR_CYAN   = "\033[96m"
CLR_RESET  = "\033[0m"
CLR_BOLD   = "\033[1m"

def print_success(msg):
    print(f"{CLR_GREEN}{CLR_BOLD}[OK]{CLR_RESET} {msg}")

def print_warn(msg):
    print(f"{CLR_YELLOW}{CLR_BOLD}[WARNING]{CLR_RESET} {msg}")

def print_err(msg):
    print(f"{CLR_RED}{CLR_BOLD}[ERROR]{CLR_RESET} {msg}")

def print_info(msg):
    print(f"{CLR_CYAN}[INFO]{CLR_RESET} {msg}")

# ── SUBCOMMAND: GENERATE ─────────────────────────────────────────────────────
def cmd_generate(lang):
    print(f"\n{CLR_BLUE}{CLR_BOLD}=== Generating PDF Documents ==={CLR_RESET}")
    here = os.path.dirname(os.path.abspath(__file__))
    gen_script = os.path.join(here, "generate.py")
    
    if not os.path.exists(gen_script):
        print_err("generate.py not found in the root folder!")
        return False

    import subprocess
    languages = []
    if lang == "all":
        languages = ["english", "hindi"]
    else:
        languages = [lang]

    success = True
    for l in languages:
        print_info(f"Running generator for language: {CLR_BOLD}{l}{CLR_RESET}...")
        try:
            res = subprocess.run([sys.executable, gen_script, l], check=True)
            if res.returncode == 0:
                print_success(f"Successfully generated bhumi_trust_{l}.pdf")
            else:
                success = False
                print_err(f"Failed to generate PDF for {l}")
        except Exception as e:
            success = False
            print_err(f"Error executing generator: {e}")

    return success

# ── SUBCOMMAND: VALIDATE (NATIVE IMPLEMENTATION) ──────────────────────────────
def run_validate_structure(base_lang="english", target_lang="hindi"):
    print(f"\n--- Checking Variable Structure Parity ({base_lang} vs {target_lang}) ---")
    try:
        base_mod = __import__(f"content_{base_lang}")
        target_mod = __import__(f"content_{target_lang}")
    except ImportError as e:
        print_err(f"Could not import language files: {e}")
        return False

    base_vars = {v for v in dir(base_mod) if not v.startswith('_')}
    target_vars = {v for v in dir(target_mod) if not v.startswith('_')}

    missing_in_target = sorted(base_vars - target_vars)
    missing_in_base = sorted(target_vars - base_vars)

    success = True
    if missing_in_target:
        success = False
        print_err(f"Variables present in '{base_lang}' but MISSING in '{target_lang}':")
        for v in missing_in_target:
            print(f"  - {v}")
    else:
        print_success(f"All variables in '{base_lang}' are present in '{target_lang}'.")

    if missing_in_base:
        success = False
        print_err(f"Variables present in '{target_lang}' but MISSING in '{base_lang}':")
        for v in missing_in_base:
            print(f"  - {v}")

    return success

def run_validate_integrity(lang="english"):
    print(f"\n--- Checking Content Integrity & Counts ({lang}) ---")
    try:
        mod = __import__(f"content_{lang}")
    except ImportError:
        print_err(f"Could not import content_{lang}.py")
        return False

    success = True
    rule_lists = [
        "RULES_CORE", "RULES_ENF", "RULES_RL", "RULES_CAP", 
        "RULES_CONT", "RULES_ECON", "RULES_PROT", "RULES_FIX", "RULES_LEGAL"
    ]
    
    total_rules = 0
    missing_any_list = False
    for rlist in rule_lists:
        if hasattr(mod, rlist):
            total_rules += len(getattr(mod, rlist))
        else:
            missing_any_list = True
            print_err(f"Rule list '{rlist}' is missing from module entirely!")
            
    if not missing_any_list:
        if total_rules == 121:
            print_success(f"Total Rules: found {total_rules} across all lists (expected 121)")
        else:
            success = False
            print_err(f"Total Rules: found {total_rules} across all lists (expected 121!)")
            for rlist in rule_lists:
                print(f"  - {rlist}: {len(getattr(mod, rlist))} rules")
    else:
        success = False

    entities = {
        "WORKFLOWS": 15,
        "ROLES": 6,
        "REGISTERS": 6,
    }
    
    for attr, expected_count in entities.items():
        if hasattr(mod, attr):
            actual = len(getattr(mod, attr))
            if actual == expected_count:
                print_success(f"{attr:<20}: found {actual} (expected {expected_count})")
            else:
                success = False
                print_err(f"{attr:<20}: found {actual} (expected {expected_count}!)")
        else:
            success = False
            print_err(f"{attr:<20}: Attribute missing from module entirely!")

    return success

def run_validate_untranslated(lang="hindi"):
    print(f"\n--- Checking for Untranslated English Content in '{lang}' ---")
    file_path = f"content_{lang}.py"
    if not os.path.exists(file_path):
        print_err(f"'{file_path}' does not exist.")
        return False

    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    cleaned = re.sub(r'#.*', '', content)
    quoted_strings = re.findall(r'["\']([^"\']+)["\']', cleaned)
    
    suspicious = []
    for s in quoted_strings:
        if re.search(r'https?://', s) or s.strip() in ('hindi', 'english', 'Martel', 'Poppins', 'EB Garamond', 'Libre Franklin'):
            continue
        if re.search(r'\b[a-zA-Z]{4,}\b\s+\b[a-zA-Z]{4,}\b', s):
            suspicious.append(s.strip()[:100])

    if suspicious:
        print_warn(f"Found {len(suspicious)} potential untranslated English strings in 'content_{lang}.py':")
        for s in suspicious[:15]:
            print(f"  - \"{s}...\"")
        if len(suspicious) > 15:
            print(f"  - ... and {len(suspicious) - 15} more.")
    else:
        print_success(f"No untranslated English sentences found in 'content_{lang}.py'.")
    return True

def run_find_sections_in_pdf(pdf_path):
    try:
        import pypdf
    except ImportError:
        return {}
    reader = pypdf.PdfReader(pdf_path)
    sections = {}
    for idx, page in enumerate(reader.pages):
        if idx in (2, 3):  # Skip Table of Contents
            continue
        text = page.extract_text()
        
        matches = re.findall(r'§\s*(\d+)', text)
        for m in matches:
            sec_num = int(m)
            if sec_num not in sections:
                sections[sec_num] = idx + 1
        
        part_matches = re.findall(r'PART\s+(\d+)', text, re.IGNORECASE)
        for pm in part_matches:
            part_num = f"PART {pm}"
            if part_num not in sections:
                sections[part_num] = idx + 1
                
    return sections

def run_validate_alignment(base_lang="english", target_lang="hindi"):
    print(f"\n--- Checking Page-by-Page PDF Alignment ({base_lang} vs {target_lang}) ---")
    
    try:
        import pypdf
    except ImportError:
        print_warn("'pypdf' package is not installed. PDF page alignment checks will be skipped.")
        return True

    here = os.path.dirname(os.path.abspath(__file__))
    base_pdf = os.path.join(here, f"bhumi_trust_{base_lang}.pdf")
    target_pdf = os.path.join(here, f"bhumi_trust_{target_lang}.pdf")

    if not os.path.exists(base_pdf) or not os.path.exists(target_pdf):
        print_err("PDFs not found. Please run PDF generation first.")
        return False

    r_base = pypdf.PdfReader(base_pdf)
    r_target = pypdf.PdfReader(target_pdf)
    
    print_info(f"'{base_lang}' total pages: {len(r_base.pages)}")
    print_info(f"'{target_lang}' total pages: {len(r_target.pages)}")

    base_secs = run_find_sections_in_pdf(base_pdf)
    target_secs = run_find_sections_in_pdf(target_pdf)

    print(f"\n{'Section/Part':<15} | {base_lang.capitalize() + ' Page':<15} | {target_lang.capitalize() + ' Page':<15} | {'Difference':<10}")
    print("-" * 65)

    all_keys = list(set(base_secs.keys()) | set(target_secs.keys()))
    sections = sorted([k for k in all_keys if isinstance(k, int)])
    parts = sorted([k for k in all_keys if isinstance(k, str)])

    max_diff = 0
    mismatches = 0

    for key in sections + parts:
        bp = base_secs.get(key, '-')
        tp = target_secs.get(key, '-')
        diff = tp - bp if isinstance(bp, int) and isinstance(tp, int) else '-'
        
        diff_str = str(diff)
        if isinstance(diff, int):
            max_diff = max(max_diff, abs(diff))
            if diff != 0:
                mismatches += 1
                diff_str = f"*{diff}*"
        
        print(f"{str(key):<15} | {str(bp):<15} | {str(tp):<15} | {diff_str:<10}")

    print("\n--- Alignment Verdict ---")
    success = True
    if len(r_base.pages) == len(r_target.pages):
        print_success(f"Both files have EXACTLY the same overall page count ({len(r_base.pages)} pages).")
    else:
        success = False
        print_err(f"Total page counts mismatch: {len(r_base.pages)} vs {len(r_target.pages)}")

    if mismatches == 0:
        print_success("Perfect 1:1 section synchronization achieved on every page!")
    elif max_diff <= 1:
        print_success(f"Clean micro-alignment: Only {mismatches} sections have minor 1-page shifts, which resynchronize perfectly.")
    else:
        success = False
        print_warn(f"Layout drift: Some sections are shifted by {max_diff} pages!")

    return success

def cmd_validate(base_lang="english", target_lang="hindi"):
    print(f"\n{CLR_BLUE}{CLR_BOLD}=== Running Validation and Page Alignment Suite ==={CLR_RESET}")
    success = True

    # 1. Structure Parity
    if not run_validate_structure(base_lang, target_lang):
        success = False

    # 2. Integrity Counts
    if not run_validate_integrity(base_lang) or not run_validate_integrity(target_lang):
        success = False

    # 3. Untranslated scan
    if not run_validate_untranslated(target_lang):
        pass # Warning only, do not fail

    # 4. Page Alignment
    if not run_validate_alignment(base_lang, target_lang):
        success = False

    return success

# ── SUBCOMMAND: RENDER ───────────────────────────────────────────────────────
def cmd_render(out_dir=None, grayscale=False):
    if grayscale:
        print(f"\n{CLR_BLUE}{CLR_BOLD}=== Rendering Key PDF Pages to BLACK & WHITE (Grayscale) Previews ==={CLR_RESET}")
    else:
        print(f"\n{CLR_BLUE}{CLR_BOLD}=== Rendering Key PDF Pages to PNG Previews ==={CLR_RESET}")
    
    here = os.path.dirname(os.path.abspath(__file__))
    
    if not out_dir:
        out_dir = os.path.join(here, "visual_previews")
        if grayscale:
            out_dir = os.path.join(out_dir, "grayscale")
    os.makedirs(out_dir, exist_ok=True)

    try:
        import fitz # PyMuPDF
    except ImportError:
        print_err("PyMuPDF (fitz) is required for rendering previews. Install it using: pip install PyMuPDF")
        return False

    pages_to_render = [0, 2, 4, 10, 16, 47, 54, 71] # 0-indexed (page 1, 3, 5, 11, 17, 48, 55, 72)
    success = True

    for lang in ["english", "hindi"]:
        pdf_name = f"bhumi_trust_{lang}.pdf"
        pdf_path = os.path.join(here, pdf_name)
        if not os.path.exists(pdf_path):
            print_warn(f"PDF file {pdf_name} not found in root. Skipping rendering for {lang}.")
            continue
        
        try:
            doc = fitz.open(pdf_path)
            print_info(f"Rendering pages for {CLR_BOLD}{lang}{CLR_RESET} PDF...")
            for p_num in pages_to_render:
                if p_num < len(doc):
                    page = doc[p_num]
                    cs = fitz.csGRAY if grayscale else None
                    pix = page.get_pixmap(colorspace=cs, dpi=150)
                    out_name = f"page_{lang}_{p_num + 1}.png"
                    out_path = os.path.join(out_dir, out_name)
                    pix.save(out_path)
                    folder_lbl = "visual_previews/grayscale" if grayscale else "visual_previews"
                    print_success(f"Saved preview: {folder_lbl}/{out_name}")
                else:
                    print_warn(f"Page {p_num + 1} is out of bounds for {pdf_name}")
        except Exception as e:
            success = False
            print_err(f"Failed to render pages for {lang}: {e}")

    if success:
        folder_lbl = "visual_previews/grayscale/" if grayscale else "visual_previews/"
        print_success(f"All previews successfully saved in: {CLR_BOLD}{folder_lbl}{CLR_RESET}")
    return success

# ── SUBCOMMAND: EXTRACT ──────────────────────────────────────────────────────
def cmd_extract(pdf_path, page_num):
    print(f"\n{CLR_BLUE}{CLR_BOLD}=== Extracting Text Content ==={CLR_RESET}")
    if not os.path.exists(pdf_path):
        print_err(f"PDF file not found at: {pdf_path}")
        return False

    try:
        import pypdf
    except ImportError:
        print_err("pypdf is required for extraction. Install it using: pip install pypdf")
        return False

    try:
        reader = pypdf.PdfReader(pdf_path)
        total_pages = len(reader.pages)
        if page_num < 1 or page_num > total_pages:
            print_err(f"Page number {page_num} is out of bounds (Total Pages: {total_pages})")
            return False

        page = reader.pages[page_num - 1]
        text = page.extract_text()
        print_info(f"Extracted content from {pdf_path} (Page {page_num} of {total_pages}):")
        print("-" * 70)
        print(text)
        print("-" * 70)
        return True
    except Exception as e:
        print_err(f"Failed to extract text: {e}")
        return False

# ── SUBCOMMAND: DEBUG SHAPING ────────────────────────────────────────────────
def cmd_debug_shaping():
    print(f"\n{CLR_BLUE}{CLR_BOLD}=== Devanagari Font Shaping & Glyph Diagnostics ==={CLR_RESET}")
    
    # 1. Check if uharfbuzz is installed
    try:
        import uharfbuzz as hb
        print_success(f"uharfbuzz library found (Version {getattr(hb, '__version__', 'unknown')})")
    except ImportError:
        print_warn("uharfbuzz is not installed. Native shaping support check will run in fallback mode.")
    
    # 2. Check Hindi fonts registration
    here = os.path.dirname(os.path.abspath(__file__))
    font_path = os.path.join(here, "fonts", "hindi", "Martel-Regular.ttf")
    if not os.path.exists(font_path):
        print_warn(f"Hindi Martel font not found at: {font_path}. Checking fallback directories...")
        font_path = os.path.join(here, "fonts", "Martel-Regular.ttf")
        
    if os.path.exists(font_path):
        print_success(f"Martel Devanagari font is locally present: {font_path}")
    else:
        print_err("Hindi Martel font is missing! Run PDF generation first to auto-download fonts.")
        return False

    # 3. Simulate shaping composition
    print_info("Simulating Devanagari shaped fragment creation inside ReportLab...")
    try:
        import reportlab.pdfbase.ttfonts as ttf
        from reportlab.pdfbase import pdfmetrics
        
        # Register font temporarily for simulation
        font_name = "Martel_Shaping_Debug"
        pdfmetrics.registerFont(ttf.TTFont(font_name, font_path))
        print_success("Martel font successfully registered in ReportLab PDF Metrics.")
        
        # Hindi shaped word check
        test_word = "प्रविष्टियाँ" # complex composition: pa + ra + va + i + sha + ta + i + yaan
        
        # Check ReportLab shaping status
        shaping_active = False
        try:
            # ReportLab TTFont checks uharfbuzz and shape capability
            font_obj = pdfmetrics.getFont(font_name)
            if hasattr(font_obj, 'face') and hasattr(font_obj.face, '_ttfont'):
                # Try shaping
                frags = ttf.shapeFragWord(test_word, font_obj, 10)
                print_success(f"Glyph shaping simulation complete. Renders as {len(frags)} shaping fragments:")
                for idx, frag in enumerate(frags):
                    print(f"  Frag {idx+1}: Glyph ID = {frag[0]}, width offset = {frag[1]}")
                shaping_active = True
        except Exception as e:
            print_warn(f"Direct ReportLab shaping simulation failed: {e}")

        if shaping_active:
            print_success("Premium glyph-shaping engines are 100% active and running beautifully!")
        else:
            print_warn("Font renders, but complex shaping composition is relying on simple glyph mappings.")
            
        return True
    except Exception as e:
        print_err(f"Font registers with issues: {e}")
        return False

# ── SUBCOMMAND: CLEAN ────────────────────────────────────────────────────────
def cmd_clean(scratch_path=None):
    print(f"\n{CLR_BLUE}{CLR_BOLD}=== Workspace Clean-up Operations ==={CLR_RESET}")
    
    here = os.path.dirname(os.path.abspath(__file__))
    
    # 1. Clean legacy zip files from root
    zips = glob.glob(os.path.join(here, "*.zip"))
    deleted_zips = 0
    for z in zips:
        try:
            os.remove(z)
            deleted_zips += 1
        except Exception as e:
            print_err(f"Could not delete {os.path.basename(z)}: {e}")

    if deleted_zips > 0:
        print_success(f"Removed {deleted_zips} legacy zip files from root folder.")
    else:
        print_info("No legacy zip files found in root folder.")

    # 2. Clean obsolete validate.py from root
    val_script = os.path.join(here, "validate.py")
    if os.path.exists(val_script):
        try:
            os.remove(val_script)
            print_success("Successfully removed obsolete validate.py (validation is now fully native!).")
        except Exception as e:
            print_err(f"Could not remove validate.py: {e}")

    # 3. Clean scratch files
    if not scratch_path:
        # Default scratch directory location
        scratch_path = r"C:\Users\Sharansh\.gemini\antigravity-ide\brain\e9f928b8-e4b1-4c8b-aeca-2d33fd573a4a\scratch"

    if os.path.exists(scratch_path) and os.path.isdir(scratch_path):
        scratch_files = glob.glob(os.path.join(scratch_path, "*"))
        deleted_scratch = 0
        for sf in scratch_files:
            if os.path.isfile(sf):
                try:
                    os.remove(sf)
                    deleted_scratch += 1
                except Exception as e:
                    print_err(f"Could not delete scratch file {os.path.basename(sf)}: {e}")

        if deleted_scratch > 0:
            print_success(f"Cleaned up {deleted_scratch} legacy development scratch/metadata files from scratch folder.")
        else:
            print_info("Scratch folder is already clean.")
    else:
        print_warn(f"Scratch path not found or inaccessible: {scratch_path}")

    print_success("Clean-up operation complete! Root workspace is fully pristine.")
    return True

# ── INTERACTIVE TUI DASHBOARD LOOP ───────────────────────────────────────────
def show_interactive_menu():
    import shutil
    import glob

    options = [
        ('gen_eng', 'Generate English PDF            (bhumi_trust_english.pdf)'),
        ('gen_hin', 'Generate Hindi PDF              (bhumi_trust_hindi.pdf)'),
        ('gen_all', 'Generate Both PDFs              (English + Hindi)'),
        ('val',     'Run Quality & Alignment Suite  (native validate)'),
        ('rnd_col', 'Render Color Previews           (./visual_previews/)'),
        ('rnd_bw',  'Render Monochrome Previews      (./visual_previews/grayscale/)'),
        ('shp',     'Run Shaping & Font Diagnostics  (reportlab checks)'),
        ('cln',     'Clean Workspace & Scratch Files (wipe temporary assets)'),
        ('help',    'Show Command-Line Help          (--help)'),
        ('quit',    'Quit')
    ]

    selected = 0
    WIDTH = min(shutil.get_terminal_size((80, 24)).columns, 80)

    def clear():
        os.system('cls' if os.name == 'nt' else 'clear')

    def draw(sel):
        clear()
        print("=" * WIDTH)
        print("  BHUMI TRUST — Unified Manager & Toolkit  v5.0")
        print("  Interactive Subcommand Menu (UP/DOWN/ENTER)")
        print("=" * WIDTH)
        print()
        print("  Select action to perform:")
        print()
        for i, (key, label) in enumerate(options):
            if i == sel:
                print(f" {CLR_GREEN}{CLR_BOLD}> {label}{CLR_RESET}")
            else:
                print(f"   {label}")
        print()
        print("-" * WIDTH)
        print("  UP/DOWN: navigate   ENTER: select   Q: quit")
        print("-" * WIDTH)

    # Try full-screen curses menu
    try:
        import curses
        def curses_menu(stdscr):
            nonlocal selected
            curses.curs_set(0)
            stdscr.keypad(True)
            while True:
                h, w = stdscr.getmaxyx()
                stdscr.clear()
                
                # Draw header
                stdscr.addstr(0, 0, "=" * min(w-1, 78), curses.A_BOLD)
                stdscr.addstr(1, 2, "BHUMI TRUST — Unified Manager & Toolkit  v5.0", curses.A_BOLD)
                stdscr.addstr(2, 2, "Interactive TUI Developer Dashboard", curses.A_BOLD)
                stdscr.addstr(3, 0, "=" * min(w-1, 78), curses.A_BOLD)
                
                stdscr.addstr(5, 2, "Select action to perform:")
                
                # Draw options
                for i, (key, label) in enumerate(options):
                    row = 7 + i
                    if row >= h - 4:
                        break
                    if i == selected:
                        stdscr.attron(curses.A_REVERSE | curses.A_BOLD)
                        stdscr.addstr(row, 2, f"  {label}"[:w-3])
                        stdscr.attroff(curses.A_REVERSE | curses.A_BOLD)
                    else:
                        stdscr.addstr(row, 4, label[:w-5])
                
                # Footer
                footer_row = min(7 + len(options) + 2, h - 2)
                stdscr.addstr(footer_row, 0, "-" * min(w-1, 78))
                stdscr.addstr(footer_row+1, 2, "UP/DOWN: navigate   ENTER: select   Q: quit")
                stdscr.refresh()

                key = stdscr.getch()
                if key in (curses.KEY_UP, ord('k'), ord('K')):
                    selected = (selected - 1) % len(options)
                elif key in (curses.KEY_DOWN, ord('j'), ord('J')):
                    selected = (selected + 1) % len(options)
                elif key in (curses.KEY_ENTER, ord('\n'), ord('\r'), 10, 13):
                    return options[selected][0]
                elif key in (ord('q'), ord('Q'), 27):
                    return 'quit'
        
        result = curses.wrapper(curses_menu)
        return result
    except Exception:
        # Fallback interactive menu for Windows cmd / non-tty
        while True:
            draw(selected)
            raw = input("  Enter option number (1-{}): ".format(len(options))).strip()
            if raw.lower() in ('q', 'quit', 'exit'):
                return 'quit'
            try:
                n = int(raw) - 1
                if 0 <= n < len(options):
                    return options[n][0]
            except ValueError:
                pass
            print(f"  {CLR_RED}Please enter a number between 1 and {len(options)}{CLR_RESET}")

# ── MAIN ENGINE ──────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="BHUMI TRUST — Unified Manager & Developer Toolkit",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python bhumi_manager.py                  (Triggers Interactive TUI Dashboard)
  python bhumi_manager.py generate all     (Generates both English and Hindi PDFs)
  python bhumi_manager.py validate         (Runs variable structure, integrity and alignment validation)
  python bhumi_manager.py render           (Renders high-resolution color PNG page previews in ./visual_previews/)
  python bhumi_manager.py render -g        (Renders black & white page previews to simulate village printouts)
  python bhumi_manager.py extract bhumi_trust_english.pdf 5 (Extracts and displays text from Page 5)
  python bhumi_manager.py debug-shaping    (Performs ReportLab Devanagari font shaping tests)
  python bhumi_manager.py clean            (Removes workspace zip files and wipes App Data scratch directory)
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", required=False, help="Subcommands to execute")

    # generate subcommand
    parser_gen = subparsers.add_parser("generate", help="Generate PDF documents from Python blueprints")
    parser_gen.add_argument("lang", choices=["english", "hindi", "all"], help="Target language for generation")

    # validate subcommand
    subparsers.add_parser("validate", help="Run parity, integrity and alignment validator suites")

    # render subcommand
    parser_rnd = subparsers.add_parser("render", help="Render high-fidelity PNG previews of key PDF pages in ./visual_previews/")
    parser_rnd.add_argument("--out-dir", type=str, default=None, help="Custom folder to save PNG previews (default: ./visual_previews/)")
    parser_rnd.add_argument("--grayscale", "-g", action="store_true", help="Render in black & white (grayscale) colorspace to verify contrast on local printers")

    # extract subcommand
    parser_ext = subparsers.add_parser("extract", help="Extract and read plain-text content of a specific PDF page")
    parser_ext.add_argument("pdf_path", type=str, help="Absolute or relative path to target PDF file")
    parser_ext.add_argument("page_number", type=int, help="1-indexed target page number to extract")

    # debug-shaping subcommand
    subparsers.add_parser("debug-shaping", help="Run glyph shaping diagnostics for Devanagari text")

    # clean subcommand
    parser_cln = subparsers.add_parser("clean", help="Prune legacy zips and delete 50+ debugging helper scratch scripts")
    parser_cln.add_argument("--scratch-path", type=str, default=None, help="Custom path to scratch directory (optional)")

    # Dispatch logic
    if len(sys.argv) == 1:
        # Show interactive menu dashboard in a loop!
        while True:
            choice = show_interactive_menu()
            if choice == 'quit':
                print(f"\n  {CLR_CYAN}Goodbye! Thank you for pair programming.{CLR_RESET}\n")
                sys.exit(0)
            elif choice == 'help':
                parser.print_help()
            elif choice == 'gen_eng':
                cmd_generate('english')
            elif choice == 'gen_hin':
                cmd_generate('hindi')
            elif choice == 'gen_all':
                cmd_generate('all')
            elif choice == 'val':
                cmd_validate()
            elif choice == 'rnd_col':
                cmd_render(grayscale=False)
            elif choice == 'rnd_bw':
                cmd_render(grayscale=True)
            elif choice == 'shp':
                cmd_debug_shaping()
            elif choice == 'cln':
                cmd_clean()
            
            print(f"\n{CLR_YELLOW}Press ENTER to return to the manager menu...{CLR_RESET}")
            input()

    args = parser.parse_args()

    if args.command == "generate":
        success = cmd_generate(args.lang)
    elif args.command == "validate":
        success = cmd_validate()
    elif args.command == "render":
        success = cmd_render(args.out_dir, args.grayscale)
    elif args.command == "extract":
        success = cmd_extract(args.pdf_path, args.page_number)
    elif args.command == "debug-shaping":
        success = cmd_debug_shaping()
    elif args.command == "clean":
        success = cmd_clean(args.scratch_path)
    else:
        parser.print_help()
        success = False

    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
